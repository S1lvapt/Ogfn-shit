const { exec } = require("child_process");
const log = require("../structs/log.js");

function parseRestartTime(restartTime) {
    if (typeof restartTime !== 'string') return null;

    const intervalMatch = restartTime.match(/^(\d+)([ywdhms])$/);
    if (intervalMatch) {
        const value = parseInt(intervalMatch[1], 10);
        const unit = intervalMatch[2];

        switch (unit) {
            case 'y': return value * 365 * 24 * 60 * 60 * 1000;
            case 'M': return value * 30.44 * 24 * 60 * 60 * 1000;
            case 'w': return value * 7 * 24 * 60 * 60 * 1000;
            case 'd': return value * 24 * 60 * 60 * 1000;
            case 'h': return value * 60 * 60 * 1000;
            case 'm': return value * 60 * 1000;
            case 's': return value * 1000;
            default: return null;
        }
    }

    const scheduleMatch = restartTime.trim().match(/^([01]?\d|2[0-3]):([0-5]\d)(?:\s*([A-Za-z\/]+))?$/);
    if (!scheduleMatch) return null;

    return {
        hour: Number(scheduleMatch[1]),
        minute: Number(scheduleMatch[2]),
        timezone: scheduleMatch[3] || null,
        type: 'schedule'
    };
}

function resolveTimeZone(timezone) {
    if (!timezone) return null;
    const normalized = timezone.toUpperCase();
    switch (normalized) {
        case 'CET':
        case 'CEST':
        case 'EUROPE/PARIS':
            return 'Europe/Paris';
        case 'UTC':
            return 'UTC';
        default:
            return timezone;
    }
}

function getTimeZoneParts(date, timeZone) {
    const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone,
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: false
    });

    return formatter.formatToParts(date).reduce((parts, part) => {
        if (part.type !== 'literal') parts[part.type] = Number(part.value);
        return parts;
    }, {});
}

function getNextScheduledRestart(restartTime) {
    const parsed = parseRestartTime(restartTime);
    if (!parsed || parsed.type !== 'schedule') return null;

    const timeZone = resolveTimeZone(parsed.timezone || 'UTC');
    const now = new Date();
    const localParts = getTimeZoneParts(now, timeZone);
    const offsetMs = Date.UTC(
        localParts.year,
        localParts.month - 1,
        localParts.day,
        localParts.hour,
        localParts.minute,
        localParts.second
    ) - now.getTime();

    let target = new Date(Date.UTC(
        localParts.year,
        localParts.month - 1,
        localParts.day,
        parsed.hour,
        parsed.minute,
        0
    ) - offsetMs);

    if (now >= target) {
        target = new Date(target.getTime() + 24 * 60 * 60 * 1000);
    }

    return target;
}

function formatTime(milliseconds) {
    const seconds = Math.floor((milliseconds / 1000) % 60);
    const minutes = Math.floor((milliseconds / (1000 * 60)) % 60);
    const hours = Math.floor((milliseconds / (1000 * 60 * 60)) % 24);
    const days = Math.floor((milliseconds / (1000 * 60 * 60 * 24)) % 30);
    const months = Math.floor((milliseconds / (1000 * 60 * 60 * 24 * 30.44)) % 12);
    const years = Math.floor(milliseconds / (1000 * 60 * 60 * 24 * 365));

    let timeString = '';
    if (years > 0) timeString += `${years} year${years > 1 ? 's' : ''}, `;
    if (months > 0) timeString += `${months} month${months > 1 ? 's' : ''}, `;
    if (days > 0) timeString += `${days} day${days > 1 ? 's' : ''}, `;
    if (hours > 0) timeString += `${hours} hour${hours > 1 ? 's' : ''}, `;
    if (minutes > 0) timeString += `${minutes} minute${minutes > 1 ? 's' : ''}, `;
    if (seconds > 0) timeString += `${seconds} second${seconds > 1 ? 's' : ''}`;

    return timeString.trim().replace(/,([^,]*)$/, ' and$1');
}

function scheduleRestart(restartTime) {
    const parsed = parseRestartTime(restartTime);
    if (!parsed) {
        log.error("Invalid 'bRestartTime' format");
        return;
    }

    let restartDelay;
    let scheduleTarget;

    if (parsed.type === 'schedule') {
        scheduleTarget = getNextScheduledRestart(restartTime);
        if (!scheduleTarget) {
            log.error("Invalid scheduled restart time");
            return;
        }
        restartDelay = scheduleTarget.getTime() - Date.now();
    } else {
        restartDelay = parsed;
    }

    const formattedTime = formatTime(restartDelay);
    if (scheduleTarget) {
        log.autobackendrestart(`Backend restart scheduled at ${scheduleTarget.toUTCString()} (${restartTime}) - in ${formattedTime}`);
    } else {
        log.autobackendrestart(`Backend will restart in ${formattedTime}`);
    }

    if (restartDelay > 10000) {
        setTimeout(() => {
            log.autobackendrestart("The backend will restart shortly...");
        }, restartDelay - 10000);
    } else {
        setTimeout(() => {
            log.autobackendrestart("The backend will restart shortly...");
        }, restartDelay);
    }

    setTimeout(() => {
        console.clear();
        exec("node index.js", (error, stdout, stderr) => {
            if (error) {
                log.error(`Error restarting backend: ${error.message}`);
                return;
            }
            log.autobackendrestart("Backend restarted successfully");
        });
        process.exit(0);
    }, restartDelay);
}

module.exports = { scheduleRestart };