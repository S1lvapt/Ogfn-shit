// FOV Changer JavaScript

let fovSettings = {
    enabled: false,
    value: 80
};

let fpsSettings = {
    multiplier: 1
};

// Potato Messages
const potatoMessages = [
    "🥔 Time to adjust your FOV!",
    "🥔 Potato power activated!",
    "🥔 See the world like a spud!",
    "🥔 FOV goes BRRRR",
    "🥔 Potato approves this FOV",
    "🥔 Your potatoes await!",
    "🥔 Maximum spud vision!",
    "🥔 Tuber time!",
    "🥔 Golden potato energy!",
    "🥔 Starchy sight engaged!",
    "⚡ Turbo potato mode!",
    "⚡ Speed up your FPS!",
    "🥔⚡ Turbo spud engaged!",
    "⚡ Potato zooming at max speed!",
    "🥔⚡ Prepare for liftoff!"
];

// Initialize FOV Changer
document.addEventListener('DOMContentLoaded', function() {
    loadFOVSettings();
    initializeTheme();
    updatePotatoMessage();
});

// Update Potato Message
function updatePotatoMessage() {
    const msg = document.getElementById('potatoMessage');
    if (msg) {
        msg.textContent = potatoMessages[Math.floor(Math.random() * potatoMessages.length)];
    }
}

// Load FOV Settings from localStorage
function loadFOVSettings() {
    const savedFOV = localStorage.getItem('fovSettings');
    if (savedFOV) {
        fovSettings = JSON.parse(savedFOV);
    }
    
    const savedFPS = localStorage.getItem('fpsSettings');
    if (savedFPS) {
        fpsSettings = JSON.parse(savedFPS);
    }
    
    updateUI();
}

// Save FOV Settings to localStorage
function saveFOVSettings() {
    localStorage.setItem('fovSettings', JSON.stringify(fovSettings));
    localStorage.setItem('fpsSettings', JSON.stringify(fpsSettings));
}

// Update UI based on current settings
function updateUI() {
    const toggle = document.getElementById('fovToggle');
    const slider = document.getElementById('fovSlider');
    const value = document.getElementById('fov-value');
    const status = document.getElementById('fov-status');
    
    const fpsSlider = document.getElementById('fpsMultiplierSlider');
    const fpsValue = document.getElementById('fps-multiplier-value');

    toggle.checked = fovSettings.enabled;
    slider.value = fovSettings.value;
    value.textContent = fovSettings.value;
    status.textContent = fovSettings.enabled ? 'On' : 'Off';
    status.style.color = fovSettings.enabled ? '#4CAF50' : '#ff9800';
    
    if (fpsSlider) {
        fpsSlider.value = fpsSettings.multiplier;
        fpsValue.textContent = fpsSettings.multiplier;
    }
}

// Toggle FOV Changer On/Off
function toggleFOV() {
    fovSettings.enabled = document.getElementById('fovToggle').checked;
    document.getElementById('fov-status').textContent = fovSettings.enabled ? 'On' : 'Off';
    document.getElementById('fov-status').style.color = fovSettings.enabled ? '#4CAF50' : '#ff9800';
    updatePotatoMessage();
    showSuccessMessage(`🥔 FOV Changer ${fovSettings.enabled ? 'Enabled' : 'Disabled'}`);
}

// Update FOV Value from Slider
function updateFOVValue(value) {
    fovSettings.value = parseInt(value);
    document.getElementById('fov-value').textContent = value;
}

// Update FPS Multiplier from Slider
function updateFPSMultiplier(value) {
    fpsSettings.multiplier = parseInt(value);
    document.getElementById('fps-multiplier-value').textContent = value;
}

// Set FOV to Preset Values
function setFOVPreset(value) {
    fovSettings.value = value;
    document.getElementById('fovSlider').value = value;
    document.getElementById('fov-value').textContent = value;
    updatePotatoMessage();
    showSuccessMessage(`🥔 FOV set to ${value}°`);
}

// Set FPS Multiplier to Preset Values
function setFPSPreset(value) {
    fpsSettings.multiplier = value;
    document.getElementById('fpsMultiplierSlider').value = value;
    document.getElementById('fps-multiplier-value').textContent = value;
    updatePotatoMessage();
    showSuccessMessage(`⚡ FPS Multiplier set to ${value}x`);
}

// Apply FOV Settings
function applyFOVSettings() {
    saveFOVSettings();
    
    const payload = {
        bEnableFOVChanger: fovSettings.enabled,
        fovValue: fovSettings.value
    };

    console.log('Applying FOV Settings:', payload);
    updatePotatoMessage();
    showSuccessMessage(`🥔 FOV Settings Applied! (${fovSettings.value}°)`);
}

// Apply All Settings
function applyAllSettings() {
    saveFOVSettings();
    
    const payload = {
        bEnableFOVChanger: fovSettings.enabled,
        fovValue: fovSettings.value,
        fpsMultiplier: fpsSettings.multiplier
    };

    console.log('Applying All Settings:', payload);
    updatePotatoMessage();
    showSuccessMessage(`🥔⚡ All Settings Applied! (FOV: ${fovSettings.value}°, FPS: ${fpsSettings.multiplier}x)`);
}

// Reset to Default Settings
function resetFOVSettings() {
    if (confirm('🥔 Are you sure you want to reset FOV settings to default potato vision?')) {
        fovSettings = { enabled: false, value: 80 };
        saveFOVSettings();
        updateUI();
        updatePotatoMessage();
        showSuccessMessage('🥔 FOV Settings Reset to Default');
    }
}

// Reset All Settings
function resetAllSettings() {
    if (confirm('🥔⚡ Are you sure you want to reset ALL settings to default?')) {
        fovSettings = { enabled: false, value: 80 };
        fpsSettings = { multiplier: 1 };
        saveFOVSettings();
        updateUI();
        updatePotatoMessage();
        showSuccessMessage('🥔⚡ All Settings Reset to Default');
    }
}

// Show Success Message
function showSuccessMessage(message) {
    const successMsg = document.getElementById('success-message');
    const successText = document.getElementById('success-text');
    
    successText.textContent = message;
    successMsg.classList.remove('hidden');
    
    setTimeout(() => {
        successMsg.classList.add('hidden');
    }, 3000);
}

// Close Success Message
function closeSuccessMessage() {
    document.getElementById('success-message').classList.add('hidden');
}

// Close Error Message
function closeErrorMessage() {
    document.getElementById('error-message').classList.add('hidden');
}

// Show Error Message
function showErrorMessage(message) {
    const errorMsg = document.getElementById('error-message');
    const errorText = document.getElementById('error-text');
    
    errorText.textContent = message;
    errorMsg.classList.remove('hidden');
    
    setTimeout(() => {
        errorMsg.classList.add('hidden');
    }, 5000);
}

// Theme Toggle
function toggleTheme() {
    const body = document.body;
    const isDarkTheme = body.classList.contains('dark-theme');
    
    if (isDarkTheme) {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
        localStorage.setItem('theme', 'light');
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
        localStorage.setItem('theme', 'dark');
    }
}

// Initialize Theme
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    const body = document.body;
    
    if (savedTheme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
    }
}

// Export settings (for debugging)
function exportFOVSettings() {
    console.log('Current FOV Settings:', fovSettings);
    return fovSettings;
}

// Import settings (for debugging)
function importFOVSettings(settings) {
    if (settings.enabled !== undefined) fovSettings.enabled = settings.enabled;
    if (settings.value !== undefined) fovSettings.value = settings.value;
    saveFOVSettings();
    updateUI();
}
