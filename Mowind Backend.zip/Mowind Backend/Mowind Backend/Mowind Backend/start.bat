@echo off
setlocal enabledelayedexpansion
title MowindMP Backend Server
color 0A

REM Check if node_modules exists, if not install dependencies
if not exist "node_modules" (
    echo Installing dependencies...
    call npm install
    if errorlevel 1 (
        echo Error: Failed to install dependencies
        pause
        exit /b 1
    )
)

REM Check if config.json exists
if not exist "Config\config.json" (
    echo Error: Config\config.json not found!
    pause
    exit /b 1
)

echo.
if exist "backend-paused.flag" del /f /q "backend-paused.flag"
echo Starting MowindP Backend Server...
echo.
echo Hotkeys:
echo   F1 - Restart the backend
echo   F3 - Stop the backend
echo   F8 - Toggle FOV Changer
echo.

REM Start F1/F8 monitor in background
if exist "restart-monitor.ps1" (
    start /b powershell.exe -NoProfile -ExecutionPolicy Bypass -File "restart-monitor.ps1"
)

:start
REM Suppress url.parse deprecation warning and run the server
node --no-deprecation index.js
set EXIT_CODE=%ERRORLEVEL%
if "%EXIT_CODE%"=="5" (
    echo Backend stopped via F3. Waiting for restart...
    :waitForRestart
    if exist "backend-paused.flag" (
        timeout /t 1 /nobreak >nul
        goto waitForRestart
    )
    goto start
)
if "%EXIT_CODE%"=="0" (
    echo Backend stopped cleanly. Exiting.
    exit /b 0
)
echo.
echo Server crashed. Restarting in 5 seconds...
timeout /t 5 /nobreak
goto start
