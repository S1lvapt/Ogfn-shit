const { MessageEmbed } = require("discord.js");
const User = require("../../../model/user.js");
const Badwords = require("bad-words");
const functions = require("../../../structs/functions.js");

const badwords = new Badwords();

module.exports = {
    commandInfo: {
        name: "change-username",
        description: "Change your username.",
        options: [
            {
                name: "username",
                description: "Your new username.",
                required: true,
                type: 3
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        // Check for required role
        const requiredRoles = ["1469343254687383606", "1473683709017325588", "1469343254687383605", "1472556496960360553", "1472555493250695312", "1469343254687383604", "1469343254687383602", "1471194981484986470", "1486053095594004540", "1470098818224750816", "1485702232824348702", "1472555934063657080"]; // Replace with your actual role IDs
        const hasRole = interaction.member.roles.cache.some(role => requiredRoles.includes(role.id));
        
        if (!hasRole) {
            return interaction.editReply({ content: "You do not have permission to change usernames. This command requires a specific role.", ephemeral: true });
        }

        const user = await User.findOne({ discordId: interaction.user.id });
        if (!user)
            return interaction.editReply({ content: "You are not registered!", ephemeral: true });

        const username = interaction.options.getString('username');

        if (user.lastUsernameChange) {
            const twoWeeks = 14 * 24 * 60 * 60 * 1000;
            const timeElapsed = Date.now() - new Date(user.lastUsernameChange).getTime();

            if (timeElapsed < twoWeeks) {
                const timeLeft = twoWeeks - timeElapsed;
                const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
                const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));

                return interaction.editReply({
                    content: `You can only change your username once every 14 days. Please wait **${days}d ${hours}h ${minutes}m** before trying again.`,
                    ephemeral: true
                });
            }
        }

        if (badwords.isProfane(username)) {
            return interaction.editReply({ content: "Invalid username. Username must not contain inappropriate language." });
        }

        const existingUser = await User.findOne({ username_lower: username.toLowerCase() });
        if (existingUser) {
            return interaction.editReply({ content: "Username already exists. Please choose a different one.", ephemeral: true });
        }
        if (username.length > 20) {
            return interaction.editReply({ content: "Your username must be 20 characters or less.", ephemeral: true });
        }
        if (username.length < 3) {
            return interaction.editReply({ content: "Your username must be at least 3 characters long.", ephemeral: true });
        }

        await user.updateOne({ $set: { username: username, username_lower: username.toLowerCase(), lastUsernameChange: new Date() } });

        const refreshTokenIndex = global.refreshTokens.findIndex(i => i.accountId == user.accountId);
        if (refreshTokenIndex != -1) global.refreshTokens.splice(refreshTokenIndex, 1);

        const accessTokenIndex = global.accessTokens.findIndex(i => i.accountId == user.accountId);
        if (accessTokenIndex != -1) {
            global.accessTokens.splice(accessTokenIndex, 1);

            const xmppClient = global.Clients.find(client => client.accountId == user.accountId);
            if (xmppClient) xmppClient.client.close();
        }

        if (accessTokenIndex != -1 || refreshTokenIndex != -1) {
            await functions.UpdateTokens();
        }

        const embed = new MessageEmbed()
            .setTitle("Username changed")
            .setDescription(`Your account username has been changed to **${username}**.`)
            .setColor("GREEN")
            .setFooter({
                text: "MowindMP Backend",
                iconURL: "https://i.imgur.com/zfDE8wI.png",
            })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed], ephemeral: true });
    }
};