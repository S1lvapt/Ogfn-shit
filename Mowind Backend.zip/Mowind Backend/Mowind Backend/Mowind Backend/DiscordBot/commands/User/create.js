const { MessageEmbed } = require("discord.js");
const User = require("../../../model/user.js");
const functions = require("../../../structs/functions.js");
const log = require("../../../structs/log.js");
const crypto = require("crypto");

module.exports = {
    commandInfo: {
        name: "create",
        description: "Creates an account on MowindMP Backend. Discord account must be at least 5 months old.",
        options: [
            {
                name: "username",
                description: "Your username.",
                required: true,
                type: 3
            }
        ],
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        try {
            const { options } = interaction;

            const discordId = interaction.user.id;
            const username = options.get("username").value;
            const email = `${interaction.user.id}@mowindmp.dev`;
            const password = crypto.randomBytes(6).toString('hex');

            const existingDiscordUser = await User.findOne({ discordId });
            const existingUser = await User.findOne({ username_lower: username.toLowerCase() });

            if (username.length < 3) {
                return interaction.editReply({ content: "Your username must be at least 3 characters long.", ephemeral: true });
            }
            if (username.length > 20) {
                return interaction.editReply({ content: "Your username must be 20 characters or less.", ephemeral: true });
            }

            const accountAgeLimit = new Date();
            accountAgeLimit.setMonth(accountAgeLimit.getMonth() - 5);
            if (interaction.user.createdAt > accountAgeLimit) {
                return interaction.editReply({ content: "Your Discord account must be at least 5 months old to create a MowindMP account.", ephemeral: true });
            }

            if (existingDiscordUser) {
                return interaction.editReply({ content: "You already created an account!", ephemeral: true });
            }
            if (existingUser) {
                return interaction.editReply({ content: "Username already exists. Please choose a different one.", ephemeral: true });
            }

            const resp = await functions.registerUser(discordId, username, email, password);
            const isError = resp.status >= 400;

            let embed = new MessageEmbed()
                .setColor(isError ? "#ff0000" : "#56ff00")
                .addFields({
                    name: "Username",
                    value: username,
                    inline: true
                }, {
                    name: "Email",
                    value: email,
                    inline: true
                }, {
                    name: "Password",
                    value: isError ? "N/A" : `||${password}||`,
                    inline: true
                })
                .setTimestamp()
                .setFooter({
                    text: "MowindMP Backend",
                    iconURL: "https://i.imgur.com/zfDE8wI.png"
                });

            if (isError) {
                embed.addFields({
                    name: "Error",
                    value: resp.message || "An unknown error occurred.",
                    inline: false
                });

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            const userDetailsText = `Hello ${interaction.user.username}, here are your account details for MowindMP Backend:\n\n` +
                `Username: ${username}\n` +
                `Email: ${email}\n` +
                `Password: ||${password}||`;

            let dmSent = true;
            await interaction.user.send({
                content: userDetailsText
            }).catch(() => {
                dmSent = false;
            });

            const replyContent = dmSent
                ? "Account created successfully! I have also sent your details to your DMs."
                : "Account created successfully! (⚠️ Note: I couldn't DM you, please make sure your DMs are open next time)";

            return interaction.editReply({ content: replyContent, ephemeral: true });
        } catch (error) {
            log.error(error);
            return interaction.editReply({ content: "An error occurred while creating your account. Please try again later.", ephemeral: true });
        }
    }
};