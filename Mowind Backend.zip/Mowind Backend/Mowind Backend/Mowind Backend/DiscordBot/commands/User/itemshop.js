const { MessageEmbed } = require("discord.js");
const functions = require("../../../structs/functions.js");

module.exports = {
    commandInfo: {
        name: "itemshop",
        description: "View the current Item Shop"
    },
    execute: async (interaction) => {
        await interaction.deferReply();

        try {
            const catalog = functions.getItemShop();
            const storefronts = catalog.storefronts || [];

            const sectionMap = {
                BRSeasonStorefront: "Featured",
                BRWeeklyStorefront: "Weekly",
                BRDailyStorefront: "Daily"
            };

            const fetch = require("node-fetch");
            const embeds = [];

            for (const storefrontName of ["BRWeeklyStorefront", "BRDailyStorefront"]) {
                const storefront = storefronts.find(s => s.name === storefrontName);
                if (!storefront || !Array.isArray(storefront.catalogEntries)) continue;

                const items = storefront.catalogEntries.filter(hasMtxPrice).slice(0, 10);
                if (items.length === 0) continue;

                for (const item of items) {
                    const itemName = getItemName(item);
                    const price = getItemPrice(item);
                    let imageUrl = null;
                    try {
                        const response = await fetch(`https://fortnite-api.com/v2/cosmetics/br/search?name=${encodeURIComponent(itemName)}`);
                        const json = await response.json();
                        imageUrl = json?.data?.images?.icon || null;
                    } catch (e) {
                        imageUrl = null;
                    }
                    const embed = new MessageEmbed()
                        .setTitle(`${sectionMap[storefrontName]}: ${itemName}`)
                        .setDescription(`**${price !== null ? `${price} V-Bucks` : "N/A"}**`)
                        .setColor(storefrontName === "BRSeasonStorefront" ? "GOLD" : storefrontName === "BRWeeklyStorefront" ? "BLUE" : "BLURPLE")
                        .setFooter({ text: "MowindMP Item Shop", iconURL: "https://i.imgur.com/zfDE8wI.png" })
                        .setTimestamp();
                    if (imageUrl) {
                        embed.setImage(imageUrl);
                    }
                    embeds.push(embed);
                }
            }

            if (embeds.length === 0) {
                const emptyEmbed = new MessageEmbed()
                    .setTitle("Item Shop")
                    .setDescription("No V-Bucks items currently available in the shop.")
                    .setColor("RED")
                    .setFooter({ text: "MowindMP Item Shop", iconURL: "https://i.imgur.com/zfDE8wI.png" });

                return interaction.editReply({ embeds: [emptyEmbed] });
            }

            return interaction.editReply({ embeds });
        } catch (error) {
            console.error(error);
            const errorEmbed = new MessageEmbed()
                .setTitle("Error")
                .setDescription("An error occurred while loading the item shop. Please try again later.")
                .setColor("RED")
                .setFooter({ text: "MowindMP Item Shop", iconURL: "https://i.imgur.com/zfDE8wI.png" });

            return interaction.editReply({ embeds: [errorEmbed] });
        }
    }
};

function hasMtxPrice(item) {
    return Array.isArray(item.prices) && item.prices.some(price => price.currencyType === "MtxCurrency");
}

function getItemPrice(item) {
    const priceEntry = (item.prices || []).find(price => price.currencyType === "MtxCurrency");
    if (priceEntry && typeof priceEntry.finalPrice === "number") {
        return priceEntry.finalPrice;
    }
    if (typeof item.price === "number") {
        return item.price;
    }
    return null;
}

function getItemName(item) {
    if (!item || typeof item !== "object") return "Unknown Item";

    const itemGrant = item.itemGrants?.[0];
    const templateId = typeof itemGrant === "object" ? itemGrant.templateId : itemGrant;

    if (typeof item.devName === "string" && item.devName.length) {
        const match = /\[VIRTUAL\]\d+ x (.+?) for \d+/i.exec(item.devName);
        if (match && match[1]) {
            return match[1].trim();
        }

        const isHash = /^[a-f0-9]{40}$/i.test(item.devName);
        if (isHash && typeof templateId === "string" && templateId.length) {
            const idPart = templateId.split(":").pop();
            return idPart.replace(/_/g, " ").trim();
        }

        return item.devName;
    }

    if (typeof templateId === "string" && templateId.length) {
        const idPart = templateId.split(":").pop();
        return idPart.replace(/_/g, " ").trim();
    }

    return "Unknown Item";
}
