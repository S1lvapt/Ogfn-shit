const User = require("../../../model/user.js");
const Profiles = require('../../../model/profiles.js');

module.exports = {
    commandInfo: {
        name: "details",
        description: "Retrieves your account info."
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const user = await User.findOne({ discordId: interaction.user.id }).lean();
        const vbucksamount = await Profiles.findOne({ accountId: user?.accountId });
        const currency = vbucksamount?.profiles.common_core.items["Currency:MtxPurchased"].quantity;
        if (!user) return interaction.editReply({ content: "You do not have a registered account!", ephemeral: true });

        let onlineStatus = global.Clients.some(i => i.accountId == user.accountId);

        const detailsText = `Your account details:\n\n` +
            `Username: ${user.username}\n` +
            `Email: ${user.email}\n` +
            `Online: ${onlineStatus ? "Yes" : "No"}\n` +
            `Banned: ${user.banned ? "Yes" : "No"}\n` +
            `V-Bucks: ${currency} V-Bucks\n` +
            `Account ID: ${user.accountId}`;

        interaction.editReply({ content: detailsText, ephemeral: true });
    }
}