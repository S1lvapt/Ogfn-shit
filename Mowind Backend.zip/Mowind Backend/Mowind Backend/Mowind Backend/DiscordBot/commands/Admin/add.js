const { MessageEmbed } = require("discord.js");
const path = require("path");
const fs = require("fs");
const Users = require('../../../model/user.js');
const Profiles = require('../../../model/profiles.js');
const log = require("../../../structs/log.js");
const destr = require("destr");
const config = require('../../../Config/config.json');
const uuid = require("uuid");
const functions = require("../../../structs/functions.js");


module.exports = {
    commandInfo: {
        name: "add",
        description: "Allows you to give a user specific cosmetic packs or V-Bucks.",
        options: [
            {
                name: "pack",
                description: "The pack or currency you want to give",
                required: true,
                type: 3,
                choices: [
                    { name: "Full Locker", value: "full" },
                    { name: "Dev Locker", value: "dev" },
                    { name: "Sweater Pack", value: "sweater" },
                    { name: "V-Bucks", value: "vbucks" },
                    { name: "Single Item", value: "item" }
                    
                ]
            },
            {
                name: "user",
                description: "The user you want to give the pack to",
                required: true,
                type: 6
            },
            {
                name: "amount",
                description: "The amount of V-Bucks to give (required if V-Bucks is selected)",
                required: false,
                type: 4
            },
            {
                name: "itemname",
                description: "The name of the item to give (required if Single Item is selected)",
                required: false,
                type: 3
            }
        ]
    },
    execute: async (interaction) => {
        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.reply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        try {
            await interaction.deferReply({ ephemeral: true });
        } catch (err) {
            log.error("Failed to defer interaction reply", err);
            // This can happen if the interaction token has expired / is unknown.
            // There's nothing we can do in that case, so just stop processing.
            return;
        }

        const pack = interaction.options.getString('pack');
        const selectedUser = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');
        const itemname = interaction.options.getString('itemname');
        const selectedUserId = selectedUser?.id;

        try {
            const targetUser = await Users.findOne({ discordId: selectedUserId });
            if (!targetUser) {
                return interaction.editReply({ content: "That user does not own an account" });
            }

            const profile = await Profiles.findOne({ accountId: targetUser.accountId });
            if (!profile) {
                return interaction.editReply({ content: "That user does not have a profile" });
            }

            if (pack === "item") {
                if (!itemname) {
                    return interaction.editReply({ content: "Please provide an item name." });
                }

                const response = await fetch(`https://fortnite-api.com/v2/cosmetics/br/search?name=${encodeURIComponent(itemname)}`);
                const json = await response.json();

                if (json.status !== 200 || !json.data) {
                    return interaction.editReply({ content: `Could not find the item "${itemname}".` });
                }

                const itemData = json.data;
                const allItems = destr(fs.readFileSync(path.join(__dirname, "../../../Config/DefaultProfiles/allathena.json"), 'utf8'));
                const allItemKeys = Object.keys(allItems.items);

                const foundKey = allItemKeys.find(key => key.toLowerCase().includes(itemData.id.toLowerCase()));

                if (!foundKey) {
                    return interaction.editReply({ content: `Item "${itemData.name}" found on API but not in backend database.` });
                }

                const cosmetic = allItems.items[foundKey];
                const athena = profile.profiles.athena;
                const common_core = profile.profiles.common_core;

                athena.items[foundKey] = cosmetic;

                const purchaseId = uuid.v4();
                common_core.items[purchaseId] = {
                    "templateId": `GiftBox:GB_MakeGood`,
                    "attributes": {
                        "fromAccountId": `[Administrator]`,
                        "lootList": [{
                            "itemType": cosmetic.templateId,
                            "itemGuid": cosmetic.templateId,
                            "quantity": 1
                        }],
                        "params": {
                            "userMessage": `Gifted ${itemData.name} from MowindMP Backend!`
                        },
                        "giftedOn": new Date().toISOString()
                    },
                    "quantity": 1
                };

                common_core.rvn += 1;
                common_core.commandRevision += 1;
                athena.rvn += 1;
                athena.commandRevision += 1;

                await Profiles.updateOne(
                    { accountId: targetUser.accountId },
                    { $set: { "profiles.athena": athena, "profiles.common_core": common_core } }
                );




                const embed = new MessageEmbed()
                    .setTitle("Item Granted")
                    .setDescription(`Successfully gave **${itemData.name}** to **${selectedUser.username}** via GiftBox.`)
                    .setThumbnail(itemData.images.icon)
                    .setColor("GREEN")
                    .setFooter({ text: "MowindMP Backend", iconURL: "https://i.imgur.com/zfDE8wI.png" })
                    .setTimestamp();

                return await interaction.editReply({ embeds: [embed] });
            }

            if (pack === "vbucks") {
                if (!amount || amount <= 0) {
                    return interaction.editReply({ content: "Please provide a valid V-Bucks amount." });
                }

                const common_core = profile.profiles["common_core"];
                const profile0 = profile.profiles["profile0"];

                if (!common_core.items["Currency:MtxPurchased"]) {
                    common_core.items["Currency:MtxPurchased"] = { templateId: "Currency:MtxPurchased", quantity: 0, attributes: {} };
                }
                if (!profile0.items["Currency:MtxPurchased"]) {
                    profile0.items["Currency:MtxPurchased"] = { templateId: "Currency:MtxPurchased", quantity: 0, attributes: {} };
                }

                common_core.items["Currency:MtxPurchased"].quantity += amount;
                profile0.items["Currency:MtxPurchased"].quantity += amount;

                const purchaseId = uuid.v4();
                common_core.items[purchaseId] = {
                    "templateId": `GiftBox:GB_MakeGood`,
                    "attributes": {
                        "fromAccountId": `[Administrator]`,
                        "lootList": [{
                            "itemType": "Currency:MtxGiveaway",
                            "itemGuid": "Currency:MtxGiveaway",
                            "quantity": amount
                        }],
                        "params": {
                            "userMessage": `Gifted V-Bucks from MowindMP Backend!`
                        },
                        "giftedOn": new Date().toISOString()
                    },
                    "quantity": 1
                };

                common_core.rvn += 1;
                common_core.commandRevision += 1;
                common_core.updated = new Date().toISOString();

                await Profiles.updateOne(
                    { accountId: targetUser.accountId },
                    {
                        $set: {
                            'profiles.common_core': common_core,
                            'profiles.profile0.items.Currency:MtxPurchased.quantity': profile0.items["Currency:MtxPurchased"].quantity
                        }
                    }
                );

                const embed = new MessageEmbed()
                    .setTitle("V-Bucks Added")
                    .setDescription(`Successfully added **${amount.toLocaleString()}** V-Bucks to **${selectedUser.username}**'s account.`)
                    .setThumbnail("https://i.imgur.com/yLbihQa.png")
                    .setColor("GREEN")
                    .setFooter({
                        text: "MowindMP Backend",
                        iconURL: "https://i.imgur.com/zfDE8wI.png"
                    })
                    .setTimestamp();

                return await interaction.editReply({ embeds: [embed] });
            }

            const allItems = destr(fs.readFileSync(path.join(__dirname, "../../../Config/DefaultProfiles/allathena.json"), 'utf8'));
            if (!allItems) {
                return interaction.editReply({ content: "Failed to parse allathena.json" });
            }

            let itemsToGive = {};

            if (pack === "full") {
                itemsToGive = allItems.items;

                let loadouts = {};
                const currentItems = profile.profiles.athena.items || {};

                for (const key in currentItems) {
                    if (key.includes("loadout") || (currentItems[key].templateId && currentItems[key].templateId.startsWith("CosmeticLocker:"))) {
                        loadouts[key] = currentItems[key];
                    }
                }

                if (Object.keys(loadouts).length === 0) {
                    try {
                        const defaultAthena = destr(fs.readFileSync(path.join(__dirname, "../../../Config/DefaultProfiles/athena.json"), 'utf8'));
                        if (defaultAthena && defaultAthena.items) {
                            for (const key in defaultAthena.items) {
                                if (key.includes("loadout") || (defaultAthena.items[key].templateId && defaultAthena.items[key].templateId.startsWith("CosmeticLocker:"))) {
                                    loadouts[key] = defaultAthena.items[key];
                                }
                            }
                        }
                    } catch (e) {
                        log.error("Failed to read default athena.json for loadout restoration", e);
                    }
                }

                itemsToGive = { ...itemsToGive, ...loadouts };
            } else if (pack === "og") {
                const ogIds = [
                    "AthenaCharacter:CID_039_Athena_Commando_F_Disco",
                    "AthenaCharacter:CID_035_Athena_Commando_M_Medieval",
                    "AthenaCharacter:CID_032_Athena_Commando_M_Medieval",
                    "AthenaCharacter:CID_033_Athena_Commando_F_Medieval",
                    "AthenaCharacter:CID_032_Athena_Commando_F_Medieval",
                    "AthenaCharacter:CID_028_Athena_Commando_F",
                    "AthenaCharacter:CID_017_Athena_Commando_M",
                    "AthenaCharacter:CID_030_Athena_Commando_M_Halloween",
                    "AthenaCharacter:CID_029_Athena_Commando_F_Halloween",
                    "AthenaPickaxe:Pickaxe_Lockjaw",
                    "AthenaPickaxe:Pickaxe_ID_013_Teslacoil",
                    "AthenaGlider:Glider_Warthog",
                    "AthenaGlider:Umbrella_Snowflake",
                    "AthenaDance:EID_Floss",
                    "AthenaDance:EID_TakeTheL",
                    "AthenaDance:EID_BestMates",
                    "AthenaDance:EID_Hype",
                    "AthenaDance:EID_GoodVibes",
                    "AthenaDance:EID_RideThePony_Athena",
                    "AthenaCharacter:CID_037_Athena_Commando_F_WinterCamo",
                    "AthenaCharacter:CID_041_Athena_Commando_F_District",
                    "AthenaCharacter:CID_096_Athena_Commando_F_Founder",
                    "AthenaCharacter:CID_070_Athena_Commando_M_Cupid",
                    "AthenaDance:EID_ElectroShuffle",
                    "AthenaDance:EID_Fresh",
                    "AthenaDance:EID_FingerGuns",
                    "AthenaDance:EID_Celebration",
                    "AthenaPickaxe:Pickaxe_ID_015_HolidayCandyCane",
                    "AthenaPickaxe:Pickaxe_ID_014_WinterCamo",
                    "AthenaPickaxe:Pickaxe_HalloweenScythe",
                    "AthenaPickaxe:Pickaxe_ID_031_Squeak",
                    "AthenaGlider:Glider_ID_004_Disco",
                    "AthenaGlider:Glider_ID_025_ShuttleA",
                    "AthenaBannerIcon:BID_004_BlackKnight",
                    "AthenaBannerIcon:BID_038_BunnyFemale",
                    "AthenaMusicPack:LSID_008_KeyArt"
                ];

                const allItemKeys = Object.keys(allItems.items);
                for (const id of ogIds) {
                    const foundKey = allItemKeys.find(key => key.toLowerCase() === id.toLowerCase());
                    if (foundKey) {
                        itemsToGive[foundKey] = allItems.items[foundKey];
                    }
                }

                itemsToGive = { ...profile.profiles.athena.items, ...itemsToGive };
            } else if (pack === "sweat") {
                const sweaterIds = [
                    "AthenaPickaxe:Pickaxe_ID_179_StarWand",
                    "AthenaPickaxe:Pickaxe_ID_215_Pug",
                    "AthenaPickaxe:Pickaxe_ID_294_CandyCane",
                    "AthenaPickaxe:Pickaxe_ID_190_GolfClub",
                    "AthenaPickaxe:Pickaxe_ID_140_StreetGoth",
                    "AthenaPickaxe:Pickaxe_ID_138_Gnome",
                    "AthenaPickaxe:Pickaxe_ID_014_WinterCamo",
                    "AthenaCharacter:CID_683_Athena_Commando_F_TigerFashion",
                    "AthenaCharacter:CID_527_Athena_Commando_F_StreetFashionRed",
                    "AthenaCharacter:CID_362_Athena_Commando_F_BandageNinja",
                    "AthenaCharacter:CID_703_Athena_Commando_M_Cyclone",
                    "AthenaCharacter:CID_715_Athena_Commando_F_TwinDark",
                    "AthenaCharacter:CID_715_Athena_Commando_F_TwinDark",
                    "AthenaCharacter:CID_674_Athena_Commando_F_HoodieBandit",
                ];

                const allItemKeys = Object.keys(allItems.items);
                for (const id of sweaterIds) {
                    const foundKey = allItemKeys.find(key => key.toLowerCase() === id.toLowerCase());
                    if (foundKey) {
                        itemsToGive[foundKey] = allItems.items[foundKey];
                    }
                }

                itemsToGive = { ...profile.profiles.athena.items, ...itemsToGive };
            }

            await Profiles.updateOne(
                { accountId: targetUser.accountId },
                { $set: { "profiles.athena.items": itemsToGive } }
            );




            const packName = pack === "full" ? "Full Locker" : pack === "og" ? "OG Pack" : pack === "sweat" ? "Sweat Pack" : pack;

            const embed = new MessageEmbed()
                .setTitle(`${packName} Added`)
                .setDescription(`Successfully added the **${packName}** to **${selectedUser.username}**'s account.`)
                .setColor("GREEN")
                .setFooter({
                    text: "MowindMP Backend",
                    iconURL: "https://i.imgur.com/zfDE8wI.png"
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            log.error("An error occurred:", error);
            try {
                await interaction.editReply({ content: "An error occurred while processing the request." });
            } catch (err) {
                // If we can't reply (e.g., interaction expired), ignore the error.
            }
        }
    }
};
