const Users = require('../../../model/user');
const config = require('../../../Config/config.json');
const functions = require('../../../structs/functions.js');
const { MessageEmbed } = require("discord.js");
const { subtractCommandHypePoints, subtractCommandHypePointsFromAll } = require("../../../structs/rawHype.js");

module.exports = {
    commandInfo: {
        name: "subtracthype",
        description: "Subtracts Hype points from a user or everyone",
        options: [
            {
                name: "hype",
                description: "Amount of points to subtract (1-10000)",
                required: true,
                type: 4,
                min_value: 1,
                max_value: 10000
            },
            {
                name: "user",
                description: "The user you want to remove Hype from",
                required: false,
                type: 6
            },
            {
                name: "all",
                description: "Remove hype from every user",
                required: false,
                type: 5
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        const selectedUser = interaction.options.getUser('user');
        const selectedUserId = selectedUser?.id;
        const removeEveryone = interaction.options.getBoolean('all') || false;
        const hype = interaction.options.getInteger('hype');

        if (!hype || hype < 1 || hype > 10000) {
            return interaction.editReply({ content: "Hype amount must be between 1 and 10000.", ephemeral: true });
        }

        if (removeEveryone) {
            const totalUpdated = await subtractCommandHypePointsFromAll(hype);

            const embed = new MessageEmbed()
                .setTitle("Hype Subtracted ⬇️")
                .setDescription(`Subtracted **${hype}** Hype point${hype !== 1 ? 's' : ''} from everyone.\n**Accounts updated:** ${totalUpdated}`)
                .setColor("RED")
                .setThumbnail("https://i.imgur.com/LJHibSW.png")
                .setFooter({ text: "MowindMP", iconURL: "https://i.imgur.com/2RImwlb.png" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }

        if (!selectedUserId) {
            return interaction.editReply({ content: "Please select a user or use the all option.", ephemeral: true });
        }

        const user = await Users.findOne({ discordId: selectedUserId }).lean();
        if (!user) {
            return interaction.editReply({ content: "That user does not own an account.", ephemeral: true });
        }

        await subtractCommandHypePoints(user, hype);

        const totalPoints = await functions.calculateTotalHypePoints(user);

        const embed = new MessageEmbed()
            .setTitle("Hype Subtracted ⬇️")
            .setDescription(`Subtracted **${hype}** Hype point${hype !== 1 ? 's' : ''} from <@${selectedUserId}>.\n**Updated total:** ${totalPoints}`)
            .setColor("RED")
            .setThumbnail("https://i.imgur.com/LJHibSW.png")
            .setFooter({ text: "MowindMP", iconURL: "https://i.imgur.com/2RImwlb.png" })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed], ephemeral: true });
    }
};
