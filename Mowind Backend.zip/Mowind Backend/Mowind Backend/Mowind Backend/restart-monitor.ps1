# Monitor for F1 (restart) and F8 (FOV Changer toggle) key presses
Add-Type -AssemblyName System.Windows.Forms

Write-Host "Hotkey Monitor started:" -ForegroundColor Green
Write-Host "  - Press F8 to toggle FOV Changer" -ForegroundColor Green
Write-Host ""

$configPath = "./Config/config.json"
$pauseFile = "./backend-paused.flag"

function Toggle-FOVChanger {
    try {
        if (Test-Path $configPath) {
            $config = Get-Content $configPath | ConvertFrom-Json
            
            # Check if FOVChanger property exists, if not create it
            if (-not ($config | Get-Member -Name "bEnableFOVChanger" -ErrorAction SilentlyContinue)) {
                $config | Add-Member -NotePropertyName "bEnableFOVChanger" -NotePropertyValue $true
            }
            
            # Toggle the value
            $config.bEnableFOVChanger = -not $config.bEnableFOVChanger
            $newValue = $config.bEnableFOVChanger
            
            # Save the config
            $config | ConvertTo-Json -Depth 10 | Set-Content $configPath
            
            Write-Host "F8 pressed - FOV Changer toggled: $newValue" -ForegroundColor Cyan
            return $true
        }
        else {
            Write-Host "F8 pressed - Error: config.json not found" -ForegroundColor Red
            return $false
        }
    }
    catch {
        Write-Host "F8 pressed - Error toggling FOV Changer: $_" -ForegroundColor Red
        return $false
    }
}

function Restart-Backend {
    Write-Host "F1 pressed - Restarting backend..." -ForegroundColor Yellow
    if (Test-Path $pauseFile) {
        Remove-Item $pauseFile -Force -ErrorAction SilentlyContinue
        Write-Host "Backend restart flag cleared." -ForegroundColor Yellow
    }
    $nodeProcess = Get-Process -Name "node" -ErrorAction SilentlyContinue
    if ($nodeProcess) {
        Stop-Process -Name "node" -Force
        Write-Host "Backend process stopped. Restart in progress..." -ForegroundColor Yellow
    }
}

try {
    while ($true) {
        if ([Console]::KeyAvailable) {
            $key = [System.Console]::ReadKey($true)
            
            if ($key.Key -eq [System.ConsoleKey]::F8) {
                Toggle-FOVChanger
            }
        }
        Start-Sleep -Milliseconds 100
    }
}
catch {
    Write-Host "Error in hotkey monitor: $_" -ForegroundColor Red
}

