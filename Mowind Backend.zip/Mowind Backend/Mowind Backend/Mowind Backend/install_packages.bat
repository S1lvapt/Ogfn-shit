@echo off
title MowindMP Package Installer

npm i
npm install express
npm install ws
pause