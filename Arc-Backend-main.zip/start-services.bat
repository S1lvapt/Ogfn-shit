@echo off
setlocal

set ARC_SIGNING_KEY=677777
set ARC_ADMIN_KEY=67777

set BASE_DIR=%USERPROFILE%\Downloads\Arc-Backend-main

echo Starting Arc...

start "account" cmd /c "cd /d %BASE_DIR%\services\account && go run main.go"
start "anticheat" cmd /c "cd /d %BASE_DIR%\services\anticheat && go run main.go"
start "auth" cmd /c "cd /d %BASE_DIR%\services\auth && go run main.go"
start "internal" cmd /c "cd /d %BASE_DIR%\services\internal && go run main.go"
start "management" cmd /c "cd /d %BASE_DIR%\services\management && go run main.go"

echo All services launched.
pause