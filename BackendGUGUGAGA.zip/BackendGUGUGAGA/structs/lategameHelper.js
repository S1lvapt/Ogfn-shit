/**
 * Late Game Arena Helper
 * Handles late game playlist configurations and loadouts
 */

const fs = require('fs');
const path = require('path');
const log = require('./log.js');

class LateGameHelper {
    constructor() {
        this.config = null;
        this.loadConfig();
    }

    /**
     * Load late game configuration
     */
    loadConfig() {
        try {
            const configPath = path.join(__dirname, '../Config/lategame_config.json');
            if (fs.existsSync(configPath)) {
                const rawConfig = fs.readFileSync(configPath, 'utf8');
                this.config = JSON.parse(rawConfig);
                log.debug('Late Game configuration loaded successfully');
            } else {
                log.error('Late Game configuration file not found');
                this.config = { lateGamePlaylists: {} };
            }
        } catch (err) {
            log.error('Error loading Late Game configuration:', err);
            this.config = { lateGamePlaylists: {} };
        }
    }

    /**
     * Reload configuration from disk
     */
    reloadConfig() {
        this.loadConfig();
    }

    /**
     * Check if playlist is a late game playlist
     * @param {string} playlistId
     * @returns {boolean}
     */
    isLateGamePlaylist(playlistId) {
        if (!this.config || !this.config.lateGamePlaylists) return false;
        const normalizedId = playlistId.toLowerCase();
        return normalizedId in this.config.lateGamePlaylists;
    }

    /**
     * Get late game configuration for a playlist
     * @param {string} playlistId
     * @returns {Object|null}
     */
    getLateGameConfig(playlistId) {
        if (!this.isLateGamePlaylist(playlistId)) return null;
        const normalizedId = playlistId.toLowerCase();
        return this.config.lateGamePlaylists[normalizedId];
    }

    /**
     * Get random loadout for a late game playlist
     * @param {string} playlistId
     * @returns {Object|null}
     */
    getRandomLoadout(playlistId) {
        const config = this.getLateGameConfig(playlistId);
        if (!config || !config.loadouts || config.loadouts.length === 0) return null;

        const randomIndex = Math.floor(Math.random() * config.loadouts.length);
        return config.loadouts[randomIndex];
    }

    /**
     * Get storm configuration for a late game playlist
     * @param {string} playlistId
     * @returns {Object|null}
     */
    getStormConfig(playlistId) {
        const config = this.getLateGameConfig(playlistId);
        if (!config || !config.stormConfig) return null;
        return config.stormConfig;
    }

    /**
     * Get scoring configuration for a late game playlist
     * @param {string} playlistId
     * @returns {Object|null}
     */
    getScoringConfig(playlistId) {
        const config = this.getLateGameConfig(playlistId);
        if (!config || !config.scoring) return null;
        return config.scoring;
    }

    /**
     * Calculate placement points based on placement
     * @param {string} playlistId
     * @param {number} placement
     * @returns {number}
     */
    calculatePlacementPoints(playlistId, placement) {
        const scoring = this.getScoringConfig(playlistId);
        if (!scoring || !scoring.placementPoints) return 0;

        const placementPoints = scoring.placementPoints;

        // Check exact placement
        if (placementPoints[placement.toString()]) {
            return placementPoints[placement.toString()];
        }

        // Check ranges (e.g., "2-5", "6-10")
        for (const range in placementPoints) {
            if (range.includes('-')) {
                const [min, max] = range.split('-').map(Number);
                if (placement >= min && placement <= max) {
                    return placementPoints[range];
                }
            }
        }

        return 0;
    }

    /**
     * Get all available late game playlists
     * @returns {Array}
     */
    getAllLateGamePlaylists() {
        if (!this.config || !this.config.lateGamePlaylists) return [];

        return Object.keys(this.config.lateGamePlaylists).map(playlistId => ({
            playlistId: playlistId,
            ...this.config.lateGamePlaylists[playlistId]
        }));
    }

    /**
     * Format loadout for client
     * @param {Object} loadout
     * @returns {Object}
     */
    formatLoadoutForClient(loadout) {
        if (!loadout) return null;

        return {
            loadoutId: loadout.loadoutId,
            items: [
                ...(loadout.weapons || []),
                ...(loadout.consumables || [])
            ],
            materials: loadout.materials || {
                wood: 0,
                stone: 0,
                metal: 0
            }
        };
    }

    /**
     * Get max players for a late game playlist
     * @param {string} playlistId
     * @returns {number}
     */
    getMaxPlayers(playlistId) {
        const config = this.getLateGameConfig(playlistId);
        if (!config) return 100;
        return config.maxPlayers || 100;
    }

    /**
     * Get match settings for a late game playlist
     * @param {string} playlistId
     * @returns {Object|null}
     */
    getMatchSettings(playlistId) {
        const config = this.getLateGameConfig(playlistId);
        if (!config || !config.matchSettings) return null;
        return config.matchSettings;
    }

    /**
     * Validate late game configuration
     * @returns {Object} { valid: boolean, errors: Array }
     */
    validateConfig() {
        const errors = [];

        if (!this.config || !this.config.lateGamePlaylists) {
            errors.push('Configuration is missing or invalid');
            return { valid: false, errors };
        }

        for (const playlistId in this.config.lateGamePlaylists) {
            const playlist = this.config.lateGamePlaylists[playlistId];

            if (!playlist.playlistName) {
                errors.push(`Playlist ${playlistId} is missing playlistName`);
            }

            if (!playlist.stormConfig) {
                errors.push(`Playlist ${playlistId} is missing stormConfig`);
            }

            if (!playlist.loadouts || playlist.loadouts.length === 0) {
                errors.push(`Playlist ${playlistId} has no loadouts`);
            }

            if (!playlist.scoring) {
                errors.push(`Playlist ${playlistId} is missing scoring config`);
            }
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }
}

// Create singleton instance
const lateGameHelper = new LateGameHelper();

module.exports = lateGameHelper;
