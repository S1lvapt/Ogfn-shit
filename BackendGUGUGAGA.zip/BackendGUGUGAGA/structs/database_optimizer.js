/**
 * Database Optimizer
 * Creates indexes and optimizes MongoDB for better performance
 */

const log = require("./log.js");

class DatabaseOptimizer {
    /**
     * Initialize database indexes for optimal performance
     * @param {mongoose.Connection} connection - Mongoose connection
     */
    static async createIndexes(connection) {
        try {
         

            const db = connection.db;

            // Helper function to create index safely
            const createIndexSafely = async (collection, indexSpec, options, collectionName) => {
                try {
                    await db.collection(collection).createIndex(indexSpec, options);
                } catch (error) {
                    // Ignore if index already exists (error code 86 or 85)
                    if (error.code !== 86 && error.code !== 85) {
                    }
                }
            };

            // Profiles indexes (skip accountId as it already exists with unique)
            // await createIndexSafely('profiles', { accountId: 1 }, { background: true }, 'profiles');
            
            // Gamemodes indexes
            await createIndexSafely('gamemodes', { isActive: 1, createdAt: -1 }, { background: true }, 'gamemodes');
            await createIndexSafely('gamemodes', { gamemodeId: 1, isActive: 1 }, { background: true }, 'gamemodes');
            await createIndexSafely('gamemodes', { category: 1, isActive: 1 }, { background: true }, 'gamemodes');
          

            // Playlists indexes
            await createIndexSafely('playlists', { isActive: 1, isVisible: 1, displayPriority: -1 }, { background: true }, 'playlists');
            await createIndexSafely('playlists', { playlistId: 1, isActive: 1 }, { background: true }, 'playlists');
            await createIndexSafely('playlists', { playlistType: 1, isActive: 1 }, { background: true }, 'playlists');
            await createIndexSafely('playlists', { displayPriority: -1 }, { background: true }, 'playlists');
           

            // User indexes (skip accountId, email, discordId as they likely already exist)
            await createIndexSafely('users', { matchmakingId: 1 }, { background: true, sparse: true }, 'users');
           

            // Friends indexes
            await createIndexSafely('friends', { accountId: 1 }, { background: true }, 'friends');
          

        } catch (error) {
           
            console.error(error);
        }
    }

    /**
     * Get database statistics
     * @param {mongoose.Connection} connection - Mongoose connection
     */
    static async getStats(connection) {
        try {
            const db = connection.db;
            const collections = ['profiles', 'gamemodes', 'playlists', 'users'];

        

            for (const collectionName of collections) {
                try {
                    const stats = await db.collection(collectionName).stats();
                    const indexes = await db.collection(collectionName).indexes();

         
                } catch (err) {
                    // Collection might not exist yet
                }
            }

        } catch (error) {
          
        }
    }

    /**
     * Optimize connection pool settings
     * Returns optimized MongoDB connection options
     */
    static getOptimizedConnectionOptions() {
        return {
            maxPoolSize: 50, // Increased from 20
            minPoolSize: 10, // Increased from 5
            socketTimeoutMS: 45000, // Increased from 30000
            serverSelectionTimeoutMS: 10000,
            heartbeatFrequencyMS: 10000,
            maxIdleTimeMS: 60000,
            retryWrites: true,
            retryReads: true,
            compressors: ['zlib'] // Enable compression
        };
    }
}

module.exports = DatabaseOptimizer;
