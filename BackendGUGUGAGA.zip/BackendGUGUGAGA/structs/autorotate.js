const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('../Config');
const log = require("./log.js");
const SmartShopAI = require('./smart_shop_ai.js');
const { Client, Intents, TextChannel } = require('discord.js');

let puppeteer = null;
let puppeteerAvailable = false;

try {
    puppeteer = require('puppeteer');
    puppeteerAvailable = true;
} catch (e) {
    puppeteerAvailable = false;
}

let FormData = null;
try {
    FormData = require('form-data');
} catch (e) {
    FormData = null;
}

const catalogcfg = path.join(__dirname, "..", 'Config', 'catalog_config.json');
const webhook = config.bItemShopWebhook;
const chapterlimit = config.bChapterlimit;
const seasonlimit = config.bSeasonlimit;
const shopAI = new SmartShopAI(config);

function updateCatalogConfig(shop) {
    const catalogConfig = { "//": "BR Item Shop Config" };

    shop.featured.forEach((item, index) => {
        catalogConfig[`featured${index + 1}`] = {
            itemGrants: shopAI.formatItemGrants(item),
            price: shopAI.calculatePrice(item)
        };
    });

    shop.daily.forEach((item, index) => {
        catalogConfig[`daily${index + 1}`] = {
            itemGrants: shopAI.formatItemGrants(item),
            price: shopAI.calculatePrice(item)
        };
    });

    shop.weekly.forEach((item, index) => {
        catalogConfig[`weekly${index + 1}`] = {
            itemGrants: shopAI.formatItemGrants(item),
            price: shopAI.calculatePrice(item)
        };
    });

    fs.writeFileSync(catalogcfg, JSON.stringify(catalogConfig, null, 2), 'utf-8');
}

async function fetchItemIcon(itemName) {
    try {
        const response = await axios.get(
            `https://fortnite-api.com/v2/cosmetics/br/search?name=${encodeURIComponent(itemName)}`,
            { timeout: 10000 }
        );

        if (response.data && response.data.data && response.data.data.images) {
            return response.data.data.images.smallIcon || response.data.data.images.icon;
        }

        return null;
    } catch (error) {
        return null;
    }
}

async function renderShopHtmlImage(itemShop) {
    const { createCanvas, loadImage, registerFont } = require('canvas');

    // Register Burbank font if available
    const fontPath = path.join(__dirname, '..', 'Website', 'Data', 'fonts', 'Burbank Big Condensed Black.ttf');
    try {
        if (fs.existsSync(fontPath)) registerFont(fontPath, { family: 'Burbank', weight: '900' });
    } catch(e) {}

    const COLS = 6;
    const CARD_W = 180;
    const CARD_H = 240;
    const PAD = 14;
    const HEADER_H = 90;
    const SECTION_LABEL_H = 36;

    const allSections = [
        { label: 'FEATURED', items: itemShop.featured || [] },
        { label: 'DAILY', items: itemShop.daily || [] },
        { label: 'WEEKLY', items: itemShop.weekly || [] },
    ].filter(s => s.items.length > 0);

    // Calculate total height
    let totalH = HEADER_H + PAD;
    for (const sec of allSections) {
        const rows = Math.ceil(sec.items.length / COLS);
        totalH += SECTION_LABEL_H + rows * (CARD_H + PAD) + PAD * 2;
    }
    totalH += PAD;

    const totalW = COLS * (CARD_W + PAD) + PAD;

    const canvas = createCanvas(totalW, totalH);
    const ctx = canvas.getContext('2d');

    // Background gradient
    const bg = ctx.createLinearGradient(0, 0, totalW, totalH);
    bg.addColorStop(0, '#0a0e27');
    bg.addColorStop(0.5, '#1a1a2e');
    bg.addColorStop(1, '#16213e');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, totalW, totalH);

    // Header
    ctx.fillStyle = 'rgba(18,18,18,0.7)';
    roundRect(ctx, 0, 0, totalW, HEADER_H, 0);
    ctx.fill();

    // Title
    ctx.font = `bold 34px Burbank, "Arial Black", sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.fillText('VORZA ITEM SHOP', PAD + 8, 44);

    // Date & item count
    const dateStr = new Date().toISOString().split('T')[0];
    const totalItems = allSections.reduce((a, s) => a + s.items.length, 0);
    ctx.font = `500 15px Burbank, Arial, sans-serif`;
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.fillText(`${dateStr}  •  ${totalItems} ITEMS`, PAD + 8, 70);

    function rarityGradient(rarity, x, y, w, h) {
        const r = (rarity || '').toLowerCase();
        const grad = ctx.createLinearGradient(x, y, x, y + h);
        switch(r) {
            case 'legendary':  grad.addColorStop(0,'#ffb56b'); grad.addColorStop(1,'#c45a00'); break;
            case 'epic':       grad.addColorStop(0,'#c07aff'); grad.addColorStop(1,'#5a1fcc'); break;
            case 'rare':       grad.addColorStop(0,'#5db9ff'); grad.addColorStop(1,'#1a5cb0'); break;
            case 'uncommon':   grad.addColorStop(0,'#7de87a'); grad.addColorStop(1,'#1f8c25'); break;
            default:           grad.addColorStop(0,'#555'); grad.addColorStop(1,'#2a2a2a'); break;
        }
        return grad;
    }

    function rarityAccent(rarity) {
        const r = (rarity || '').toLowerCase();
        switch(r) {
            case 'legendary': return '#ffb56b';
            case 'epic':      return '#b175ff';
            case 'rare':      return '#5db9ff';
            case 'uncommon':  return '#7de87a';
            default:          return '#888';
        }
    }

    function roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    }

    // Fetch all images in parallel
    const imageCache = {};
    await Promise.all(allSections.flatMap(s => s.items).map(async (item) => {
        try {
            const resp = await axios.get(
                `https://fortnite-api.com/v2/cosmetics/br/search?name=${encodeURIComponent(item.name)}`,
                { timeout: 8000, responseType: 'json' }
            );
            const imgUrl = resp.data?.data?.images?.featured || resp.data?.data?.images?.smallIcon || resp.data?.data?.images?.icon;
            if (imgUrl) {
                const imgResp = await axios.get(imgUrl, { timeout: 8000, responseType: 'arraybuffer' });
                imageCache[item.name] = await loadImage(Buffer.from(imgResp.data));
            }
        } catch(e) {}
    }));

    let curY = HEADER_H + PAD;

    for (const sec of allSections) {
        // Section label
        ctx.font = `bold 18px Burbank, "Arial Black", sans-serif`;
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.fillText(sec.label, PAD + 6, curY + 24);
        // Divider line
        ctx.fillStyle = 'rgba(255,255,255,0.1)';
        ctx.fillRect(PAD, curY + 29, totalW - PAD * 2, 1);
        curY += SECTION_LABEL_H + PAD;

        for (let i = 0; i < sec.items.length; i++) {
            const item = sec.items[i];
            const col = i % COLS;
            const row = Math.floor(i / COLS);
            const cx = PAD + col * (CARD_W + PAD);
            const cy = curY + row * (CARD_H + PAD);

            const rarity = item.rarity?.value || item.rarity?.displayValue || item.rarity || '';
            const price = shopAI.calculatePrice(item);

            // Card background (rarity gradient)
            ctx.save();
            roundRect(ctx, cx, cy, CARD_W, CARD_H, 12);
            ctx.clip();
            ctx.fillStyle = rarityGradient(rarity, cx, cy, CARD_W, CARD_H);
            ctx.fill();

            // Subtle dark overlay at bottom for text
            const overlay = ctx.createLinearGradient(cx, cy + CARD_H - 70, cx, cy + CARD_H);
            overlay.addColorStop(0, 'rgba(0,0,0,0)');
            overlay.addColorStop(1, 'rgba(0,0,0,0.88)');
            ctx.fillStyle = overlay;
            ctx.fillRect(cx, cy, CARD_W, CARD_H);

            // Item image
            const img = imageCache[item.name];
            if (img) {
                const imgSize = CARD_H - 60;
                const imgX = cx + (CARD_W - imgSize) / 2;
                const imgY = cy + 4;
                ctx.drawImage(img, imgX, imgY, imgSize, imgSize);
            }

            ctx.restore();

            // Card border with rarity accent
            ctx.save();
            roundRect(ctx, cx, cy, CARD_W, CARD_H, 12);
            ctx.strokeStyle = rarityAccent(rarity) + '55';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            ctx.restore();

            // Item name
            ctx.font = `bold 13px Burbank, "Arial Black", sans-serif`;
            ctx.fillStyle = '#ffffff';
            const nameText = (item.name || '').toUpperCase();
            // Truncate if too long
            let displayName = nameText;
            while (ctx.measureText(displayName).width > CARD_W - 16 && displayName.length > 3) {
                displayName = displayName.slice(0, -1);
            }
            if (displayName !== nameText) displayName = displayName.slice(0, -2) + '..';
            ctx.fillText(displayName, cx + 8, cy + CARD_H - 32);

            // Price row
            ctx.font = `bold 14px Burbank, Arial, sans-serif`;
            ctx.fillStyle = '#67CAF5';
            if (price) ctx.fillText(`${price} V-Bucks`, cx + 8, cy + CARD_H - 12);
        }

        const rows = Math.ceil(sec.items.length / COLS);
        curY += rows * (CARD_H + PAD) + PAD;
    }

    return canvas.toBuffer('image/png');
}

async function postToDiscord(shop) {
    try {
        const dateStr = new Date().toISOString().split('T')[0];
        const shopUrl = 'http://vorza.fun';
        const imageBuffer = await renderShopHtmlImage(shop);
        const shopEmbed = {
            title: `Vorza Item Shop for ${dateStr}`,
            url: shopUrl,
            color: 0x00FF7F,
            image: { url: 'attachment://shop.png' }
        };

        if (config.discord && config.discord.bUseDiscordBot === true && config.discord.bot_token && config.bItemShopChannelId) {
            const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });

            await new Promise((resolve, reject) => {
                client.once('ready', async () => {
                    try {
                        const channel = await client.channels.fetch(config.bItemShopChannelId);
                        if (!(channel instanceof TextChannel)) {
                            resolve();
                            client.destroy();
                            return;
                        }

                        await channel.send({
                            content: '@everyone',
                            embeds: [shopEmbed],
                            files: [{ attachment: imageBuffer, name: 'shop.png' }],
                            allowedMentions: { parse: ['everyone'] }
                        });

                        resolve();
                    } catch (err) {
                        reject(err);
                    } finally {
                        client.destroy();
                    }
                });

                client.login(config.discord.bot_token).catch(reject);
            });

        } else if (config.bEnableDiscordWebhook === true && webhook && FormData) {
            const form = new FormData();
            form.append('payload_json', JSON.stringify({
                content: '@everyone',
                embeds: [shopEmbed],
                allowed_mentions: { parse: ['everyone'] }
            }));
            form.append('file', imageBuffer, { filename: 'shop.png', contentType: 'image/png' });
            await axios.post(webhook, form, { headers: form.getHeaders() });
        }

    } catch (error) {
        log.error('[Shop] Erro ao postar no Discord:', error.message);
    }
}

function calculateTimeUntilNextRotation() {
    const now = new Date();
    const rotateTimeConfig = config.bRotateTime.toString().trim();

    const [hourStr, minuteStr] = rotateTimeConfig.split(':');
    const targetHour = parseInt(hourStr, 10);
    const targetMinute = parseInt(minuteStr, 10);

    if (isNaN(targetHour) || isNaN(targetMinute)) {
        return 86400000;
    }

    let nextRotation = new Date(now);
    nextRotation.setHours(targetHour, targetMinute, 0, 0);

    if (nextRotation.getTime() <= now.getTime()) {
        nextRotation.setDate(nextRotation.getDate() + 1);
    }

    const millisUntilRotation = nextRotation.getTime() - now.getTime();

    if (millisUntilRotation < 10000) {
        nextRotation.setDate(nextRotation.getDate() + 1);
        return nextRotation.getTime() - now.getTime();
    }

    return millisUntilRotation;
}

async function rotateShop() {
    try {
        log.backend("[AUTO-ROTATE] Starting shop rotation...");
        const shop = await shopAI.generateShop();

        if (!shop) {
            log.error("[AUTO-ROTATE] Shop generation returned null");
            const nextRotationTime = calculateTimeUntilNextRotation();
            setTimeout(rotateShop, nextRotationTime);
            return;
        }

        updateCatalogConfig(shop);
        markRotatedToday();
    
        await postToDiscord(shop);

        const nextRotationTime = calculateTimeUntilNextRotation();
        setTimeout(rotateShop, nextRotationTime);

    } catch (error) {
        setTimeout(rotateShop, 3600000);
    }
}

let currentRotationTimer = null;

const lastRotationFile = path.join(__dirname, '..', '.last_rotation_date');

function didRotateToday() {
    try {
        if (!fs.existsSync(lastRotationFile)) return false;
        const lastDate = fs.readFileSync(lastRotationFile, 'utf-8').trim();
        return lastDate === new Date().toDateString();
    } catch (e) {
        return false;
    }
}

function markRotatedToday() {
    try {
        fs.writeFileSync(lastRotationFile, new Date().toDateString());
    } catch (e) {}
}

function initializeAutoRotation() {
    if (currentRotationTimer) {
        clearTimeout(currentRotationTimer);
        currentRotationTimer = null;
    }

    delete require.cache[require.resolve('../Config')];
    const freshConfig = require('../Config');

    if (freshConfig.bUseAutoRotate !== true) {
        return;
    }

    const now = new Date();
    const rotateTimeConfig = freshConfig.bRotateTime.toString().trim();
    const [h, m] = rotateTimeConfig.split(':').map(Number);

    const todayRotation = new Date(now);
    todayRotation.setHours(h, m, 0, 0);

    if (now.getTime() > todayRotation.getTime() && !didRotateToday()) {
        log.backend(`[Shop](${rotateTimeConfig}), rotating now`);
        currentRotationTimer = setTimeout(rotateShop, 5000);
    } else {
        const initialDelay = calculateTimeUntilNextRotation();
        const nextDate = new Date(now.getTime() + initialDelay);
        log.backend(`[Shop] Next Rotate ${nextDate.toLocaleString()} (in ${Math.round(initialDelay / 60000)} min)`);
        currentRotationTimer = setTimeout(rotateShop, initialDelay);
    }
}

initializeAutoRotation();

module.exports.rotateNow = async () => {
    try {
        await rotateShop();
    } catch (e) {
        throw e;
    }
};

module.exports.rescheduleRotation = () => {
    initializeAutoRotation();
};
