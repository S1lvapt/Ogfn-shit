/**
 * Playlist Display Manager
 * Handles custom playlist names, descriptions, and visual metadata
 */

const fs = require('fs');
const path = require('path');

class PlaylistDisplayManager {
    constructor() {
        this.displayData = this.loadDisplayData();
    }

    loadDisplayData() {
        try {
            const displayPath = path.join(__dirname, '..', 'Config', 'playlist_display.json');
            if (fs.existsSync(displayPath)) {
                return JSON.parse(fs.readFileSync(displayPath, 'utf8'));
            }
        } catch (err) {
            console.error('[PlaylistDisplay] Error loading display data:', err);
        }
        return { playlists: {} };
    }

    /**
     * Get display information for a playlist
     * @param {string} playlistName - Internal playlist name (e.g., "Playlist_ShowdownAlt_Solo")
     * @param {string} language - Language code (e.g., "en", "pt", "es")
     * @returns {object} Display data for the playlist
     */
    getPlaylistDisplay(playlistName, language = 'en') {
        const playlist = this.displayData.playlists[playlistName];

        if (!playlist) {
            return {
                displayName: playlistName,
                description: '',
                shortDescription: '',
                metadata: {}
            };
        }

        return {
            displayName: playlist.displayName[language] || playlist.displayName['en'],
            description: playlist.description[language] || playlist.description['en'],
            shortDescription: playlist.shortDescription[language] || playlist.shortDescription['en'],
            metadata: playlist.metadata || {},
            rules: this.localizeRules(playlist.rules, language),
            rewards: playlist.rewards || {}
        };
    }

    /**
     * Localize rules array
     */
    localizeRules(rules, language = 'en') {
        if (!rules) return null;

        return {
            displayRules: rules.displayRules?.map(rule =>
                rule[language] || rule['en']
            ) || [],
            tips: rules.tips?.map(tip =>
                tip[language] || tip['en']
            ) || []
        };
    }

    /**
     * Get all playlists with display data
     */
    getAllPlaylists(language = 'en') {
        const playlists = {};

        for (const [playlistName, playlistData] of Object.entries(this.displayData.playlists)) {
            playlists[playlistName] = this.getPlaylistDisplay(playlistName, language);
        }

        return playlists;
    }

    /**
     * Format playlist for API response
     */
    formatForAPI(playlistName, language = 'en') {
        const display = this.getPlaylistDisplay(playlistName, language);

        return {
            playlistName: playlistName,
            displayName: display.displayName,
            description: display.description,
            shortDescription: display.shortDescription,
            ...display.metadata,
            rules: display.rules,
            rewards: display.rewards
        };
    }

    /**
     * Get playlist metadata for matchmaking
     */
    getMatchmakingData(playlistName) {
        const playlist = this.displayData.playlists[playlistName];

        if (!playlist || !playlist.metadata) {
            return {
                maxPlayers: 100,
                gameMode: 'BR',
                subMode: 'Default'
            };
        }

        return {
            maxPlayers: playlist.metadata.maxPlayers || 100,
            gameMode: playlist.metadata.gameMode || 'BR',
            subMode: playlist.metadata.subMode || 'Default',
            minLevel: playlist.metadata.minLevel || 0,
            displayPriority: playlist.metadata.displayPriority || 0
        };
    }
}

module.exports = new PlaylistDisplayManager();
