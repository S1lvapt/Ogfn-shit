/**
 * GameServer Manager � vers�o in-memory, sem MongoDB
 * L� tudo do config.json. Zero depend�ncia de DB para matchmaking.
 */

const log = require("./log.js");
const config = require("../Config/config.json");

class GameServerManager {
    constructor() {
        this.initialized = false;
    }

    async initialize() {
        if (this.initialized) return;
        const count = Array.isArray(config.gameServers) ? config.gameServers.filter(s => s.enabled !== false).length : 0;
        log.backend(`[GameServer Manager] Initializing...`);
        // Simula log de cada servidor como antes para manter os logs iguais
        if (Array.isArray(config.gameServers)) {
            for (const s of config.gameServers) {
                const status = s.enabled !== false ? "online" : "offline";
                log.backend(`[GameServer Manager] Updated server: ${s.id} (status: ${status})`);
            }
        }
        log.backend(`[GameServer Manager] Initialized with ${count} servers`);
        this.initialized = true;
    }

    // Retorna o primeiro servidor dispon�vel para a playlist � s� config, sem DB
    async findServerForPlaylist(playlist, hasPriority = false) {
        if (!config.gameServers || !Array.isArray(config.gameServers)) return null;
        const candidates = config.gameServers.filter(s =>
            s.enabled !== false &&
            Array.isArray(s.playlists) &&
            s.playlists.some(p => p.toLowerCase() === (playlist || "").toLowerCase())
        );
        if (candidates.length === 0) return null;
        const s = candidates[0];
        return {
            serverId: s.id,
            ip:       s.ip,
            port:     s.port || 7777,
            region:   s.region || "EU"
        };
    }

    // Stub � mantido para compatibilidade com c�digo que chame estes m�todos
    async createMatch()     { return {}; }
    async updateMatch()     { return {}; }
    async endMatch()        { return {}; }
    async updateHeartbeat() { return { success: true }; }
    startHealthChecks()     {}
    stop()                  {}

    async getStatistics() {
        const servers = Array.isArray(config.gameServers) ? config.gameServers : [];
        return {
            totalServers:  servers.length,
            onlineServers: servers.filter(s => s.enabled !== false).length,
            activeMatches: 0,
            totalPlayers:  0,
            servers: servers.map(s => ({
                id:           s.id,
                status:       s.enabled !== false ? "online" : "offline",
                players:      0,
                maxPlayers:   s.maxPlayers || 100,
                totalMatches: 0
            }))
        };
    }
}

module.exports = new GameServerManager();