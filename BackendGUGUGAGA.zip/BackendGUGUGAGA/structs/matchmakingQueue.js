/**
 * Matchmaking Queue � vers�o in-memory, sem MongoDB
 * Mant�m compatibilidade de API com o c�digo original.
 */

const log = require("./log.js");

class MatchmakingQueue {
    constructor() {
        this.queues = new Map();       // playlist -> [players]
        this.playerQueues = new Map(); // accountId -> entry
    }

    async initialize() {
        log.backend("[Matchmaking Queue] A inicializar...");
        log.backend("[Matchmaking Queue] Inicializado");
    }

    async joinQueue(player, playlist) {
        if (this.playerQueues.has(player.accountId)) {
            const existing = this.playerQueues.get(player.accountId);
            if (existing.playlist === playlist) return existing;
            await this.leaveQueue(player.accountId);
        }
        const entry = {
            accountId:    player.accountId,
            displayName:  player.displayName || player.accountId,
            matchmakingId: player.matchmakingId,
            playlist,
            joinedAt:     Date.now(),
            priorityTier: player.priorityTier || 0,
            hasPriority:  (player.priorityTier || 0) > 0
        };
        if (!this.queues.has(playlist)) this.queues.set(playlist, []);
        this.queues.get(playlist).push(entry);
        this.playerQueues.set(player.accountId, entry);
        return entry;
    }

    async leaveQueue(accountId) {
        const entry = this.playerQueues.get(accountId);
        if (!entry) return false;
        const queue = this.queues.get(entry.playlist);
        if (queue) {
            const idx = queue.findIndex(p => p.accountId === accountId);
            if (idx !== -1) queue.splice(idx, 1);
        }
        this.playerQueues.delete(accountId);
        return true;
    }

    getQueueInfo(accountId) {
        const entry = this.playerQueues.get(accountId);
        if (!entry) return null;
        const queue = this.queues.get(entry.playlist) || [];
        const position = queue.findIndex(p => p.accountId === accountId) + 1;
        return {
            playlist:     entry.playlist,
            position,
            queueSize:    queue.length,
            waitTime:     Math.floor((Date.now() - entry.joinedAt) / 1000),
            estimatedWait: 0,
            priorityTier: entry.priorityTier,
            hasPriority:  entry.hasPriority
        };
    }

    getStatistics() {
        const stats = {};
        for (const [playlist, queue] of this.queues) {
            stats[playlist] = { totalInQueue: queue.length };
        }
        return stats;
    }

    // Stub para compatibilidade
    startMatchmaking() {}
    stopMatchmaking()  {}
}

module.exports = new MatchmakingQueue();