const crypto = require('crypto');

// Chave de encriptação (em produção, deve estar em variável de ambiente)
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'vorza-backend-secret-key-32bit!';
const IV_LENGTH = 16;

function encrypt(text) {
    if (!text) return text;

    try {
        const key = crypto.createHash('sha256').update(String(ENCRYPTION_KEY)).digest('base64').substr(0, 32);
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);

        let encrypted = cipher.update(text);
        encrypted = Buffer.concat([encrypted, cipher.final()]);

        return iv.toString('hex') + ':' + encrypted.toString('hex');
    } catch (error) {
        console.error('Encryption error:', error);
        return text;
    }
}

function decrypt(text) {
    if (!text || typeof text !== 'string') return text;

    // Check if text looks like encrypted data (has : separator and hex format)
    if (!text.includes(':') || text.split(':').length !== 2) return text;

    const parts = text.split(':');
    // Verify both parts are valid hex strings
    if (!/^[0-9a-f]+$/i.test(parts[0]) || !/^[0-9a-f]+$/i.test(parts[1])) {
        return text;
    }

    try {
        const key = crypto.createHash('sha256').update(String(ENCRYPTION_KEY)).digest('base64').substr(0, 32);
        const iv = Buffer.from(parts[0], 'hex');
        const encryptedText = Buffer.from(parts[1], 'hex');
        const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);

        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);

        return decrypted.toString();
    } catch (error) {
        // Silently return original text if decryption fails
        return text;
    }
}

// Função para processar config com campos sensíveis
function decryptConfig(config) {
    const decrypted = JSON.parse(JSON.stringify(config));

    // Decrypt sensitive fields
    if (decrypted.discord?.bot_token) {
        decrypted.discord.bot_token = decrypt(decrypted.discord.bot_token);
    }
    if (decrypted.discord?.clientSecret) {
        decrypted.discord.clientSecret = decrypt(decrypted.discord.clientSecret);
    }
    if (decrypted.mongodb?.database) {
        decrypted.mongodb.database = decrypt(decrypted.mongodb.database);
    }
    if (decrypted.Website?.clientSecret) {
        decrypted.Website.clientSecret = decrypt(decrypted.Website.clientSecret);
    }
    if (decrypted.Api?.bApiKey) {
        decrypted.Api.bApiKey = decrypt(decrypted.Api.bApiKey);
    }

    return decrypted;
}

module.exports = {
    encrypt,
    decrypt,
    decryptConfig
};
