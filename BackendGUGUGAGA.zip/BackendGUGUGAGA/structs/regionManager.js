/**
 * Region Manager
 * Manages server regions and ping calculations
 */

const config = require("../Config/config.json");
const log = require("./log.js");

class RegionManager {
    constructor() {
        this.regions = this.loadRegions();
    }

    /**
     * Load regions from config
     */
    loadRegions() {
        if (!config.gameServers || !Array.isArray(config.gameServers)) {
            log.error("[Region Manager] No gameServers configured in config.json");
            return [];
        }

        return config.gameServers.filter(server => server.enabled).map(server => ({
            id: server.id,
            regionId: server.region,
            regionName: server.regionName || server.region,
            displayName: server.regionName || server.region,
            ip: server.ip,
            port: server.port,
            location: server.location || "Unknown",
            averagePing: server.averagePing || 0,
            playlists: server.playlists || [],
            enabled: server.enabled !== false
        }));
    }

    /**
     * Get all available regions
     */
    getAllRegions() {
        return this.regions;
    }

    /**
     * Get region by ID
     */
    getRegionById(regionId) {
        return this.regions.find(r => r.regionId === regionId || r.id === regionId);
    }

    /**
     * Get best region based on ping (for auto-region selection)
     */
    getBestRegion() {
        // Return the region with lowest average ping
        return this.regions.reduce((best, current) => {
            if (!best || current.averagePing < best.averagePing) {
                return current;
            }
            return best;
        }, null);
    }

    /**
     * Get server for playlist
     */
    getServerForPlaylist(playlist) {
        return this.regions.find(r => r.playlists.includes(playlist));
    }

    /**
     * Format region display name with ping
     */
    formatRegionDisplayName(regionId, ping) {
        const region = this.getRegionById(regionId);
        if (!region) return `Unknown (${ping}ms)`;

        // Format: "Europe (Spain) 15ms"
        return `${region.displayName} ${ping}ms`;
    }

    /**
     * Get ping info for a region
     */
    getPingInfo(regionId) {
        const region = this.getRegionById(regionId);
        if (!region) return null;

        return {
            regionId: region.regionId,
            regionName: region.regionName,
            averagePing: region.averagePing,
            ip: region.ip,
            port: region.port
        };
    }
}

// Create singleton instance
const regionManager = new RegionManager();

module.exports = regionManager;
