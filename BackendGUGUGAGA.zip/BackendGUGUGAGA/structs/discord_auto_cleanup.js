const fs = require('fs');
const path = require('path');
const log = require('./log.js');

const COMMANDS_HASH_FILE = path.join(__dirname, '..', '.discord_commands_hash');

function calculateCommandsHash() {
    const commandsDir = path.join(__dirname, '..', 'DiscordBot', 'commands');
    const files = [];

    function readDir(dir) {
        if (!fs.existsSync(dir)) return;
        const items = fs.readdirSync(dir);
        items.forEach(item => {
            const fullPath = path.join(dir, item);
            if (fs.statSync(fullPath).isDirectory()) {
                readDir(fullPath);
            } else if (item.endsWith('.js')) {
                files.push(fullPath);
            }
        });
    }

    readDir(commandsDir);

    const hash = files.map(f => {
        const stat = fs.statSync(f);
        return `${path.basename(f)}:${stat.size}`;
    }).join('|');

    return hash;
}

async function checkAndCleanupDiscord(client) {
    try {
        const currentHash = calculateCommandsHash();
        let previousHash = '';

        if (fs.existsSync(COMMANDS_HASH_FILE)) {
            previousHash = fs.readFileSync(COMMANDS_HASH_FILE, 'utf-8');
        }

        if (currentHash !== previousHash) {
            const commands = await client.application.commands.fetch();

            if (commands.size > 0) {
                for (const [id, cmd] of commands) {
                    try {
                        await client.application.commands.delete(id);
                    } catch (err) {}
                }
            }

            fs.writeFileSync(COMMANDS_HASH_FILE, currentHash);
            return true;
        }

        return false;

    } catch (error) {
        return false;
    }
}

module.exports = { checkAndCleanupDiscord };