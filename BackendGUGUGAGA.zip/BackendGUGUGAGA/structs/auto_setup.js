const fs = require('fs');
const path = require('path');

const SETUP_FLAG = path.join(__dirname, '..', '.auto_setup_done');

async function runAutoSetup() {
    if (fs.existsSync(SETUP_FLAG)) return;

    try {
        // Ensure tokenManager directory exists
        const tokenManagerDir = path.join(__dirname, '..', 'tokenManager');
        if (!fs.existsSync(tokenManagerDir)) {
            fs.mkdirSync(tokenManagerDir, { recursive: true });
        }

        // Ensure tokens.json exists
        const tokensFile = path.join(tokenManagerDir, 'tokens.json');
        if (!fs.existsSync(tokensFile)) {
            fs.writeFileSync(tokensFile, JSON.stringify({
                accessTokens: [],
                refreshTokens: [],
                clientTokens: []
            }, null, 2));
        }

        const autorotateV2 = path.join(__dirname, 'autorotate_v2.js');
        const autorotate = path.join(__dirname, 'autorotate.js');

        if (fs.existsSync(autorotateV2)) {
            if (fs.existsSync(autorotate)) {
                const backup = autorotate + '.backup';
                if (!fs.existsSync(backup)) {
                    fs.copyFileSync(autorotate, backup);
                }
            }
            fs.copyFileSync(autorotateV2, autorotate);
        }

        const configPath = path.join(__dirname, '..', 'Config', 'config.json');
        if (fs.existsSync(configPath)) {
            const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
            let updated = false;

            if (!config.bDailyItemsAmount || config.bDailyItemsAmount < 12) {
                config.bDailyItemsAmount = 12;
                updated = true;
            }
            if (!config.bFeaturedItemsAmount || config.bFeaturedItemsAmount < 8) {
                config.bFeaturedItemsAmount = 8;
                updated = true;
            }
            if (!config.bWeeklyItemsAmount) {
                config.bWeeklyItemsAmount = 6;
                updated = true;
            }

            if (updated) {
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
            }
        }

        fs.writeFileSync(SETUP_FLAG, new Date().toISOString());

    } catch (error) {}
}

module.exports = { runAutoSetup };
