const mongoose = require('mongoose');
const http = require('http');
const https = require('https');
const config = require('../Config');

class HealthMonitor {
    constructor() {
        this.checks = {
            mongodb: { healthy: true, lastCheck: Date.now(), errors: 0 },
            connections: { healthy: true, lastCheck: Date.now(), errors: 0 }
        };
        this.maxErrors = 5;
        this.checkInterval = 60000;
        this.keepAliveInterval = 300000;
        this.isMonitoring = false;
    }

    start() {
        if (this.isMonitoring) return;
        this.isMonitoring = true;

        this.runHealthChecks();

        this.monitorInterval = setInterval(() => {
            this.runHealthChecks();
        }, this.checkInterval);

        this.startKeepAlive();
    }

    stop() {
        if (!this.isMonitoring) return;
        this.isMonitoring = false;
        clearInterval(this.monitorInterval);
        clearInterval(this.keepAliveTimer);
    }

    startKeepAlive() {
        const port = config.port || 3551;
        const protocol = config.bEnableHTTPS ? https : http;
        const url = config.bEnableHTTPS
            ? `https://localhost:${port}/unknown`
            : `http://localhost:${port}/unknown`;

        this.keepAliveTimer = setInterval(() => {
            try {
                const req = protocol.get(url, { rejectUnauthorized: false }, (res) => {
                    res.resume();
                });
                req.on('error', () => {});
                req.end();
            } catch (e) {}
        }, this.keepAliveInterval);
    }

    async runHealthChecks() {
        try {
            await this.checkMongoDB();
            this.checkConnections();
        } catch (error) {}
    }

    async checkMongoDB() {
        try {
            const state = mongoose.connection.readyState;

            if (state === 1) {
                await mongoose.connection.db.admin().ping();
                this.checks.mongodb.healthy = true;
                this.checks.mongodb.errors = 0;
                this.checks.mongodb.lastCheck = Date.now();
            } else if (state === 0) {
                this.checks.mongodb.healthy = false;
                this.checks.mongodb.errors++;
                await this.attemptMongoDBReconnect();
            } else {
                this.checks.mongodb.healthy = false;
                this.checks.mongodb.errors++;
            }
        } catch (error) {
            this.checks.mongodb.healthy = false;
            this.checks.mongodb.errors++;

            if (this.checks.mongodb.errors >= this.maxErrors) {
                this.attemptMongoDBReconnect();
            }
        }
    }

    async attemptMongoDBReconnect() {
        try {
            if (mongoose.connection.readyState !== 0) {
                await mongoose.connection.close();
            }

            await mongoose.connect(config.mongodb.database, {
                serverSelectionTimeoutMS: 10000,
                socketTimeoutMS: 45000,
            });

            this.checks.mongodb.healthy = true;
            this.checks.mongodb.errors = 0;
        } catch (error) {
            setTimeout(() => {
                this.attemptMongoDBReconnect();
            }, 30000);
        }
    }

    checkConnections() {
        try {
            const mongoConnections = mongoose.connections.length;
            this.checks.connections.lastCheck = Date.now();
            this.checks.connections.healthy = mongoConnections <= 10;
            if (this.checks.connections.healthy) {
                this.checks.connections.errors = 0;
            } else {
                this.checks.connections.errors++;
            }
        } catch (error) {}
    }

    getHealthStatus() {
        return {
            healthy: Object.values(this.checks).every(c => c.healthy),
            checks: this.checks,
            uptime: process.uptime()
        };
    }
}

const healthMonitor = new HealthMonitor();
module.exports = healthMonitor;
