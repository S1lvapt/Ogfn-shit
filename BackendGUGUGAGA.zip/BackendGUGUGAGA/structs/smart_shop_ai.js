const axios = require('axios');
const fs = require('fs');
const path = require('path');
const log = require("./log.js");

/**
 * Smart Shop AI - Sistema inteligente de cria��o de loja
 * Cria lojas di�rias com 20+ itens usando algoritmos inteligentes
 */

class SmartShopAI {
    constructor(config) {
        this.config = config;
        this.fortniteApi = "https://fortnite-api.com/v2/cosmetics/br";
        this.cosmetics = [];
        this.lastFetch = null;
        this.historyFile = path.join(__dirname, '..', '.shop_history.json');

        // Configura��es da IA
        this.shopConfig = {
            featured: 8,    // 8 itens featured
            daily: 12,      // 12 itens daily
            weekly: 6       // 6 itens weekly (total: 26 itens)
        };

        // Pesos de raridade para sele��o inteligente
        this.rarityWeights = {
            'legendary': 0.15,  // 15% de chance
            'epic': 0.30,       // 30% de chance
            'rare': 0.35,       // 35% de chance
            'uncommon': 0.20    // 20% de chance
        };

        // Pesos de tipo para variedade
        this.typeWeights = {
            'outfit': 0.30,
            'emote': 0.20,
            'pickaxe': 0.15,
            'glider': 0.15,
            'backpack': 0.10,
            'wrap': 0.05,
            'loadingscreen': 0.03,
            'music': 0.02
        };
    }

    /**
     * Load recent shop history (item IDs from last N rotations)
     */
    loadHistory() {
        try {
            if (fs.existsSync(this.historyFile)) {
                const data = JSON.parse(fs.readFileSync(this.historyFile, 'utf-8'));
                return Array.isArray(data) ? data : [];
            }
        } catch (e) {}
        return [];
    }

    /**
     * Save item IDs to history, keeping last 3 rotations
     */
    saveHistory(itemIds) {
        try {
            let history = this.loadHistory();
            history.unshift(itemIds);
            // Keep only last 3 rotations
            history = history.slice(0, 3);
            fs.writeFileSync(this.historyFile, JSON.stringify(history, null, 2));
        } catch (e) {}
    }

    /**
     * Get set of recently used item IDs (from last 2 rotations)
     */
    getRecentItemIds() {
        const history = this.loadHistory();
        const recentIds = new Set();
        // Skip current (index 0 would be the one we just saved), use last 2
        for (const rotation of history.slice(0, 2)) {
            if (Array.isArray(rotation)) {
                rotation.forEach(id => recentIds.add(id));
            }
        }
        return recentIds;
    }

    /**
     * Busca todos os cosm�ticos da API do Fortnite
     */
    async fetchCosmetics() {
        try {
            // Cache de 1 hora
            if (this.lastFetch && (Date.now() - this.lastFetch < 3600000)) {
                log.AutoRotation("[AI] Using cached cosmetics data");
                return this.cosmetics;
            }

            log.AutoRotation("[AI] Fetching cosmetics from Fortnite API...");
            const response = await axios.get(this.fortniteApi, { timeout: 30000 });
            const cosmetics = response.data.data || [];

            const excludedItems = this.config.bExcludedItems || [];
            const maxChapter = parseInt(this.config.bChapterlimit, 10);
            const maxSeason = this.config.bSeasonlimit.toString();

            this.cosmetics = cosmetics.filter(item => {
                const { id, introduction, rarity } = item;
                const chapter = introduction?.chapter ? parseInt(introduction.chapter, 10) : null;
                const season = introduction?.season ? introduction.season.toString() : null;
                const itemRarity = rarity?.displayValue?.toLowerCase();

                if (!chapter || !season) return false;
                if (excludedItems.includes(id)) return false;
                if (itemRarity === "common") return false;

                if (maxSeason === "OG") {
                    return chapter >= 1 && chapter <= maxChapter;
                }

                if (chapter < 1 || chapter > maxChapter) return false;
                if (chapter === maxChapter) {
                    // Rejeitar seasons com nomes nao numericos (ex: "Remix", "OG") --
                    // sao seasons especiais de re-run e os seus cosmeticos nao existem nesta versao.
                    const seasonNum = parseInt(season, 10);
                    if (isNaN(seasonNum)) return false;
                    if (season !== "X" && seasonNum > parseInt(maxSeason, 10)) return false;
                }

                return true;
            });

            this.lastFetch = Date.now();
            log.AutoRotation(`[AI] Fetched ${this.cosmetics.length} valid cosmetics`);
            return this.cosmetics;

        } catch (error) {
            log.error('[AI] Error fetching cosmetics:', error.message);
            // Retorna cache antigo se houver
            return this.cosmetics.length > 0 ? this.cosmetics : [];
        }
    }

    /**
     * Calcula score de um item baseado em diversos fatores
     */
    calculateItemScore(item, recentIds) {
        let score = 0;

        // Score por raridade (small bonus, not dominant)
        const rarity = item.rarity?.displayValue?.toLowerCase();
        if (rarity === 'legendary') score += 20;
        else if (rarity === 'epic') score += 15;
        else if (rarity === 'rare') score += 10;
        else if (rarity === 'uncommon') score += 5;

        // Small bonus for series items
        const series = item.series?.value?.toLowerCase();
        if (series) score += 10;

        // Small bonus by type
        const type = item.type?.value?.toLowerCase();
        if (type === 'outfit') score += 10;
        else if (type === 'emote') score += 5;

        // Penalize recently used items heavily
        if (recentIds && recentIds.has(item.id)) {
            score -= 200;
        }

        // Large random factor so different items get picked each rotation
        score += Math.random() * 100;

        return score;
    }

    /**
     * Seleciona itens de forma inteligente usando pesos e scores
     */
    selectSmartItems(items, count, category = 'general') {
        if (items.length === 0) return [];
        if (items.length <= count) return this.shuffle(items);

        const recentIds = this.getRecentItemIds();

        // Separate by type
        const itemsByType = {
            outfit: [],
            emote: [],
            pickaxe: [],
            glider: [],
            backpack: [],
            wrap: [],
            loadingscreen: [],
            music: [],
            other: []
        };

        items.forEach(item => {
            const type = item.type?.value?.toLowerCase();
            if (itemsByType[type]) {
                itemsByType[type].push(item);
            } else {
                itemsByType.other.push(item);
            }
        });

        const selectedItems = [];

        // Para featured: mais outfits e itens raros
        if (category === 'featured') {
            this.addRandomItemsFromType(itemsByType.outfit, 3, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.emote, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.pickaxe, 1, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.glider, 1, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.backpack, 1, selectedItems, recentIds);
        }
        // Para daily: variedade maior
        else if (category === 'daily') {
            this.addRandomItemsFromType(itemsByType.outfit, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.emote, 3, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.pickaxe, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.glider, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.backpack, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.wrap, 1, selectedItems, recentIds);
        }
        // Para weekly: mix balanceado
        else if (category === 'weekly') {
            this.addRandomItemsFromType(itemsByType.outfit, 2, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.emote, 1, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.pickaxe, 1, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.glider, 1, selectedItems, recentIds);
            this.addRandomItemsFromType(itemsByType.backpack, 1, selectedItems, recentIds);
        }

        // Fill remaining slots with random items
        const remainingCount = count - selectedItems.length;
        if (remainingCount > 0) {
            const remainingItems = items.filter(item => !selectedItems.includes(item));
            const scoredItems = remainingItems
                .map(item => ({ item, score: this.calculateItemScore(item, recentIds) }))
                .sort((a, b) => b.score - a.score)
                .slice(0, remainingCount)
                .map(scored => scored.item);

            selectedItems.push(...scoredItems);
        }

        return selectedItems.slice(0, count);
    }

    /**
     * Fisher-Yates shuffle
     */
    shuffle(array) {
        const arr = [...array];
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    /**
     * Adiciona os melhores itens de um tipo espec�fico
     */
    addRandomItemsFromType(items, count, selectedItems, recentIds) {
        if (!items || items.length === 0 || count === 0) return;

        // Filter out already selected and recently used items first
        let available = items.filter(item => !selectedItems.includes(item) && !(recentIds && recentIds.has(item.id)));

        // If not enough non-recent items, allow recent ones too
        if (available.length < count) {
            available = items.filter(item => !selectedItems.includes(item));
        }

        // Shuffle and pick random items
        const shuffled = this.shuffle(available);
        selectedItems.push(...shuffled.slice(0, count));
    }

    /**
     * Formata o item para o formato do backend
     */
    formatItemGrants(item) {
        const { id, backendValue, type } = item;
        let itemType;

        switch (type.value.toLowerCase()) {
            case "outfit":
                itemType = "AthenaCharacter";
                break;
            case "emote":
                itemType = "AthenaDance";
                break;
            case "backpack":
                itemType = "AthenaBackpack";
                break;
            case "glider":
                itemType = "AthenaGlider";
                break;
            case "pickaxe":
                itemType = "AthenaPickaxe";
                break;
            case "wrap":
                itemType = "AthenaItemWrap";
                break;
            case "loadingscreen":
                itemType = "AthenaLoadingScreen";
                break;
            case "music":
                itemType = "AthenaMusicPack";
                break;
            default:
                itemType = backendValue || `Athena${this.capitalize(type.value)}`;
                break;
        }

        return [`${itemType}:${id}`];
    }

    /**
     * Calcula pre�o baseado em raridade e tipo
     */
    calculatePrice(item) {
        const rarity = item.rarity?.displayValue?.toLowerCase();
        const type = item.type?.value?.toLowerCase();
        const series = item.series?.value?.toLowerCase();

        // S�ries especiais
        if (series) {
            const specialSeries = ['gaming legends series', 'marvel series', 'star wars series', 'dc series', 'icon series'];
            if (specialSeries.includes(series)) {
                switch (type) {
                    case 'outfit': return 1500;
                    case 'pickaxe': return 1200;
                    case 'backpack': return 1200;
                    case 'emote': return 500;
                    case 'glider': return 1200;
                    case 'wrap': return 700;
                    default: return 1000;
                }
            }
        }

        // Pre�os normais por tipo e raridade
        switch (type) {
            case 'outfit':
                switch (rarity) {
                    case 'legendary': return 2000;
                    case 'epic': return 1500;
                    case 'rare': return 1200;
                    case 'uncommon': return 800;
                    default: return 1200;
                }
            case 'pickaxe':
                switch (rarity) {
                    case 'epic': return 1200;
                    case 'rare': return 800;
                    case 'uncommon': return 500;
                    default: return 800;
                }
            case 'emote':
                switch (rarity) {
                    case 'legendary': return 2000;
                    case 'epic': return 800;
                    case 'rare': return 500;
                    case 'uncommon': return 200;
                    default: return 500;
                }
            case 'glider':
                switch (rarity) {
                    case 'legendary': return 2000;
                    case 'epic': return 1200;
                    case 'rare': return 800;
                    case 'uncommon': return 500;
                    default: return 800;
                }
            case 'backpack':
                switch (rarity) {
                    case 'legendary': return 2000;
                    case 'epic': return 1500;
                    case 'rare': return 1200;
                    case 'uncommon': return 200;
                    default: return 1000;
                }
            case 'wrap':
                switch (rarity) {
                    case 'legendary': return 1200;
                    case 'epic': return 700;
                    case 'rare': return 500;
                    case 'uncommon': return 300;
                    default: return 500;
                }
            default:
                return 500;
        }
    }

    /**
     * Gera uma loja completa com 20+ itens
     */
    async generateShop() {
        try {
            log.AutoRotation("+---------------------------------------------------+");
            log.AutoRotation("�         SMART SHOP AI - GENERATING SHOP          �");
            log.AutoRotation("+---------------------------------------------------+");

            const cosmetics = await this.fetchCosmetics();

            if (cosmetics.length === 0) {
                log.error("[AI] No cosmetics available!");
                return null;
            }

            log.AutoRotation(`[AI] Available cosmetics: ${cosmetics.length}`);

            // Selecionar itens de forma inteligente
            const featuredItems = this.selectSmartItems(cosmetics, this.shopConfig.featured, 'featured');

            // Remove featured items da pool para evitar duplicatas
            const remainingCosmetics = cosmetics.filter(c => !featuredItems.includes(c));
            const dailyItems = this.selectSmartItems(remainingCosmetics, this.shopConfig.daily, 'daily');

            // Remove daily items da pool
            const remainingForWeekly = remainingCosmetics.filter(c => !dailyItems.includes(c));
            const weeklyItems = this.selectSmartItems(remainingForWeekly, this.shopConfig.weekly, 'weekly');

            const totalItems = featuredItems.length + dailyItems.length + weeklyItems.length;

            log.AutoRotation(`[AI] Generated shop with ${totalItems} items:`);
            log.AutoRotation(`  +- Featured: ${featuredItems.length} items`);
            log.AutoRotation(`  +- Daily: ${dailyItems.length} items`);
            log.AutoRotation(`  +- Weekly: ${weeklyItems.length} items`);

            // Calcular estat�sticas
            const allItems = [...featuredItems, ...dailyItems, ...weeklyItems];
            const stats = this.calculateShopStats(allItems);

            log.AutoRotation(`[AI] Shop Statistics:`);
            log.AutoRotation(`  +- Legendary: ${stats.legendary}`);
            log.AutoRotation(`  +- Epic: ${stats.epic}`);
            log.AutoRotation(`  +- Rare: ${stats.rare}`);
            log.AutoRotation(`  +- Uncommon: ${stats.uncommon}`);
            log.AutoRotation(`  +- Total V-Bucks: ${stats.totalVBucks}`);

            // Save item IDs to history so next rotation picks different items
            const allItemIds = allItems.map(item => item.id);
            this.saveHistory(allItemIds);

            return {
                featured: featuredItems,
                daily: dailyItems,
                weekly: weeklyItems,
                stats
            };

        } catch (error) {
            log.error("[AI] Error generating shop:", error.message);
            throw error;
        }
    }

    /**
     * Calcula estat�sticas da loja
     */
    calculateShopStats(items) {
        const stats = {
            legendary: 0,
            epic: 0,
            rare: 0,
            uncommon: 0,
            totalVBucks: 0
        };

        items.forEach(item => {
            const rarity = item.rarity?.displayValue?.toLowerCase();
            if (rarity === 'legendary') stats.legendary++;
            else if (rarity === 'epic') stats.epic++;
            else if (rarity === 'rare') stats.rare++;
            else if (rarity === 'uncommon') stats.uncommon++;

            stats.totalVBucks += this.calculatePrice(item);
        });

        return stats;
    }

    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

module.exports = SmartShopAI;