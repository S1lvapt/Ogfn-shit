/**
 * Helper functions for playlist and gamemode management
 */

const Playlist = require("../model/playlists.js");
const Gamemode = require("../model/gamemodes.js");
const log = require("./log.js");

class PlaylistHelper {
    /**
     * Get playlist by ID
     * @param {string} playlistId
     * @returns {Promise<Object|null>}
     */
    static async getPlaylist(playlistId) {
        try {
            const playlist = await Playlist.findOne({
                playlistId: playlistId,
                isActive: true
            });
            return playlist;
        } catch (err) {
            log.error(`Error fetching playlist ${playlistId}:`, err);
            return null;
        }
    }

    /**
     * Get all active playlists
     * @returns {Promise<Array>}
     */
    static async getActivePlaylists() {
        try {
            const playlists = await Playlist.find({
                isActive: true,
                isVisible: true
            }).sort({ displayPriority: -1 });
            return playlists;
        } catch (err) {
            log.error("Error fetching active playlists:", err);
            return [];
        }
    }

    /**
     * Get gamemode by ID
     * @param {string} gamemodeId
     * @returns {Promise<Object|null>}
     */
    static async getGamemode(gamemodeId) {
        try {
            const gamemode = await Gamemode.findOne({
                gamemodeId: gamemodeId,
                isActive: true
            });
            return gamemode;
        } catch (err) {
            log.error(`Error fetching gamemode ${gamemodeId}:`, err);
            return null;
        }
    }

    /**
     * Check if user can join a playlist
     * @param {Object} user
     * @param {Object} playlist
     * @returns {Object} { canJoin: boolean, reason: string }
     */
    static canUserJoinPlaylist(user, playlist) {
        if (!playlist) {
            return { canJoin: false, reason: "Playlist not found" };
        }

        if (!playlist.isActive) {
            return { canJoin: false, reason: "Playlist is not active" };
        }

        // Check level requirement
        if (playlist.requirements.minLevel > 0) {
            const userLevel = user.level || 0;
            if (userLevel < playlist.requirements.minLevel) {
                return {
                    canJoin: false,
                    reason: `Requires level ${playlist.requirements.minLevel}`
                };
            }
        }

        // Check donator requirement
        if (playlist.requirements.requiredDonatorTier !== "none") {
            const tierHierarchy = {
                "none": 0,
                "basic": 1,
                "medium": 2,
                "high": 3,
                "ultimate": 4
            };

            const requiredTier = tierHierarchy[playlist.requirements.requiredDonatorTier] || 0;
            let userTier = 0;

            if (user.ultimateDonator) userTier = 4;
            else if (user.highDonator) userTier = 3;
            else if (user.mediumDonator) userTier = 2;
            else if (user.basicDonator) userTier = 1;

            if (userTier < requiredTier) {
                return {
                    canJoin: false,
                    reason: `Requires ${playlist.requirements.requiredDonatorTier} donator tier or higher`
                };
            }
        }

        return { canJoin: true, reason: "" };
    }

    /**
     * Increment playlist match statistics
     * @param {string} playlistId
     * @param {number} playerCount
     */
    static async incrementPlaylistStats(playlistId, playerCount = 1) {
        try {
            await Playlist.updateOne(
                { playlistId: playlistId },
                {
                    $inc: {
                        totalMatches: 1,
                        totalPlayers: playerCount
                    },
                    $set: {
                        updatedAt: Date.now()
                    }
                }
            );
        } catch (err) {
            log.error(`Error updating playlist stats for ${playlistId}:`, err);
        }
    }

    /**
     * Get server info for a playlist
     * @param {Object} playlist
     * @returns {Object} { ip: string, port: number, playlist: string }
     */
    static getServerInfo(playlist) {
        if (!playlist) return null;

        return {
            ip: playlist.serverIP,
            port: playlist.serverPort || 7777,
            playlist: playlist.playlistId,
            config: playlist.gamemodeConfig
        };
    }

    /**
     * Parse raw playlist name from bucketId
     * @param {string} rawPlaylist
     * @returns {string}
     */
    static parsePlaylistName(rawPlaylist) {
        // Convert various playlist formats to standardized format
        const playlistMap = {
            'solo': 'playlist_defaultsolo',
            'duo': 'playlist_defaultduo',
            'squad': 'playlist_defaultsquad',
            'solo_lategame': 'playlist_defaultsolo_lategame',
            'duo_lategame': 'playlist_defaultduo_lategame',
            'squad_lategame': 'playlist_defaultsquad_lategame'
        };

        const normalized = rawPlaylist.toLowerCase().trim();
        return playlistMap[normalized] || rawPlaylist;
    }

    /**
     * Find playlist by server IP and port (fallback)
     * @param {string} ip
     * @param {number} port
     * @returns {Promise<Object|null>}
     */
    static async findPlaylistByServer(ip, port) {
        try {
            const playlist = await Playlist.findOne({
                serverIP: ip,
                serverPort: port,
                isActive: true
            });
            return playlist;
        } catch (err) {
            log.error(`Error finding playlist by server ${ip}:${port}:`, err);
            return null;
        }
    }
}

module.exports = PlaylistHelper;
