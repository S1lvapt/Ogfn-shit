const XMLBuilder = require("xmlbuilder");
const uuid = require("uuid");
const bcrypt = require("bcrypt");
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

const User = require("../model/user.js");
const Profile = require("../model/profiles.js");
const profileManager = require("../structs/profile.js");
const Friends = require("../model/friends.js");
const SaCCodes = require("../model/saccodes.js");
const log = require("./log.js");

async function sleep(ms) {
    await new Promise((resolve, reject) => {
        setTimeout(resolve, ms);
    })
}

function GetVersionInfo(req) {
    let memory = {
        season: 0,
        build: 0.0,
        CL: "0",
        lobby: ""
    }

    if (req.headers["user-agent"]) {
        let CL = "";

        try {
            let BuildID = req.headers["user-agent"].split("-")[3].split(",")[0];

            if (!Number.isNaN(Number(BuildID))) CL = BuildID;
            else {
                BuildID = req.headers["user-agent"].split("-")[3].split(" ")[0];

                if (!Number.isNaN(Number(BuildID))) CL = BuildID;
            }
        } catch {
            try {
                let BuildID = req.headers["user-agent"].split("-")[1].split("+")[0];

                if (!Number.isNaN(Number(BuildID))) CL = BuildID;
            } catch {}
        }

        try {
            let Build = req.headers["user-agent"].split("Release-")[1].split("-")[0];

            if (Build.split(".").length == 3) {
                let Value = Build.split(".");
                Build = Value[0] + "." + Value[1] + Value[2];
            }

            memory.season = Number(Build.split(".")[0]);
            memory.build = Number(Build);
            memory.CL = CL;
            memory.lobby = `LobbySeason${memory.season}`;

            if (Number.isNaN(memory.season)) throw new Error();
        } catch {
            if (Number(memory.CL) < 3724489) {
                memory.season = 0;
                memory.build = 0.0;
                memory.CL = CL;
                memory.lobby = "LobbySeason0";
            } else if (Number(memory.CL) <= 3790078) {
                memory.season = 1;
                memory.build = 1.0;
                memory.CL = CL;
                memory.lobby = "LobbySeason1";
            } else {
                memory.season = 2;
                memory.build = 2.0;
                memory.CL = CL;
                memory.lobby = "LobbyWinterDecor";
            }
        }
    }

    return memory;
}

function getContentPages(req) {
    const memory = GetVersionInfo(req);

    const contentpages = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "responses", "contentpages.json")).toString());

    let Language = "en";

    try {
        if (req.headers["accept-language"]) {
            if (req.headers["accept-language"].includes("-") && req.headers["accept-language"] != "es-419") {
                Language = req.headers["accept-language"].split("-")[0];
            } else {
                Language = req.headers["accept-language"];
            }
        }
    } catch {}

    const modes = ["saveTheWorldUnowned", "battleRoyale", "creative", "saveTheWorld"];
    const news = ["savetheworldnews", "battleroyalenews"];

    try {
        modes.forEach(mode => {
            contentpages.subgameselectdata[mode].message.title = contentpages.subgameselectdata[mode].message.title[Language]
            contentpages.subgameselectdata[mode].message.body = contentpages.subgameselectdata[mode].message.body[Language]
        })
    } catch {}

    try {
        if (memory.build < 5.30) { 
            news.forEach(mode => {
                contentpages[mode].news.messages[0].image = "";
                contentpages[mode].news.messages[1].image = "";
            });
        }
    } catch {}

    try {
        contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = `season${memory.season}`;
        contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage = `season${memory.season}`;

        if (memory.season == 10) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "seasonx";
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage = "seasonx";
        }

        if (memory.build == 11.31 || memory.build == 11.40) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "Winter19";
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage = "Winter19";
        }

        if (memory.build == 19.01) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "winter2021";
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn.discordapp.com/attachments/927739901540188200/930880158167085116/t-bp19-lobby-xmas-2048x1024-f85d2684b4af.png";
            contentpages.subgameinfo.battleroyale.image = "https://cdn.discordapp.com/attachments/927739901540188200/930880421514846268/19br-wf-subgame-select-512x1024-16d8bb0f218f.jpg";
            contentpages.specialoffervideo.bSpecialOfferEnabled = "true";
        }

        if (memory.season == 20) {
            if (memory.build == 20.40) {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-bp20-40-armadillo-glowup-lobby-2048x2048-2048x2048-3b83b887cc7f.jpg"
            } else {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-bp20-lobby-2048x1024-d89eb522746c.png";
            }
        }

        if (memory.season == 21) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/s21-lobby-background-2048x1024-2e7112b25dc3.jpg"
            
            if (memory.build == 21.10) {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "season2100";
            }
            if (memory.build == 21.30) {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/nss-lobbybackground-2048x1024-f74a14565061.jpg"
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "season2130";
            }
        }

        if (memory.season == 22) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-bp22-lobby-square-2048x2048-2048x2048-e4e90c6e8018.jpg"
        }

        if (memory.season == 23) {
            if (memory.build == 23.10) {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-bp23-winterfest-lobby-square-2048x2048-2048x2048-277a476e5ca6.png"
                contentpages.specialoffervideo.bSpecialOfferEnabled = "true";
            } else {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-bp20-lobby-2048x1024-d89eb522746c.png";
            }
        }

        if (memory.season == 24) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-ch4s2-bp-lobby-4096x2048-edde08d15f7e.jpg"
        }

        if (memory.season == 25) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/s25-lobby-4k-4096x2048-4a832928e11f.jpg"
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/fn-shop-ch4s3-04-1920x1080-785ce1d90213.png"
            
            if (memory.build == 25.11) {
                contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage = "https://cdn2.unrealengine.com/t-s25-14dos-lobby-4096x2048-2be24969eee3.jpg"
            }
        }

        if (memory.season == 27) {
            contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "rufus";
        }
    } catch {}

    return contentpages;
}

function getItemShop() {
    try {
        const catalogPath = path.join(__dirname, "..", "responses", "catalog.json");
        const configPath = path.join(__dirname, "..", "Config", "catalog_config.json");
        
        // Validate files exist
        if (!fs.existsSync(catalogPath)) {
            log.error(`[ItemShop] Catalog file not found: ${catalogPath}`);
            return { storefronts: [] };
        }
        
        if (!fs.existsSync(configPath)) {
            log.error(`[ItemShop] Catalog config file not found: ${configPath}`);
            return { storefronts: [] };
        }
        
        const catalog = JSON.parse(fs.readFileSync(catalogPath).toString());
        const CatalogConfig = JSON.parse(fs.readFileSync(configPath).toString());
        
        if (!catalog || !catalog.storefronts) {
            log.error("[ItemShop] Catalog or storefronts is undefined");
            return { storefronts: [] };
        }
        
        // Ensure storefronts is an array
        if (!Array.isArray(catalog.storefronts)) {
            log.error("[ItemShop] Storefronts is not an array");
            return { storefronts: [] };
        }
        
        // Set expiration to far future so items don't expire
        const futureDate = new Date();
        futureDate.setFullYear(futureDate.getFullYear() + 10); // 10 years from now
        const isoDate = futureDate.toISOString();

        for (let value in CatalogConfig) {
            if (!Array.isArray(CatalogConfig[value].itemGrants)) continue;
            if (CatalogConfig[value].itemGrants.length == 0) continue;
            
            const CatalogEntry = {"devName":"","offerId":"","fulfillmentIds":[],"dailyLimit":-1,"weeklyLimit":-1,"monthlyLimit":-1,"categories":[],"prices":[{"currencyType":"MtxCurrency","currencySubType":"","regularPrice":0,"finalPrice":0,"saleExpiration":"9999-12-02T01:12:00Z","basePrice":0}],"meta":{"SectionId":"Featured","TileSize":"Small"},"matchFilter":"","filterWeight":0,"appStoreId":[],"requirements":[],"offerType":"StaticPrice","giftInfo":{"bIsEnabled":true,"forcedGiftBoxTemplateId":"","purchaseRequirements":[],"giftRecordIds":[]},"refundable":true,"metaInfo":[{"key":"SectionId","value":"Featured"},{"key":"TileSize","value":"Small"}],"displayAssetPath":"","itemGrants":[],"sortPriority":0,"catalogGroupPriority":0};

            let i = catalog.storefronts.findIndex(p => p.name == (value.toLowerCase().startsWith("daily") ? "BRDailyStorefront" : "BRWeeklyStorefront"));
            if (i == -1) continue;

            if (value.toLowerCase().startsWith("daily")) {
                CatalogEntry.sortPriority = -1;
            } else {
                CatalogEntry.meta.TileSize = "Normal";
                CatalogEntry.metaInfo[1].value = "Normal";
            }

            for (let itemGrant of CatalogConfig[value].itemGrants) {
                if (typeof itemGrant != "string") continue;
                if (itemGrant.length == 0) continue;

                CatalogEntry.requirements.push({ "requirementType": "DenyOnItemOwnership", "requiredId": itemGrant, "minQuantity": 1 });
                CatalogEntry.itemGrants.push({ "templateId": itemGrant, "quantity": 1 });
            }

            CatalogEntry.prices = [{
                "currencyType": "MtxCurrency",
                "currencySubType": "",
                "regularPrice": CatalogConfig[value].price,
                "finalPrice": CatalogConfig[value].price,
                "saleExpiration": isoDate,
                "basePrice": CatalogConfig[value].price
            }];

            if (CatalogEntry.itemGrants.length > 0) {
                let uniqueIdentifier = crypto.createHash("sha1").update(`${JSON.stringify(CatalogConfig[value].itemGrants)}_${CatalogConfig[value].price}`).digest("hex");

                // Derive a readable devName so frontend shows a friendly name instead of a hash
                let readable = null;
                const firstTemplateId = CatalogEntry.itemGrants[0] && CatalogEntry.itemGrants[0].templateId;
                if (firstTemplateId) {
                    const token = firstTemplateId.split(":")[1] || firstTemplateId;

                    // Generate display asset paths for in-game shop rendering
                    CatalogEntry.displayAssetPath = `/Game/Catalog/DisplayAssets/DA_Featured_${token}.DA_Featured_${token}`;
                    CatalogEntry["newDisplayAssetPath"] = `/Game/Catalog/NewDisplayAssets/DAv2_${token}.DAv2_${token}`;
                    CatalogEntry.metaInfo.push({ key: "NewDisplayAssetPath", value: `/Game/Catalog/NewDisplayAssets/DAv2_${token}.DAv2_${token}` });

                    // Clean up the name properly
                    readable = token
                        // Remove prefixes like CID_, BID_, etc with numbers
                        .replace(/^[A-Z]{2,3}_[A-Z]?_?\d+_/gi, '')
                        // Remove Athena patterns
                        .replace(/Athena_/gi, '')
                        // Remove Commando patterns
                        .replace(/Commando_[MF]_/gi, '')
                        // Remove Pickaxe/Glider prefixes
                        .replace(/^(Pickaxe|Glider)_ID_\d+_/gi, '')
                        // Remove technical suffixes (1 or more caps/numbers at end)
                        .replace(/_[A-Z0-9]+$/gi, '')
                        // Remove single letter suffixes (like _C, _F, _M)
                        .replace(/_[A-Z]$/gi, '')
                        // Remove numbers at the end
                        .replace(/_?\d+$/gi, '')
                        // Remove VIP, Default and other generic terms
                        .replace(/\b(VIP|Default|Rebirth)\b/gi, '')
                        // Replace underscores and dashes with spaces
                        .replace(/[_\-]+/g, ' ')
                        // Remove extra spaces
                        .replace(/\s+/g, ' ')
                        .trim();

                    // If name is too short or empty, extract meaningful parts
                    if (!readable || readable.length < 3) {
                        const parts = token.split('_').filter(p =>
                            p.length > 2 &&
                            !/^\d+$/.test(p) &&
                            !/^[A-Z]{1,3}$/.test(p) &&
                            !['Athena', 'Commando', 'Female', 'Male', 'ID', 'VIP', 'Default', 'Rebirth'].includes(p)
                        );
                        readable = parts.join(' ') || 'Item';
                    }

                    // If still problematic, use first grant type
                    if (readable.length < 3 || /^[A-Z]+$/.test(readable)) {
                        const itemType = firstTemplateId.split(':')[0] || 'Item';
                        readable = itemType.replace('Athena', '').replace(/([A-Z])/g, ' $1').trim() + ' Item';
                    }
                }

                if (!readable || readable.length < 3) readable = `offer_${uniqueIdentifier.slice(0,8)}`;

                CatalogEntry.devName = readable;
                CatalogEntry.offerId = uniqueIdentifier;

                // also store an explicit display name in metaInfo so other systems can pick it up
                CatalogEntry.metaInfo.push({ key: 'DisplayName', value: readable });

                catalog.storefronts[i].catalogEntries.push(CatalogEntry);
            }
        }

        // Final validation before returning
        if (!catalog.storefronts || !Array.isArray(catalog.storefronts)) {
            log.error("[ItemShop] Final validation failed - storefronts is invalid");
            return { storefronts: [] };
        }
        
        // Ensure refreshIntervalHrs exists
        if (!catalog.refreshIntervalHrs) {
            catalog.refreshIntervalHrs = 24;
        }
        
        // Ensure expiration exists
        if (!catalog.expiration) {
            const futureDate = new Date();
            futureDate.setFullYear(futureDate.getFullYear() + 10);
            catalog.expiration = futureDate.toISOString();
        }
        
        log.debug(`[ItemShop] Successfully generated catalog with ${catalog.storefronts.length} storefronts`);
        return catalog;
    } catch (error) {
        log.error("[ItemShop] Error in getItemShop:", error.message);
        log.error("[ItemShop] Stack trace:", error.stack);
        return { 
            refreshIntervalHrs: 24,
            dailyPurchaseHrs: 24,
            expiration: new Date(Date.now() + 10 * 365 * 24 * 60 * 60 * 1000).toISOString(),
            storefronts: [] 
        };
    }
}

function getOfferID(offerId) {
    const catalog = getItemShop();

    for (let storefront of catalog.storefronts) {
        let findOfferId = storefront.catalogEntries.find(i => i.offerId == offerId);

        if (findOfferId) return {
            name: storefront.name,
            offerId: findOfferId
        };
    }
}

function MakeID() {
    return uuid.v4();
}

function sendXmppMessageToAll(body) {
    if (!global.Clients) return;
    if (typeof body == "object") body = JSON.stringify(body);

    global.Clients.forEach(ClientData => {
        ClientData.client.send(XMLBuilder.create("message")
        .attribute("from", `xmpp-admin@${global.xmppDomain}`)
        .attribute("xmlns", "jabber:client")
        .attribute("to", ClientData.jid)
        .element("body", `${body}`).up().toString());
    });
}

function sendXmppMessageToId(body, toAccountId) {
    if (!global.Clients) return;
    if (typeof body == "object") body = JSON.stringify(body);

    let receiver = global.Clients.find(i => i.accountId == toAccountId);
    if (!receiver) return;

    receiver.client.send(XMLBuilder.create("message")
    .attribute("from", `xmpp-admin@${global.xmppDomain}`)
    .attribute("to", receiver.jid)
    .attribute("xmlns", "jabber:client")
    .element("body", `${body}`).up().toString());
}

function getPresenceFromUser(fromId, toId, offline) {
    if (!global.Clients) return;

    let SenderData = global.Clients.find(i => i.accountId == fromId);
    let ClientData = global.Clients.find(i => i.accountId == toId);

    if (!SenderData || !ClientData) return;

    let xml = XMLBuilder.create("presence")
    .attribute("to", ClientData.jid)
    .attribute("xmlns", "jabber:client")
    .attribute("from", SenderData.jid)
    .attribute("type", offline ? "unavailable" : "available")

    if (SenderData.lastPresenceUpdate.away) xml = xml.element("show", "away").up().element("status", SenderData.lastPresenceUpdate.status).up();
    else xml = xml.element("status", SenderData.lastPresenceUpdate.status).up();

    ClientData.client.send(xml.toString());
}

async function registerUser(discordId, username, email, plainPassword, savePlainPassword = false, donator = false, mediumDonator = false, ultimateDonator = false) {
    email = email.toLowerCase();

    if (!username || !email || !plainPassword) {
        return { message: "Username, email, or password is required.", status: 400 };
    }

    if (discordId && await User.findOne({ discordId })) {
        return { message: "You already created an account!", status: 400 };
    }

    if (await User.findOne({ email })) {
        return { message: "Email is already in use.", status: 400 };
    }

    const accountId = MakeID().replace(/-/ig, "");
    const matchmakingId = MakeID().replace(/-/ig, "");

    const emailFilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!emailFilter.test(email)) {
        return { message: "You did not provide a valid email address.", status: 400 };
    }
    if (username.length >= 25) {
        return { message: "Your username must be less than 25 characters long.", status: 400 };
    }
    if (username.length < 3) {
        return { message: "Your username must be at least 3 characters long.", status: 400 };
    }
    if (plainPassword.length >= 128) {
        return { message: "Your password must be less than 128 characters long.", status: 400 };
    }
    if (plainPassword.length < 4) {
        return { message: "Your password must be at least 4 characters long.", status: 400 };
    }

    const allowedCharacters = (" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~").split("");
    for (let character of username) {
        if (!allowedCharacters.includes(character)) {
            return { message: "Your username has special characters, please remove them and try again.", status: 400 };
        }
    }

    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    try {
        const userData = {
            created: new Date().toISOString(),
            accountId,
            username,
            username_lower: username.toLowerCase(),
            email,
            password: hashedPassword,
            externalPassword: savePlainPassword ? plainPassword : null,
            matchmakingId,
            // Donator flags
            donator: donator || false,
            mediumDonator: mediumDonator || false,
            ultimateDonator: ultimateDonator || false
        };

        if (discordId) {
            userData.discordId = discordId;
        }

        const i = await User.create(userData);

        const defaultProfiles = profileManager.createProfiles(i.accountId);
        await Profile.create({ created: i.created, accountId: i.accountId, profiles: defaultProfiles });
        await Friends.create({ created: i.created, accountId: i.accountId });
        profileManager.createUserStatsProfiles(i.accountId);

        // Initialize user numeric stats from default profiles
        try {
            let vbucks = 0;
            try {
                const commonCore = defaultProfiles['common_core'];
                if (commonCore && commonCore.items) {
                    const vItem = commonCore.items['Currency:MtxPurchased'] || commonCore.items['Currency:MtxPremium'] || Object.values(commonCore.items).find(it => it.templateId && (it.templateId.includes('Currency:MtxPurchased') || it.templateId.includes('Currency:MtxPremium')));
                    if (vItem) vbucks = vItem.quantity || 0;
                }
            } catch (e){}

            let level = 1;
            let wins = 0;
            try {
                const athena = defaultProfiles['athena'];
                if (athena && athena.stats && athena.stats.attributes) {
                    level = athena.stats.attributes.level || athena.stats.attributes.accountLevel || 1;
                    wins = athena.stats.attributes.lifetime_wins || athena.stats.attributes.wins || 0;
                }
            } catch (e){}

            await User.updateOne({ _id: i._id }, { $set: {
                vbucks: Number(vbucks),
                level: Number(level),
                wins: Number(wins),
                kills: 0,
                deaths: 0,
                matchesPlayed: 0
            }});
        } catch (err) {
            // ignore initialization errors
        }
    } catch (err) {
        if (err.code == 11000) {
            return { message: `Username or email is already in use.`, status: 400 };
        }

        return { message: "An unknown error has occurred, please try again later.", status: 400 };
    }

    return { message: `Successfully created an account with the username **${username}**`, status: 200 };
}

async function createSAC(code, username, creator) {
    if (!code || !username) return {message: "**Code** or **Ingame Username** is required.", status: 400 };

    const account = await User.findOne({ username })

    if (account == null) return { message: `**${username}** doesnt exist!`}

    if (await SaCCodes.findOne({ code })) return { message: `**${code}** already exist!`, status: 400}; 

    if (await SaCCodes.findOne({ owneraccountId: account.accountId })) return { message: `**${username}** already has an **Code** (**${code}**)!`, status: 400};
    const creatorprofile = (await User.findOne({ discordId: creator }))

    const allowedCharacters = ("!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~").split("");
    for (let character of allowedCharacters) {
        if (!allowedCharacters.includes(character)) return { message: "The Code has special Characters!", status: 400 };
    }

    try {
        await SaCCodes.create({ created: new Date().toISOString(), createdby: creatorprofile.accountId, owneraccountId: account.accountId , code, code_lower: code.toLowerCase(), code_higher: code.toUpperCase()})
    } catch (error) {
        return { message: error, status: 400}
    }

    return { message: "You successfully created an **Support a Creator** Code!", status: 200}
}

function PlaylistNames(playlist) {
    switch (playlist) {
        case "2":
            return "Playlist_DefaultSolo";
        case "10":
            return "Playlist_DefaultDuo";
        case "9":
            return "Playlist_DefaultSquad";
        case "50":
            return "Playlist_50v50";
        case "11":
            return "Playlist_50v50";
        case "13":
            return "Playlist_HighExplosives_Squads";
        case "22":
            return "Playlist_5x20";
        case "36":
            return "Playlist_Blitz_Solo";
        case "37":
            return "Playlist_Blitz_Duos";
        case "19":
            return "Playlist_Blitz_Squad";
        case "33":
            return "Playlist_Carmine";
        case "32":
            return "Playlist_Fortnite";
        case "23":
            return "Playlist_HighExplosives_Solo";
        case "24":
            return "Playlist_HighExplosives_Squads";
        case "44":
            return "Playlist_Impact_Solo";
        case "45":
            return "Playlist_Impact_Duos";
        case "46":
            return "Playlist_Impact_Squads";
        case "35":
            return "Playlist_Playground";
        case "30":
            return "Playlist_SkySupply";
        case "42":
            return "Playlist_SkySupply_Duos";
        case "43":
            return "Playlist_SkySupply_Squads";
        case "41":
            return "Playlist_Snipers";
        case "39":
            return "Playlist_Snipers_Solo";
        case "40":
            return "Playlist_Snipers_Duos";
        case "26":
            return "Playlist_SolidGold_Solo";
        case "27":
            return "Playlist_SolidGold_Squads";
        case "28":
            return "Playlist_ShowdownAlt_Solo";
        case "solo":
            return "2";
        case "duo":
            return "10";
        case "squad":
            return "9";
        default:
            return playlist;
    }
}

function DecodeBase64(str) {
    return Buffer.from(str, 'base64').toString();
}

function UpdateTokens() {
    try {
        // Ensure tokenManager directory exists
        if (!fs.existsSync("./tokenManager")) {
            fs.mkdirSync("./tokenManager", { recursive: true });
        }

        fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify({
            accessTokens: global.accessTokens,
            refreshTokens: global.refreshTokens,
            clientTokens: global.clientTokens
        }, null, 2));
    } catch (error) {
        console.error("Error updating tokens:", error);
        // Try to create with default empty tokens
        try {
            if (!fs.existsSync("./tokenManager")) {
                fs.mkdirSync("./tokenManager", { recursive: true });
            }
            fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify({
                accessTokens: [],
                refreshTokens: [],
                clientTokens: []
            }, null, 2));
        } catch (retryError) {
            console.error("Failed to create tokens.json:", retryError);
        }
    }
}

module.exports = {
    sleep,
    GetVersionInfo,
    getContentPages,
    getItemShop,
    getOfferID,
    MakeID,
    sendXmppMessageToAll,
    sendXmppMessageToId,
    getPresenceFromUser,
    registerUser,
    createSAC,
    PlaylistNames,
    DecodeBase64,
    UpdateTokens
}