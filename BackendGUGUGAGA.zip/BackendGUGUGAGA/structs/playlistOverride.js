const fs = require('fs');
const path = require('path');

class PlaylistOverride {
    constructor() {
        this.overrides = this.load();
    }

    load() {
        try {
            const file = path.join(__dirname, '..', 'Config', 'playlist_overrides.json');
            if (fs.existsSync(file)) {
                return JSON.parse(fs.readFileSync(file, 'utf8'));
            }
        } catch (err) {
            console.error('[PlaylistOverride] Erro:', err);
        }
        return {};
    }

    get(playlistName) {
        return this.overrides[playlistName] || null;
    }

    apply(playlistName, data) {
        const override = this.get(playlistName);
        if (!override) return data;

        return {
            ...data,
            displayName: override.name || data.displayName,
            description: override.description || data.description,
            subtitle: override.subtitle,
            rules: override.rules,
            images: override.images,
            colors: override.colors
        };
    }
}

module.exports = new PlaylistOverride();
