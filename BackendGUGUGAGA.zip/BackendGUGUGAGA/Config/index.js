const fs = require('fs');
const path = require('path');

let config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json')).toString());

// Try to decrypt sensitive fields if crypto module is available
try {
    const { decryptConfig } = require('../structs/crypto.js');
    config = decryptConfig(config);
} catch (error) {
    // Crypto module not available or decryption failed, use raw values
}

module.exports = config;
