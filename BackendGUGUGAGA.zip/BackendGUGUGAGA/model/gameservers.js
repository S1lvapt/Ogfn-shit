const mongoose = require("mongoose");

const GameServerSchema = new mongoose.Schema({
    serverId: { type: String, required: true, unique: true },
    ip: { type: String, required: true },
    port: { type: Number, required: true },
    region: { type: String, default: "EU" },

    // Server Phase (reported by game server: setting_up -> joinable -> in_match)
    serverPhase: {
        type: String,
        enum: ['setting_up', 'joinable', 'in_match'],
        default: 'setting_up'
    },

    // Server Status
    status: {
        type: String,
        enum: ['online', 'offline', 'starting', 'stopping', 'maintenance'],
        default: 'offline'
    },

    // Current Match Info
    currentMatch: {
        matchId: String,
        playlist: String,
        playersInMatch: { type: Number, default: 0 },
        maxPlayers: { type: Number, default: 100 },
        matchStarted: Date,
        phase: {
            type: String,
            enum: ['waiting', 'warmup', 'aircraft', 'gameplay', 'endgame', 'finished'],
            default: 'waiting'
        }
    },

    // Supported Playlists
    supportedPlaylists: [{ type: String }],

    // Server Capabilities
    maxPlayers: { type: Number, default: 100 },
    maxConcurrentMatches: { type: Number, default: 1 },

    // Health & Performance
    health: {
        lastHeartbeat: Date,
        cpu: { type: Number, default: 0 },
        memory: { type: Number, default: 0 },
        ping: { type: Number, default: 0 },
        uptime: { type: Number, default: 0 }
    },

    // Statistics
    stats: {
        totalMatches: { type: Number, default: 0 },
        totalPlayers: { type: Number, default: 0 },
        averageMatchDuration: { type: Number, default: 0 },
        lastMatchDate: Date
    },

    // Configuration
    config: {
        autoRestart: { type: Boolean, default: true },
        restartAfterMatches: { type: Number, default: 50 },
        enabled: { type: Boolean, default: true }
    },

    // Metadata
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    lastOnline: Date
}, {
    collection: "gameservers"
});

// Index for fast lookups
GameServerSchema.index({ serverId: 1 });
GameServerSchema.index({ status: 1, 'config.enabled': 1 });
GameServerSchema.index({ supportedPlaylists: 1, status: 1 });
GameServerSchema.index({ 'health.lastHeartbeat': 1 });

// Update timestamp on save
GameServerSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

const model = mongoose.model('GameServers', GameServerSchema);

module.exports = model;