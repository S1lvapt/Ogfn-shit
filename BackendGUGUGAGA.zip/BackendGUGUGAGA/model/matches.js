const mongoose = require("mongoose");

const MatchSchema = new mongoose.Schema({
    matchId: { type: String, required: true, unique: true },
    sessionId: { type: String, required: true },

    // Match Configuration
    playlist: { type: String, required: true },
    region: { type: String, default: "EU" },
    gamemode: { type: String, default: "BR" },

    // Server Info
    serverId: { type: String, required: true },
    serverIP: { type: String, required: true },
    serverPort: { type: Number, required: true },

    // Match Status
    status: {
        type: String,
        enum: ['waiting', 'warmup', 'starting', 'active', 'ending', 'finished', 'cancelled'],
        default: 'waiting'
    },

    // Players
    players: [{
        accountId: String,
        displayName: String,
        joinedAt: Date,
        leftAt: Date,
        placement: Number,
        kills: { type: Number, default: 0 },
        damage: { type: Number, default: 0 },
        survived: { type: Number, default: 0 } // seconds
    }],

    maxPlayers: { type: Number, default: 100 },
    currentPlayers: { type: Number, default: 0 },

    // Match Timeline
    timeline: {
        created: { type: Date, default: Date.now },
        warmupStarted: Date,
        matchStarted: Date,
        matchEnded: Date,
        duration: Number // seconds
    },

    // Match Settings
    settings: {
        buildingEnabled: { type: Boolean, default: true },
        stormPhase: { type: Number, default: 1 },
        lootMultiplier: { type: Number, default: 1.0 },
        customSettings: Object
    },

    // Match Results
    results: {
        winner: {
            accountId: String,
            displayName: String,
            kills: Number,
            damage: Number
        },
        totalKills: { type: Number, default: 0 },
        averagePlacement: Number,
        matchDuration: Number
    },

    // Metadata
    buildVersion: String,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
}, {
    collection: "matches"
});

// Indexes for performance
MatchSchema.index({ matchId: 1 });
MatchSchema.index({ sessionId: 1 });
MatchSchema.index({ serverId: 1, status: 1 });
MatchSchema.index({ playlist: 1, status: 1 });
MatchSchema.index({ 'players.accountId': 1 });
MatchSchema.index({ createdAt: -1 });
MatchSchema.index({ status: 1, 'timeline.created': -1 });

// Update timestamp on save
MatchSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

const model = mongoose.model('Matches', MatchSchema);

module.exports = model;
