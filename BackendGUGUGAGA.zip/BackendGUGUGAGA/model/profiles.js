const mongoose = require("mongoose");

const ProfilesSchema = new mongoose.Schema(
    {
        created: { type: Date, required: true },
        accountId: { type: String, required: true, unique: true },
        profiles: { type: Object, required: true }
    },
    {
        collection: "profiles"
    }
)

// Index already created by unique: true on accountId
// No need to create duplicate index

const model = mongoose.model('ProfilesSchema', ProfilesSchema);

module.exports = model;