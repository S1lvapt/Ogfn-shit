const mongoose = require("mongoose");

const GamemodeSchema = new mongoose.Schema({
    // Basic Info
    gamemodeId: { type: String, required: true, unique: true }, // e.g., "lategame_solo_v1"
    gamemodeName: { type: String, required: true }, // e.g., "Late Game Practice"
    description: { type: String, default: "" },
    category: {
        type: String,
        enum: ['standard', 'lategame', 'practice', 'ltm', 'tournament', 'creative'],
        default: 'standard'
    },

    // Linked Playlists (which playlists use this gamemode)
    linkedPlaylists: [{ type: String }],

    // Advanced Configuration
    advancedSettings: {
        // Zone Configuration
        zones: [
            {
                phaseNumber: Number, // 1-9
                radius: Number, // meters
                shrinkTime: Number, // seconds
                waitTime: Number, // seconds before shrinking
                damagePerTick: Number
            }
        ],

        // Spawn Configuration
        spawnLocations: {
            type: {
                type: String,
                enum: ['random', 'fixed', 'circle_based'],
                default: 'random'
            },
            locations: [
                {
                    x: Number,
                    y: Number,
                    z: Number
                }
            ]
        },

        // Weapon Configuration
        weaponSettings: {
            allowedWeapons: [String], // Array of weapon IDs
            bannedWeapons: [String],
            weaponDamageMultiplier: { type: Number, default: 1.0 },
            headshotMultiplier: { type: Number, default: 2.0 }
        },

        // Item Configuration
        itemSettings: {
            allowedItems: [String],
            bannedItems: [String],
            maxItemsPerSlot: { type: Number, default: 999 }
        },

        // Building Configuration
        buildingSettings: {
            buildingEnabled: { type: Boolean, default: true },
            maxWood: { type: Number, default: 999 },
            maxStone: { type: Number, default: 999 },
            maxMetal: { type: Number, default: 999 },
            buildingHealthMultiplier: { type: Number, default: 1.0 },
            turboBuilding: { type: Boolean, default: true }
        },

        // Movement Configuration
        movementSettings: {
            sprintMultiplier: { type: Number, default: 1.0 },
            jumpHeight: { type: Number, default: 1.0 },
            fallDamageMultiplier: { type: Number, default: 1.0 },
            gliderRedeploy: { type: Boolean, default: false }
        },

        // Healing Configuration
        healingSettings: {
            healingItemMultiplier: { type: Number, default: 1.0 },
            shieldItemMultiplier: { type: Number, default: 1.0 },
            maxHealing: { type: Number, default: 100 },
            maxShield: { type: Number, default: 100 },
            regenHealth: { type: Boolean, default: false },
            regenRate: { type: Number, default: 0 } // HP per second
        }
    },

    // Scoring & XP
    scoring: {
        killPoints: { type: Number, default: 25 },
        winPoints: { type: Number, default: 50 },
        placementMultiplier: { type: Number, default: 1.0 },
        xpEnabled: { type: Boolean, default: true },
        xpMultiplier: { type: Number, default: 1.0 }
    },

    // Status
    isActive: { type: Boolean, default: true },
    isBeta: { type: Boolean, default: false },

    // Metadata
    version: { type: String, default: "1.0.0" },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    createdBy: { type: String, default: "system" }
}, {
    collection: "gamemodes"
});

// Indexes for query optimization
GamemodeSchema.index({ isActive: 1, createdAt: -1 });
GamemodeSchema.index({ gamemodeId: 1, isActive: 1 });
GamemodeSchema.index({ category: 1, isActive: 1 });

// Update timestamp on save
GamemodeSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

const model = mongoose.model('Gamemodes', GamemodeSchema);

module.exports = model;
