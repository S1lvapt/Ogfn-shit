const mongoose = require("mongoose");

const NewsSchema = new mongoose.Schema(
    {
        title: { type: String, required: true },
        content: { type: String, required: true },
        author: { type: String, required: true },
        authorId: { type: String, required: true },
        createdAt: { type: Date, default: Date.now },
        pinned: { type: Boolean, default: false }
    },
    {
        collection: "news"
    }
)

const model = mongoose.model('NewsSchema', NewsSchema);

module.exports = model;
