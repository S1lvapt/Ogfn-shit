const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema(
    {
        created: { type: Date, required: true },
        banned: { type: Boolean, default: false },
        discordId: { type: String, default: null, sparse: true },
        accountId: { type: String, required: true, unique: true },
        username: { type: String, required: true, unique: true },
        username_lower: { type: String, required: true, unique: true },
        email: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        externalPassword: { type: String, default: null },
        matchmakingId: { type: String, required: true, unique: true},
        isServer: { type: Boolean, default: false},
        currentSACCode: { type: String, default: null },
        // Donator tiers (permanent - never removed even if user leaves Discord)
        // basic=green, medium=blue, high=orange, ultimate=purple
        basicDonator: { type: Boolean, default: false },
        mediumDonator: { type: Boolean, default: false },
        highDonator: { type: Boolean, default: false },
        ultimateDonator: { type: Boolean, default: false },
        // Legacy field for compatibility (same as basicDonator)
        donator: { type: Boolean, default: false },
        // Track which benefits were already given (to avoid duplicates)
        benefitsGiven: {
            basic: { type: Boolean, default: false },      // Priority MM given
            medium: { type: Boolean, default: false },     // 5k vbucks given
            high: { type: Boolean, default: false },       // Skins + 2k vbucks given
            ultimate: { type: Boolean, default: false }    // All cosmetics + 10k vbucks given
        },
        // Date when each tier was obtained (for records)
        donatorSince: {
            basic: { type: Date, default: null },
            medium: { type: Date, default: null },
            high: { type: Date, default: null },
            ultimate: { type: Date, default: null }
        },
        // Discord profile info
        discordUsername: { type: String, default: null },
        discordAvatar: { type: String, default: null },
        discordAvatarDecorationData: { type: Object, default: null },
        discordProfilePicture: { type: String, default: null },
        // Player stats - SINGLE SOURCE OF TRUTH (no duplications!)
        level: { type: Number, default: 1 },
        xp: { type: Number, default: 0 },
        vbucks: { type: Number, default: 0 },
        lastRewardClaim: { type: Number, default: null },
        lastUsernameChange: { type: Date, default: null },
        // Game stats
        wins: { type: Number, default: 0 },
        kills: { type: Number, default: 0 },
        deaths: { type: Number, default: 0 },
        matchesPlayed: { type: Number, default: 0 },
        currentServerId: { type: String, default: null },  // server player is currently on
        matchJoinedAt: { type: Date, default: null },      // when player joined the server
        // Arena/Competitive stats
        hype: { type: Number, default: 0 },  // Arena points (formerly arenaPoints)
        division: { type: Number, default: 0 },  // Arena division (0-7)
        avatarDecoration: { type: String, default: null },
        // Admin flag
        isAdmin: { type: Boolean, default: false },
        // HWID (Hardware ID) tracking
        currentHWID: { type: String, default: null },
        hwidHistory: [{ type: String }],
        lastHWIDUpdate: { type: Date, default: null },
        // Leaderboard visibility � se false, o user n�o aparece em nenhuma leaderboard
        showInLeaderboard: { type: Boolean, default: true }
    },
    {
        collection: "users"
    }
)
const model = mongoose.model('UserSchema', UserSchema);
module.exports = model;