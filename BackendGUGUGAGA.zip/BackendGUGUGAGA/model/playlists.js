const mongoose = require("mongoose");

const PlaylistSchema = new mongoose.Schema({
    // Basic Info
    playlistId: { type: String, required: true, unique: true }, // e.g., "playlist_defaultsolo_lategame"
    playlistName: { type: String, required: true }, // e.g., "Solo Late Game"
    description: { type: String, default: "" },

    // Playlist Type
    playlistType: {
        type: String,
        enum: ['solo', 'duo', 'trio', 'squad', 'ltm', 'creative', 'arena'],
        required: true
    },

    // Server Configuration
    serverIP: { type: String, required: true },
    serverPort: { type: Number, required: false },

    // Game Mode Configuration
    gamemodeConfig: {
        // Storm Configuration
        stormPhase: { type: Number, default: 1 }, // Which storm circle to start at (1-9)
        stormSpeed: { type: Number, default: 1.0 }, // Storm movement speed multiplier
        stormDamage: { type: Number, default: 1.0 }, // Storm damage multiplier
        stormWaitTime: { type: Number, default: 180 }, // Time before first storm (seconds)

        // Loot Configuration
        lootMultiplier: { type: Number, default: 1.0 },
        maxShields: { type: Number, default: 100 },
        maxHealth: { type: Number, default: 100 },
        startingHealth: { type: Number, default: 100 },
        startingShields: { type: Number, default: 0 },

        // Starting Inventory (for late game)
        startingInventory: {
            enabled: { type: Boolean, default: false },
            items: [
                {
                    itemId: String, // e.g., "WID_Assault_AutoHigh_Athena_SR_Ore_T03"
                    quantity: Number,
                    slot: Number // 0-5
                }
            ],
            materials: {
                wood: { type: Number, default: 0 },
                stone: { type: Number, default: 0 },
                metal: { type: Number, default: 0 }
            }
        },

        // Player Configuration
        maxPlayers: { type: Number, default: 100 },
        minPlayers: { type: Number, default: 1 },
        respawnEnabled: { type: Boolean, default: false },

        // Match Settings
        matchTimeLimit: { type: Number, default: 1500 }, // 25 minutes in seconds
        warmupTime: { type: Number, default: 30 },

        // Special Rules
        buildingEnabled: { type: Boolean, default: true },
        editingEnabled: { type: Boolean, default: true },
        fallDamageEnabled: { type: Boolean, default: true },
        friendlyFire: { type: Boolean, default: false },

        // Loot Pool
        lootTier: {
            type: String,
            enum: ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mixed'],
            default: 'mixed'
        }
    },

    // Display Settings
    displayPriority: { type: Number, default: 0 }, // Higher = shown first
    isActive: { type: Boolean, default: true },
    isVisible: { type: Boolean, default: true }, // Show in playlist selection

    // Requirements
    requirements: {
        minLevel: { type: Number, default: 0 },
        requiredDonatorTier: {
            type: String,
            enum: ['none', 'basic', 'medium', 'high', 'ultimate'],
            default: 'none'
        }
    },

    // Statistics
    totalMatches: { type: Number, default: 0 },
    totalPlayers: { type: Number, default: 0 },

    // Metadata
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    createdBy: { type: String, default: "system" }
}, {
    collection: "playlists"
});

// Indexes for query optimization
PlaylistSchema.index({ isActive: 1, isVisible: 1, displayPriority: -1 });
PlaylistSchema.index({ playlistId: 1, isActive: 1 });
PlaylistSchema.index({ playlistType: 1, isActive: 1 });
PlaylistSchema.index({ displayPriority: -1 });

// Update timestamp on save
PlaylistSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

const model = mongoose.model('Playlists', PlaylistSchema);

module.exports = model;
