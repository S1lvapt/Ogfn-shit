const mongoose = require("mongoose");

const HWIDBanSchema = new mongoose.Schema({
    hwid: { type: String, required: true, unique: true, index: true },
    accountId: { type: String, required: true },
    username: { type: String, required: true },
    reason: { type: String, default: "No reason provided" },
    bannedBy: { type: String, default: "System" },
    bannedAt: { type: Date, default: Date.now },
    expiresAt: { type: Date, default: null }, // null = permanent
    isPermanent: { type: Boolean, default: true },
    notes: { type: String, default: "" },
}, {
    collection: "hwidbans"
});

// Index para busca rápida
HWIDBanSchema.index({ hwid: 1 });
HWIDBanSchema.index({ accountId: 1 });

module.exports = mongoose.model("HWIDBan", HWIDBanSchema);
