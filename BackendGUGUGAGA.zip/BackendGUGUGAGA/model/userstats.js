const mongoose = require("mongoose");

const UserStatsSchema = new mongoose.Schema({
    accountId: { type: String, required: true, unique: true },
    displayName: { type: String, required: true },

    // Total Stats
    totalKills: { type: Number, default: 0 },
    totalWins: { type: Number, default: 0 },
    totalMatches: { type: Number, default: 0 },
    totalPoints: { type: Number, default: 0 },
    totalDamage: { type: Number, default: 0 },

    // Points Breakdown
    pointsFromKills: { type: Number, default: 0 },
    pointsFromWins: { type: Number, default: 0 },
    pointsFromPlacement: { type: Number, default: 0 },

    // Best Records
    bestPlacement: { type: Number, default: 100 },
    highestKillGame: { type: Number, default: 0 },
    longestWinStreak: { type: Number, default: 0 },
    currentWinStreak: { type: Number, default: 0 },

    // Match History (last 20 matches)
    matchHistory: [{
        matchId: String,
        kills: Number,
        placement: Number,
        damage: Number,
        points: Number,
        date: Date,
        hasWon: Boolean
    }],

    // Rankings
    rank: { type: Number, default: 0 },
    rankTier: {
        type: String,
        enum: ['bronze', 'silver', 'gold', 'platinum', 'diamond', 'master', 'champion'],
        default: 'bronze'
    },

    // Metadata
    lastPlayed: { type: Date, default: Date.now },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
}, {
    collection: "userstats"
});

// Indexes for leaderboards and fast lookups
UserStatsSchema.index({ totalPoints: -1 });
UserStatsSchema.index({ accountId: 1 });
UserStatsSchema.index({ totalKills: -1 });
UserStatsSchema.index({ totalWins: -1 });
UserStatsSchema.index({ rank: 1 });

// Update timestamp on save
UserStatsSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

// Calculate rank tier based on points
UserStatsSchema.methods.calculateRankTier = function() {
    if (this.totalPoints >= 10000) this.rankTier = 'champion';
    else if (this.totalPoints >= 7500) this.rankTier = 'master';
    else if (this.totalPoints >= 5000) this.rankTier = 'diamond';
    else if (this.totalPoints >= 2500) this.rankTier = 'platinum';
    else if (this.totalPoints >= 1000) this.rankTier = 'gold';
    else if (this.totalPoints >= 500) this.rankTier = 'silver';
    else this.rankTier = 'bronze';
};

const model = mongoose.model("UserStatsSchema", UserStatsSchema);

module.exports = model;