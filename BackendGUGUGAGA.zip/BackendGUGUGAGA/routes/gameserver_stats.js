/**
 * GameServer Stats API
 * Receives stats from gameserver and saves to MongoDB
 */

const express = require("express");
const app = express.Router();
const log = require("../structs/log.js");
const UserStats = require("../model/userstats.js");
const User = require("../model/user.js");
const Match = require("../model/matches.js");
const config = require("../Config/config.json");

// Simple API key verification
function verifyGameServerAuth(req, res, next) {
    const apiKey = req.headers['x-gameserver-key'] || req.headers['authorization'];
    const serverId = req.headers['x-server-id'];

    if (!apiKey || apiKey !== config.Api.bApiKey) {
        return res.status(401).json({
            error: "Unauthorized",
            message: "Invalid or missing API key"
        });
    }

    if (!serverId) {
        return res.status(400).json({
            error: "Bad Request",
            message: "Missing X-Server-ID header"
        });
    }

    req.serverId = serverId;
    next();
}

/**
 * Kill Event
 * Called when a player gets a kill
 */
app.post("/api/gameserver/stats/kill", verifyGameServerAuth, async (req, res) => {
    try {
        const { accountId, kills, points, matchId } = req.body;

        if (!accountId || kills === undefined || points === undefined) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing required fields"
            });
        }

        // Get or create user stats
        let userStats = await UserStats.findOne({ accountId });
        const user = await User.findOne({ accountId });

        if (!userStats) {
            userStats = new UserStats({
                accountId: accountId,
                displayName: user ? user.displayName : "Unknown"
            });
        }

        // Update kills and points
        userStats.totalKills += 1;
        userStats.totalPoints += points;
        userStats.pointsFromKills += points;

        // Update best records
        if (kills > userStats.highestKillGame) {
            userStats.highestKillGame = kills;
        }

        // Calculate rank tier
        userStats.calculateRankTier();

        userStats.lastPlayed = new Date();
        await userStats.save();

        log.debug(`[GameServer Stats] Kill recorded for ${accountId} (+${points} points)`);

        res.json({
            success: true,
            totalPoints: userStats.totalPoints,
            totalKills: userStats.totalKills
        });

    } catch (err) {
        log.error("[GameServer Stats] Kill error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Placement Event
 * Called when a player finishes with a placement
 */
app.post("/api/gameserver/stats/placement", verifyGameServerAuth, async (req, res) => {
    try {
        const { accountId, placement, points, matchId } = req.body;

        if (!accountId || placement === undefined || points === undefined) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing required fields"
            });
        }

        // Get or create user stats
        let userStats = await UserStats.findOne({ accountId });
        const user = await User.findOne({ accountId });

        if (!userStats) {
            userStats = new UserStats({
                accountId: accountId,
                displayName: user ? user.displayName : "Unknown"
            });
        }

        // Update placement stats
        userStats.totalPoints += points;
        userStats.pointsFromPlacement += points;

        // Update best placement
        if (placement < userStats.bestPlacement) {
            userStats.bestPlacement = placement;
        }

        // Calculate rank tier
        userStats.calculateRankTier();

        userStats.lastPlayed = new Date();
        await userStats.save();

        log.debug(`[GameServer Stats] Placement #${placement} recorded for ${accountId} (+${points} points)`);

        res.json({
            success: true,
            totalPoints: userStats.totalPoints,
            placement: placement
        });

    } catch (err) {
        log.error("[GameServer Stats] Placement error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Win Event
 * Called when a player wins the match
 */
app.post("/api/gameserver/stats/win", verifyGameServerAuth, async (req, res) => {
    try {
        const { accountId, points, matchId } = req.body;

        if (!accountId || points === undefined) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing required fields"
            });
        }

        // Get or create user stats
        let userStats = await UserStats.findOne({ accountId });
        const user = await User.findOne({ accountId });

        if (!userStats) {
            userStats = new UserStats({
                accountId: accountId,
                displayName: user ? user.displayName : "Unknown"
            });
        }

        // Update win stats
        userStats.totalWins += 1;
        userStats.totalPoints += points;
        userStats.pointsFromWins += points;
        userStats.bestPlacement = 1;
        userStats.currentWinStreak += 1;

        // Update longest win streak
        if (userStats.currentWinStreak > userStats.longestWinStreak) {
            userStats.longestWinStreak = userStats.currentWinStreak;
        }

        // Calculate rank tier
        userStats.calculateRankTier();

        userStats.lastPlayed = new Date();
        await userStats.save();

        log.backend(`[GameServer Stats] WIN recorded for ${user ? user.displayName : accountId} (+${points} points)`);

        res.json({
            success: true,
            totalPoints: userStats.totalPoints,
            totalWins: userStats.totalWins,
            winStreak: userStats.currentWinStreak
        });

    } catch (err) {
        log.error("[GameServer Stats] Win error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Get Player Stats
 */
app.get("/api/stats/:accountId", async (req, res) => {
    try {
        const userStats = await UserStats.findOne({ accountId: req.params.accountId });

        if (!userStats) {
            return res.status(404).json({
                error: "Not Found",
                message: "Player stats not found"
            });
        }

        res.json({
            success: true,
            stats: userStats
        });

    } catch (err) {
        log.error("[GameServer Stats] Get stats error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Leaderboard
 */
app.get("/api/leaderboard", async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const type = req.query.type || 'points'; // points, kills, wins

        let sortField = {};
        if (type === 'kills') sortField = { totalKills: -1 };
        else if (type === 'wins') sortField = { totalWins: -1 };
        else sortField = { totalPoints: -1 };

        const leaderboard = await UserStats.find({})
            .sort(sortField)
            .limit(limit)
            .select('accountId displayName totalPoints totalKills totalWins rankTier bestPlacement')
            .lean();

        // Add rank positions
        const rankedLeaderboard = leaderboard.map((player, index) => ({
            ...player,
            rank: index + 1
        }));

        res.json({
            success: true,
            leaderboard: rankedLeaderboard,
            type: type
        });

    } catch (err) {
        log.error("[GameServer Stats] Leaderboard error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

module.exports = app;
