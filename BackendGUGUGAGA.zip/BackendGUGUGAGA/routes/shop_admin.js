const express = require("express");
const app = express.Router();
const fs = require("fs");
const path = require("path");
const log = require("../structs/log.js");
const axios = require("axios");

// Cache para itens (evita requests repetidos à API)
let itemsCache = null;
let cacheTimestamp = null;
const CACHE_DURATION = 3600000; // 1 hora

// Middleware simples de autenticação (você pode melhorar isso)
function requireAdmin(req, res, next) {
    // Por enquanto, apenas permitir todas as requisições
    // Em produção, adicione verificação de token/sessão admin
    next();
}

// Get all available items from Fortnite API
app.get("/api/shop/available-items", requireAdmin, async (req, res) => {
    try {
        // Check cache
        const now = Date.now();
        if (itemsCache && cacheTimestamp && (now - cacheTimestamp) < CACHE_DURATION) {
            log.debug(`Returned ${itemsCache.length} items from cache`);
            return res.json({
                success: true,
                items: itemsCache,
                count: itemsCache.length,
                cached: true
            });
        }

        log.debug("Fetching items from Fortnite-API.com...");

        // Fetch all cosmetics from Fortnite API
        const response = await axios.get('https://fortnite-api.com/v2/cosmetics/br', {
            timeout: 15000
        });

        if (!response.data || !response.data.data) {
            throw new Error("Invalid API response");
        }

        const allCosmetics = response.data.data;
        const items = [];
        const seenIds = new Set();

        // Filter and format items
        for (const cosmetic of allCosmetics) {
            // Skip items without proper data
            if (!cosmetic.id || !cosmetic.type || !cosmetic.type.value) continue;

            // Filter: Only items introduced up to v17.50 (Season 7 Chapter 2)
            // Chapter 2 Season 7 ended around v17.40
            if (cosmetic.introduction && cosmetic.introduction.chapter) {
                const chapter = cosmetic.introduction.chapter;
                const season = cosmetic.introduction.season || 0;

                // Skip Chapter 2 Season 8+ and all Chapter 3+
                if (chapter > 2 || (chapter === 2 && season > 7)) {
                    continue;
                }
            }

            // Build templateId based on type
            let templateId = '';
            const itemId = cosmetic.id;

            switch (cosmetic.type.value) {
                case 'outfit':
                    templateId = `AthenaCharacter:${itemId}`;
                    break;
                case 'backpack':
                    templateId = `AthenaBackpack:${itemId}`;
                    break;
                case 'pickaxe':
                    templateId = `AthenaPickaxe:${itemId}`;
                    break;
                case 'glider':
                    templateId = `AthenaGlider:${itemId}`;
                    break;
                case 'emote':
                    templateId = `AthenaDance:${itemId}`;
                    break;
                case 'wrap':
                    templateId = `AthenaItemWrap:${itemId}`;
                    break;
                default:
                    // Skip other types
                    continue;
            }

            // Skip duplicates
            if (seenIds.has(templateId)) continue;
            seenIds.add(templateId);

            // Use official name from API
            const name = cosmetic.name || 'Unknown Item';

            // Map type
            let type = 'Item';
            switch (cosmetic.type.value) {
                case 'outfit': type = 'Outfit'; break;
                case 'backpack': type = 'Back Bling'; break;
                case 'pickaxe': type = 'Pickaxe'; break;
                case 'glider': type = 'Glider'; break;
                case 'emote': type = 'Emote'; break;
                case 'wrap': type = 'Wrap'; break;
            }

            items.push({
                templateId,
                name,
                type,
                rarity: cosmetic.rarity?.value || 'common',
                description: cosmetic.description || ''
            });
        }

        // Sort by name
        items.sort((a, b) => a.name.localeCompare(b.name));

        // Cache results
        itemsCache = items;
        cacheTimestamp = now;

        res.json({
            success: true,
            items,
            count: items.length,
            cached: false
        });

        log.backend(`Loaded ${items.length} items from Fortnite API (up to v17.50)`);
    } catch (error) {
        log.error("Error getting available items:", error);

        // Fallback to local athena.json if API fails
        try {
            log.debug("API failed, falling back to local athena.json");
            const athenaPath = path.join(__dirname, "..", "Config", "DefaultProfiles", "athena.json");
            const athenaProfile = JSON.parse(fs.readFileSync(athenaPath, 'utf8'));

            const items = [];
            const seenItems = new Set();

            for (const itemId in athenaProfile.items) {
                const item = athenaProfile.items[itemId];
                const templateId = item.templateId;

                if (seenItems.has(templateId)) continue;
                seenItems.add(templateId);

                let name = templateId;
                if (templateId.includes(':')) {
                    name = templateId.split(':')[1];
                }

                name = name
                    .replace(/^[A-Z]{2,3}_[A-Z]?_?\d+_/gi, '')
                    .replace(/Athena_/gi, '')
                    .replace(/Commando_[MF]_/gi, '')
                    .replace(/^(Pickaxe|Glider)_ID_\d+_/gi, '')
                    .replace(/_[A-Z0-9]{3,}$/gi, '')
                    .replace(/_\d+$/gi, '')
                    .replace(/_/g, ' ')
                    .replace(/^\d+\s+/g, '')
                    .replace(/\s+/g, ' ')
                    .trim();

                name = name.split(' ').map(w =>
                    w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()
                ).join(' ');

                let type = 'Item';
                if (templateId.includes('AthenaCharacter')) type = 'Outfit';
                else if (templateId.includes('AthenaBackpack')) type = 'Back Bling';
                else if (templateId.includes('AthenaPickaxe')) type = 'Pickaxe';
                else if (templateId.includes('AthenaGlider')) type = 'Glider';
                else if (templateId.includes('AthenaDance')) type = 'Emote';
                else if (templateId.includes('AthenaItemWrap')) type = 'Wrap';

                items.push({
                    templateId,
                    name: name || 'Unknown Item',
                    type
                });
            }

            items.sort((a, b) => a.name.localeCompare(b.name));

            res.json({
                success: true,
                items,
                count: items.length,
                fallback: true
            });

            log.debug(`Returned ${items.length} items from fallback`);
        } catch (fallbackError) {
            log.error("Fallback also failed:", fallbackError);
            res.status(500).json({
                success: false,
                error: "Failed to load items from API and fallback"
            });
        }
    }
});

// AI generate shop
app.post("/api/shop/ai-generate", requireAdmin, async (req, res) => {
    try {
        const { featuredCount = 2, dailyCount = 6 } = req.body;

        // Get items from cache or API
        let allItems = [];

        if (itemsCache && itemsCache.length > 0) {
            // Use cached items
            allItems = itemsCache.map(item => item.templateId);
        } else {
            // Fetch from API if cache empty
            try {
                const response = await axios.get('https://fortnite-api.com/v2/cosmetics/br', {
                    timeout: 15000
                });

                if (response.data && response.data.data) {
                    const cosmetics = response.data.data;
                    allItems = cosmetics
                        .filter(c => {
                            // Filter by version
                            if (c.introduction && c.introduction.chapter) {
                                const chapter = c.introduction.chapter;
                                const season = c.introduction.season || 0;
                                if (chapter > 2 || (chapter === 2 && season > 7)) {
                                    return false;
                                }
                            }
                            return c.id && c.type && c.type.value;
                        })
                        .map(c => {
                            const prefix = {
                                'outfit': 'AthenaCharacter',
                                'backpack': 'AthenaBackpack',
                                'pickaxe': 'AthenaPickaxe',
                                'glider': 'AthenaGlider',
                                'emote': 'AthenaDance',
                                'wrap': 'AthenaItemWrap'
                            }[c.type.value];
                            return prefix ? `${prefix}:${c.id}` : null;
                        })
                        .filter(Boolean);
                }
            } catch (apiError) {
                log.error("API fetch failed in AI-generate, using fallback");
            }
        }

        // Fallback to local if no items
        if (allItems.length === 0) {
            const athenaPath = path.join(__dirname, "..", "Config", "DefaultProfiles", "athena.json");
            const athenaProfile = JSON.parse(fs.readFileSync(athenaPath, 'utf8'));
            allItems = Object.values(athenaProfile.items).map(i => i.templateId);
        }

        const uniqueItems = [...new Set(allItems)];

        // Shuffle e selecionar itens aleatórios
        function shuffle(array) {
            const arr = [...array];
            for (let i = arr.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [arr[i], arr[j]] = [arr[j], arr[i]];
            }
            return arr;
        }

        // Preferir certos tipos para featured (skins)
        const skins = uniqueItems.filter(id => id.includes('AthenaCharacter'));
        const others = uniqueItems.filter(id => !id.includes('AthenaCharacter'));

        const shuffledSkins = shuffle(skins);
        const shuffledOthers = shuffle(others);

        // Featured: principalmente skins
        const featured = shuffledSkins.slice(0, featuredCount);

        // Daily: mix de tudo, exceto os já selecionados
        const remainingItems = [...shuffledSkins.slice(featuredCount), ...shuffledOthers];
        const daily = remainingItems.slice(0, dailyCount);

        res.json({
            success: true,
            featured,
            daily,
            message: `Generated ${featured.length} featured and ${daily.length} daily items from ${uniqueItems.length} available`
        });

        log.debug(`AI generated shop: ${featured.length} featured, ${daily.length} daily from ${uniqueItems.length} items`);
    } catch (error) {
        log.error("Error generating AI shop:", error);
        res.status(500).json({
            success: false,
            error: "Failed to generate shop"
        });
    }
});

// Helper function to determine price based on item type
function getItemPrice(templateId) {
    if (templateId.includes('AthenaCharacter')) return 1500; // Skins
    if (templateId.includes('AthenaBackpack')) return 1200;  // Back Blings
    if (templateId.includes('AthenaPickaxe')) return 800;    // Pickaxes
    if (templateId.includes('AthenaGlider')) return 1200;    // Gliders
    if (templateId.includes('AthenaDance')) return 800;      // Emotes
    if (templateId.includes('AthenaItemWrap')) return 300;   // Wraps
    return 800; // Default
}

// Get rotation info for countdown timer
app.get("/api/shop/rotation-info", (req, res) => {
    try {
        const mainConfigPath = path.join(__dirname, "..", "Config", "config.json");
        const mainConfig = JSON.parse(fs.readFileSync(mainConfigPath, 'utf8'));

        const rotateTime = mainConfig.bRotateTime || "00:00";
        const [hours, minutes] = rotateTime.split(':').map(Number);

        // Calculate next rotation time
        const now = new Date();
        const nextRotation = new Date();
        nextRotation.setHours(hours, minutes, 0, 0);

        // If the rotation time has passed today, set it for tomorrow
        if (nextRotation <= now) {
            nextRotation.setDate(nextRotation.getDate() + 1);
        }

        res.json({
            success: true,
            nextRotation: nextRotation.toISOString(),
            rotateTime: rotateTime,
            serverTime: now.toISOString()
        });

        log.debug(`Returned rotation info: next rotation at ${nextRotation.toISOString()}`);
    } catch (error) {
        log.error("Error getting rotation info:", error);
        res.status(500).json({
            success: false,
            error: "Failed to get rotation info"
        });
    }
});

// Save shop configuration
app.post("/api/shop/save-config", requireAdmin, (req, res) => {
    try {
        const { featured = [], daily = [], rotationTime = "00:00" } = req.body;

        const configPath = path.join(__dirname, "..", "Config", "catalog_config.json");

        // Criar novo config
        const newConfig = {
            "//": "BR Item Shop Config"
        };

        // Adicionar featured items com preços corretos
        featured.forEach((templateId, index) => {
            newConfig[`featured${index + 1}`] = {
                itemGrants: [templateId],
                price: getItemPrice(templateId)
            };
        });

        // Adicionar daily items com preços corretos
        daily.forEach((templateId, index) => {
            newConfig[`daily${index + 1}`] = {
                itemGrants: [templateId],
                price: getItemPrice(templateId)
            };
        });

        // Salvar config
        fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 2));

        // Atualizar horário de rotação no config principal
        const mainConfigPath = path.join(__dirname, "..", "Config", "config.json");
        const mainConfig = JSON.parse(fs.readFileSync(mainConfigPath, 'utf8'));
        const oldRotateTime = mainConfig.bRotateTime;
        mainConfig.bRotateTime = rotationTime;
        mainConfig.bFeaturedItemsAmount = featured.length;
        mainConfig.bDailyItemsAmount = daily.length;
        fs.writeFileSync(mainConfigPath, JSON.stringify(mainConfig, null, 2));

        // Reschedule auto-rotation if time changed
        if (oldRotateTime !== rotationTime && mainConfig.bUseAutoRotate === true) {
            try {
                const autorotate = require('../structs/autorotate.js');
                if (autorotate.rescheduleRotation) {
                    autorotate.rescheduleRotation();
                    log.backend(`Auto-rotation rescheduled to ${rotationTime}`);
                }
            } catch (err) {
                log.error("Failed to reschedule rotation:", err.message);
            }
        }

        res.json({
            success: true,
            message: `Shop configured with ${featured.length} featured and ${daily.length} daily items`
        });

        log.backend(`Shop configuration saved: ${featured.length} featured, ${daily.length} daily, rotation at ${rotationTime}`);
    } catch (error) {
        log.error("Error saving shop config:", error);
        res.status(500).json({
            success: false,
            error: "Failed to save configuration"
        });
    }
});

module.exports = app;
