/**
 * GameServer API Routes
 * Endpoints for game servers to communicate with the backend
 */

const express = require("express");
const app = express.Router();
const log = require("../structs/log.js");
const error = require("../structs/error.js");
const gameServerManager = require("../structs/gameserverManager.js");
const Match = require("../model/matches.js");
const GameServer = require("../model/gameservers.js");
const config = require("../Config/config.json");

// Simple API key verification middleware
function verifyGameServerAuth(req, res, next) {
    const apiKey = req.headers['x-gameserver-key'] || req.headers['authorization'];
    const serverId = req.headers['x-server-id'];

    // For now, we'll use a simple API key system
    // TODO: Implement proper JWT authentication for game servers
    if (!apiKey || apiKey !== config.Api.bApiKey) {
        return res.status(401).json({
            error: "Unauthorized",
            message: "Invalid or missing API key"
        });
    }

    if (!serverId) {
        return res.status(400).json({
            error: "Bad Request",
            message: "Missing X-Server-ID header"
        });
    }

    req.serverId = serverId;
    next();
}

/**
 * Server Heartbeat
 * Game servers should call this every 10-15 seconds
 */
app.post("/api/gameserver/heartbeat", verifyGameServerAuth, async (req, res) => {
    try {
        const { cpu, memory, ping, uptime, currentPlayers, matchStatus } = req.body;

        await gameServerManager.updateHeartbeat(req.serverId, {
            cpu: cpu || 0,
            memory: memory || 0,
            ping: ping || 0,
            uptime: uptime || 0
        });

        // Update current match info if provided
        if (matchStatus) {
            await GameServer.updateOne(
                { serverId: req.serverId },
                {
                    $set: {
                        'currentMatch.playersInMatch': matchStatus.currentPlayers || 0,
                        'currentMatch.phase': matchStatus.phase || 'waiting'
                    }
                }
            );
        }

        log.debug(`[GameServer API] Heartbeat from ${req.serverId}`);

        res.json({
            success: true,
            timestamp: new Date().toISOString()
        });

    } catch (err) {
        log.error("[GameServer API] Heartbeat error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Match Started
 * Called when a match starts on the game server
 */
app.post("/api/gameserver/match/start", verifyGameServerAuth, async (req, res) => {
    try {
        const { matchId, players } = req.body;

        if (!matchId) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing matchId"
            });
        }

        const match = await Match.findOne({ matchId });

        if (!match) {
            return res.status(404).json({
                error: "Not Found",
                message: "Match not found"
            });
        }

        match.status = 'active';
        match.timeline.matchStarted = new Date();

        if (players && Array.isArray(players)) {
            match.currentPlayers = players.length;
        }

        await match.save();

        log.backend(`[GameServer API] Match ${matchId} started on ${req.serverId}`);

        res.json({
            success: true,
            matchId: matchId
        });

    } catch (err) {
        log.error("[GameServer API] Match start error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Match Update
 * Update match state (players, kills, etc)
 */
app.post("/api/gameserver/match/update", verifyGameServerAuth, async (req, res) => {
    try {
        const { matchId, updates } = req.body;

        if (!matchId) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing matchId"
            });
        }

        await gameServerManager.updateMatch(matchId, updates);

        log.debug(`[GameServer API] Match ${matchId} updated`);

        res.json({
            success: true
        });

    } catch (err) {
        log.error("[GameServer API] Match update error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Match Ended
 * Called when a match ends
 */
app.post("/api/gameserver/match/end", verifyGameServerAuth, async (req, res) => {
    try {
        const { matchId, results } = req.body;

        if (!matchId) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing matchId"
            });
        }

        await gameServerManager.endMatch(matchId, results);

        log.backend(`[GameServer API] Match ${matchId} ended on ${req.serverId}`);

        res.json({
            success: true
        });

    } catch (err) {
        log.error("[GameServer API] Match end error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Player Joined Match
 * Called when a player joins the match
 */
app.post("/api/gameserver/match/player/join", verifyGameServerAuth, async (req, res) => {
    try {
        const { matchId, player } = req.body;

        if (!matchId || !player || !player.accountId) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing required fields"
            });
        }

        const match = await Match.findOne({ matchId });

        if (!match) {
            return res.status(404).json({
                error: "Not Found",
                message: "Match not found"
            });
        }

        // Add player to match if not already present
        const existingPlayer = match.players.find(p => p.accountId === player.accountId);

        if (!existingPlayer) {
            match.players.push({
                accountId: player.accountId,
                displayName: player.displayName,
                joinedAt: new Date()
            });
            match.currentPlayers = match.players.length;
            await match.save();

            log.debug(`[GameServer API] Player ${player.displayName} joined match ${matchId}`);
        }

        res.json({
            success: true
        });

    } catch (err) {
        log.error("[GameServer API] Player join error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Player Left Match
 * Called when a player leaves the match
 */
app.post("/api/gameserver/match/player/leave", verifyGameServerAuth, async (req, res) => {
    try {
        const { matchId, accountId, stats } = req.body;

        if (!matchId || !accountId) {
            return res.status(400).json({
                error: "Bad Request",
                message: "Missing required fields"
            });
        }

        const match = await Match.findOne({ matchId });

        if (!match) {
            return res.status(404).json({
                error: "Not Found",
                message: "Match not found"
            });
        }

        // Update player info
        const player = match.players.find(p => p.accountId === accountId);

        if (player) {
            player.leftAt = new Date();

            if (stats) {
                player.kills = stats.kills || 0;
                player.damage = stats.damage || 0;
                player.placement = stats.placement || 0;
                player.survived = stats.survived || 0;
            }

            match.currentPlayers = match.players.filter(p => !p.leftAt).length;
            await match.save();

            // If all players left before the match started, flip server back to joinable
            if (match.currentPlayers === 0 && match.status === 'waiting') {
                const GameServer = require('../model/gameservers.js');
                await GameServer.updateOne(
                    { serverId: req.serverId },
                    { $set: { serverPhase: 'joinable', 'currentMatch.playersInMatch': 0 } }
                );
                log.backend(`[GameServer API] All players left pre-match on ${req.serverId} - reset to joinable`);
            }

            log.debug(`[GameServer API] Player ${accountId} left match ${matchId}`);
        }

        res.json({
            success: true
        });

    } catch (err) {
        log.error("[GameServer API] Player leave error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Get Match Info
 * Game server can request current match information
 */
app.get("/api/gameserver/match/:matchId", verifyGameServerAuth, async (req, res) => {
    try {
        const match = await Match.findOne({ matchId: req.params.matchId });

        if (!match) {
            return res.status(404).json({
                error: "Not Found",
                message: "Match not found"
            });
        }

        res.json({
            success: true,
            match: {
                matchId: match.matchId,
                sessionId: match.sessionId,
                playlist: match.playlist,
                status: match.status,
                players: match.players,
                currentPlayers: match.currentPlayers,
                maxPlayers: match.maxPlayers,
                settings: match.settings,
                timeline: match.timeline
            }
        });

    } catch (err) {
        log.error("[GameServer API] Get match error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Server Status
 * Get current server status
 */
app.get("/api/gameserver/status", verifyGameServerAuth, async (req, res) => {
    try {
        const server = await GameServer.findOne({ serverId: req.serverId });

        if (!server) {
            return res.status(404).json({
                error: "Not Found",
                message: "Server not found"
            });
        }

        res.json({
            success: true,
            server: {
                serverId: server.serverId,
                status: server.status,
                currentMatch: server.currentMatch,
                supportedPlaylists: server.supportedPlaylists,
                maxPlayers: server.maxPlayers,
                stats: server.stats,
                health: server.health
            }
        });

    } catch (err) {
        log.error("[GameServer API] Get status error:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});

/**
 * Report Error
 * Game server can report errors to backend
 */
app.post("/api/gameserver/error", verifyGameServerAuth, async (req, res) => {
    try {
        const { error: errorMsg, stack, matchId } = req.body;

        log.error(`[GameServer API] Error from ${req.serverId}:`, {
            error: errorMsg,
            stack: stack,
            matchId: matchId
        });

        res.json({
            success: true
        });

    } catch (err) {
        log.error("[GameServer API] Report error failed:", err);
        return res.status(500).json({
            error: "Internal server error",
            message: err.message
        });
    }
});


/**
 * Phase Update
 * Game server reports its current phase: setting_up | joinable | in_match
 */
app.post("/api/gameserver/phase", verifyGameServerAuth, async (req, res) => {
    try {
        const { phase, currentPlayers } = req.body;
        const validPhases = ['setting_up', 'joinable', 'in_match'];
        if (!phase || !validPhases.includes(phase)) {
            return res.status(400).json({ error: "Bad Request", message: `Invalid phase. Must be one of: ${validPhases.join(', ')}` });
        }
        const server = await GameServer.findOne({ serverId: req.serverId });
        if (!server) return res.status(404).json({ error: "Not Found", message: "Server not found" });

        server.serverPhase = phase;
        if (phase === 'setting_up') {
            server.currentMatch.playersInMatch = 0;
            server.status = 'online';
        }
        if (currentPlayers !== undefined) {
            server.currentMatch.playersInMatch = currentPlayers;
        }
        server.health.lastHeartbeat = new Date();
        if (server.status !== 'online') server.status = 'online';
        await server.save();

        log.backend(`[GameServer API] ${req.serverId} phase -> ${phase} (players: ${server.currentMatch.playersInMatch})`);
        res.json({ success: true, phase });
    } catch (err) {
        log.error("[GameServer API] Phase update error:", err);
        return res.status(500).json({ error: "Internal server error", message: err.message });
    }
});

module.exports = app;