const express = require("express");
const app = express.Router();
const Playlist = require("../model/playlists.js");
const Gamemode = require("../model/gamemodes.js");
const { verifyToken, verifyAdmin } = require("../tokenManager/tokenVerify.js");
const log = require("../structs/log.js");
const error = require("../structs/error.js");

// Cache for playlists list
let playlistsCache = null;
let playlistsCacheTime = 0;
const PLAYLISTS_CACHE_TTL = 60000; // 1 minute

// Get all active playlists (public endpoint)
app.get("/fortnite/api/playlists/public", async (req, res) => {
    try {
        // Check cache first
        if (playlistsCache && (Date.now() - playlistsCacheTime < PLAYLISTS_CACHE_TTL)) {
            return res.json({
                status: "success",
                playlists: playlistsCache
            });
        }

        const playlists = await Playlist.find({
            isActive: true,
            isVisible: true
        }).select('-__v').sort({ displayPriority: -1 }).lean();

        const formattedPlaylists = playlists.map(p => ({
            playlistId: p.playlistId,
            playlistName: p.playlistName,
            description: p.description,
            playlistType: p.playlistType,
            maxPlayers: p.gamemodeConfig.maxPlayers,
            requirements: p.requirements
        }));

        // Update cache
        playlistsCache = formattedPlaylists;
        playlistsCacheTime = Date.now();

        res.json({
            status: "success",
            playlists: formattedPlaylists
        });
    } catch (err) {
        log.error("Error fetching playlists:", err);
        return error.createError(
            "errors.com.epicgames.playlist.fetch_failed",
            "Failed to fetch playlists",
            [], 1001, "playlist_error", 500, res
        );
    }
});

// Get specific playlist details
app.get("/fortnite/api/playlists/:playlistId", verifyToken, async (req, res) => {
    try {
        const playlist = await Playlist.findOne({
            playlistId: req.params.playlistId,
            isActive: true
        }).lean();

        if (!playlist) {
            return error.createError(
                "errors.com.epicgames.playlist.not_found",
                `Playlist ${req.params.playlistId} not found`,
                [], 1002, "playlist_not_found", 404, res
            );
        }

        res.json({
            status: "success",
            playlist: playlist
        });
    } catch (err) {
        log.error("Error fetching playlist:", err);
        return error.createError(
            "errors.com.epicgames.playlist.fetch_failed",
            "Failed to fetch playlist",
            [], 1001, "playlist_error", 500, res
        );
    }
});

// Admin: Get all playlists (including inactive)
app.get("/fortnite/api/admin/playlists/all", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const playlists = await Playlist.find({}).sort({ createdAt: -1 });
        res.json({
            status: "success",
            count: playlists.length,
            playlists: playlists
        });
    } catch (err) {
        log.error("Error fetching all playlists:", err);
        return error.createError(
            "errors.com.epicgames.playlist.fetch_failed",
            "Failed to fetch playlists",
            [], 1001, "playlist_error", 500, res
        );
    }
});

// Admin: Create new playlist
app.post("/fortnite/api/admin/playlists/create", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const playlistData = req.body;

        // Check if playlist already exists
        const existing = await Playlist.findOne({ playlistId: playlistData.playlistId });
        if (existing) {
            return error.createError(
                "errors.com.epicgames.playlist.already_exists",
                `Playlist ${playlistData.playlistId} already exists`,
                [], 1003, "playlist_exists", 400, res
            );
        }

        // Set creator
        playlistData.createdBy = req.user.accountId;

        const playlist = new Playlist(playlistData);
        await playlist.save();

        log.debug(`Playlist created: ${playlist.playlistId} by ${req.user.displayName}`);

        res.status(201).json({
            status: "success",
            message: "Playlist created successfully",
            playlist: playlist
        });
    } catch (err) {
        log.error("Error creating playlist:", err);
        return error.createError(
            "errors.com.epicgames.playlist.create_failed",
            "Failed to create playlist",
            [err.message], 1004, "playlist_error", 500, res
        );
    }
});

// Admin: Update playlist
app.put("/fortnite/api/admin/playlists/:playlistId", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const playlist = await Playlist.findOneAndUpdate(
            { playlistId: req.params.playlistId },
            {
                ...req.body,
                updatedAt: Date.now()
            },
            { new: true }
        );

        if (!playlist) {
            return error.createError(
                "errors.com.epicgames.playlist.not_found",
                `Playlist ${req.params.playlistId} not found`,
                [], 1002, "playlist_not_found", 404, res
            );
        }

        log.debug(`Playlist updated: ${playlist.playlistId} by ${req.user.displayName}`);

        res.json({
            status: "success",
            message: "Playlist updated successfully",
            playlist: playlist
        });
    } catch (err) {
        log.error("Error updating playlist:", err);
        return error.createError(
            "errors.com.epicgames.playlist.update_failed",
            "Failed to update playlist",
            [err.message], 1005, "playlist_error", 500, res
        );
    }
});

// Admin: Delete playlist
app.delete("/fortnite/api/admin/playlists/:playlistId", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const playlist = await Playlist.findOneAndDelete({
            playlistId: req.params.playlistId
        });

        if (!playlist) {
            return error.createError(
                "errors.com.epicgames.playlist.not_found",
                `Playlist ${req.params.playlistId} not found`,
                [], 1002, "playlist_not_found", 404, res
            );
        }

        log.debug(`Playlist deleted: ${playlist.playlistId} by ${req.user.displayName}`);

        res.json({
            status: "success",
            message: "Playlist deleted successfully"
        });
    } catch (err) {
        log.error("Error deleting playlist:", err);
        return error.createError(
            "errors.com.epicgames.playlist.delete_failed",
            "Failed to delete playlist",
            [err.message], 1006, "playlist_error", 500, res
        );
    }
});

// Admin: Toggle playlist active status
app.patch("/fortnite/api/admin/playlists/:playlistId/toggle", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const playlist = await Playlist.findOne({ playlistId: req.params.playlistId });

        if (!playlist) {
            return error.createError(
                "errors.com.epicgames.playlist.not_found",
                `Playlist ${req.params.playlistId} not found`,
                [], 1002, "playlist_not_found", 404, res
            );
        }

        playlist.isActive = !playlist.isActive;
        playlist.updatedAt = Date.now();
        await playlist.save();

        log.debug(`Playlist ${playlist.playlistId} ${playlist.isActive ? 'activated' : 'deactivated'} by ${req.user.displayName}`);

        res.json({
            status: "success",
            message: `Playlist ${playlist.isActive ? 'activated' : 'deactivated'} successfully`,
            isActive: playlist.isActive
        });
    } catch (err) {
        log.error("Error toggling playlist:", err);
        return error.createError(
            "errors.com.epicgames.playlist.toggle_failed",
            "Failed to toggle playlist",
            [err.message], 1007, "playlist_error", 500, res
        );
    }
});

// Get playlist statistics
app.get("/fortnite/api/playlists/:playlistId/stats", verifyToken, async (req, res) => {
    try {
        const playlist = await Playlist.findOne({
            playlistId: req.params.playlistId
        }).select('playlistId playlistName totalMatches totalPlayers');

        if (!playlist) {
            return error.createError(
                "errors.com.epicgames.playlist.not_found",
                `Playlist ${req.params.playlistId} not found`,
                [], 1002, "playlist_not_found", 404, res
            );
        }

        res.json({
            status: "success",
            stats: {
                playlistId: playlist.playlistId,
                playlistName: playlist.playlistName,
                totalMatches: playlist.totalMatches,
                totalPlayers: playlist.totalPlayers,
                averagePlayersPerMatch: playlist.totalMatches > 0
                    ? Math.round(playlist.totalPlayers / playlist.totalMatches)
                    : 0
            }
        });
    } catch (err) {
        log.error("Error fetching playlist stats:", err);
        return error.createError(
            "errors.com.epicgames.playlist.stats_failed",
            "Failed to fetch playlist statistics",
            [], 1008, "playlist_error", 500, res
        );
    }
});

module.exports = app;
