const express = require('express');
const app = express.Router();
const User = require('../model/user.js');
const Profile = require('../model/profiles.js');
const Friends = require('../model/friends.js');
const UserStats = require('../model/userstats.js');
const GameServer = require('../model/gameservers.js');
const Match = require('../model/matches.js');
const log = require('../structs/log.js');
const functions = require('../structs/functions.js');
const axios = require('axios');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const config = require('../Config');

// Sync user.vbucks to Profile MongoDB (common_core + profile0 currency items)
async function syncVbucksToProfile(accountId, newVbucks) {
  try {
    const profiles = await Profile.findOne({ accountId });
    if (!profiles) return;

    let changed = false;

    for (const profileId of ['common_core', 'profile0']) {
      const profile = profiles.profiles[profileId];
      if (!profile || !profile.items) continue;

      // Find existing currency:mtx item
      let found = false;
      for (const key in profile.items) {
        if (profile.items[key].templateId && profile.items[key].templateId.toLowerCase().startsWith('currency:mtx')) {
          profile.items[key].quantity = newVbucks;
          found = true;
          changed = true;
          break;
        }
      }

      // If no currency item exists, create one
      if (!found) {
        profile.items['Currency:MtxPurchased'] = {
          templateId: 'Currency:MtxPurchased',
          attributes: { platform: 'EpicPC' },
          quantity: newVbucks
        };
        changed = true;
      }

      if (changed) {
        profile.rvn = (profile.rvn || 0) + 1;
        profile.commandRevision = (profile.commandRevision || 0) + 1;
        profile.updated = new Date().toISOString();
      }
    }

    if (changed) {
      await Profile.updateOne(
        { accountId },
        {
          $set: {
            'profiles.common_core': profiles.profiles['common_core'],
            'profiles.profile0': profiles.profiles['profile0']
          }
        }
      );
      // Invalidate cache so next QueryProfile picks up new value
      if (global.invalidateProfileCache) global.invalidateProfileCache(accountId);
      log.debug(`[syncVbucks] Synced ${newVbucks} V-Bucks to Profile for ${accountId}`);
    }
  } catch (err) {
    log.error('[syncVbucks] Failed to sync vbucks to Profile:', err);
  }
}

// Calculate division based on hype points
function calculateDivision(hype) {
  const divisions = config.arenaDivisions;
  for (let i = divisions.length - 1; i >= 0; i--) {
    if (hype >= divisions[i].minPoints) {
      return {
        id: divisions[i].id,
        name: divisions[i].name,
        minPoints: divisions[i].minPoints,
        maxPoints: divisions[i].maxPoints,
        currentPoints: hype,
        pointsToNext: i < divisions.length - 1 ? divisions[i + 1].minPoints - hype : 0
      };
    }
  }
  return {
    id: 0,
    name: divisions[0].name,
    minPoints: 0,
    maxPoints: divisions[0].maxPoints,
    currentPoints: hype,
    pointsToNext: divisions[0].maxPoints - hype
  };
}

async function verifySessionMiddleware(req, res, next) {
  try {
    const cookieHeader = req.headers.cookie || '';
    const match = cookieHeader.match(/connect\.sid=([^;]+)/);
    const sessionID = match && match[1];

    if (!sessionID || !global.launcherSessions || !global.launcherSessions[sessionID]) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const sessionObj = global.launcherSessions[sessionID];
    req.user = sessionObj.user;
    next();
  } catch (err) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
  }
}

app.post('/account/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Missing email or password' });
    }

    const emailLower = email.toLowerCase();

    const existingUser = await User.findOne({ email: emailLower });
    if (existingUser) {
      return res.status(200).json({ 
        success: true, 
        message: 'Account already exists',
        accountId: existingUser.accountId 
      });
    }

    const accountId = uuidv4().replace(/-/g, '');
    const matchmakingId = uuidv4().replace(/-/g, '');
    const username = email.split('@')[0];

    const hashedPassword = await bcrypt.hash(password, 10);

    await User.create({
      created: new Date(),
      banned: false,
      accountId: accountId,
      username: username,
      username_lower: username.toLowerCase(),
      email: emailLower,
      password: hashedPassword,
      externalPassword: password,
      matchmakingId: matchmakingId,
      isServer: true,
      level: 1,
      xp: 0,
      vbucks: 0,
      wins: 0,
      kills: 0,
      deaths: 0,
      hype: 0,
      division: 0,
      matchesPlayed: 0
    });

    await Profile.create({
      created: new Date(),
      accountId: accountId,
      profiles: {
        athena: {
          accountId: accountId,
          profileId: 'athena',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          rvn: 0,
          commandRevision: 0,
          wipeNumber: 1,
          version: 'no_version',
          stats: {
            attributes: {
              season_match_boost: 0,
              mfa_reward_claimed: false,
              quest_manager: {},
              book_level: 1,
              season_num: 8,
              season_update: 0,
              book_xp: 0,
              permissions: [],
              season: {
                numWins: 0,
                numHighBracket: 0,
                numLowBracket: 0
              },
              vote_data: {},
              lifetime_wins: 0,
              book_purchased: false,
              level: 1,
              rested_xp_overflow: 0,
              rested_xp: 0,
              rested_xp_mult: 1,
              accountLevel: 1,
              competitive_identity: {},
              inventory_limit_bonus: 0,
              daily_rewards: {},
              xp: 0,
              season_friend_match_boost: 0,
              active_loadout_index: 0,
              last_applied_loadout: "sandbox_loadout",
              loadouts: ["sandbox_loadout"],
              active_loadout_index: 0,
              banner_icon: "standardbanner1",
              banner_color: "defaultcolor1",
              favorite_character: "",
              favorite_backpack: "",
              favorite_pickaxe: "",
              favorite_glider: "",
              favorite_skydivecontrail: "",
              favorite_musicpack: "",
              favorite_loadingscreen: "",
              favorite_dance: ["", "", "", "", "", ""],
              favorite_itemwraps: ["", "", "", "", "", "", ""],
              past_seasons: []
            }
          },
          items: {
            "sandbox_loadout": {
              "templateId": "CosmeticLocker:cosmeticlocker_athena",
              "attributes": {
                "locker_slots_data": {
                  "slots": {
                    "Character": { "items": [""], "activeVariants": [{"variants": []}] },
                    "Backpack": { "items": [""], "activeVariants": [{"variants": []}] },
                    "SkyDiveContrail": { "items": [""], "activeVariants": [{"variants": []}] },
                    "Pickaxe": { "items": ["AthenaPickaxe:DefaultPickaxe"], "activeVariants": [{"variants": []}] },
                    "Glider": { "items": ["AthenaGlider:DefaultGlider"], "activeVariants": [{"variants": []}] },
                    "Dance": { "items": ["", "", "", "", "", ""], "activeVariants": [{"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}] },
                    "ItemWrap": { "items": ["", "", "", "", "", "", ""], "activeVariants": [{"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}, {"variants": []}] },
                    "MusicPack": { "items": [""], "activeVariants": [{"variants": []}] },
                    "LoadingScreen": { "items": [""], "activeVariants": [{"variants": []}] }
                  }
                },
                "use_count": 0,
                "banner_icon_template": "",
                "banner_color_template": "",
                "locker_name": "Preset 1",
                "item_seen": true,
                "favorite": false
              },
              "quantity": 1
            }
          }
        },
        common_core: {
          accountId: accountId,
          profileId: 'common_core',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          rvn: 0,
          commandRevision: 0,
          wipeNumber: 1,
          version: 'no_version',
          stats: {
            attributes: {
              survey_data: {},
              personal_offers: {},
              intro_game_played: false,
              import_friends_claimed: {},
              mtx_purchase_history: {
                refundsUsed: 0,
                refundCredits: 3,
                purchases: []
              },
              undo_cooldowns: [],
              mtx_affiliate_set_time: new Date().toISOString(),
              inventory_limit_bonus: 0,
              current_mtx_platform: "EpicPC",
              mtx_affiliate: "",
              weekly_purchases: {},
              daily_purchases: {},
              ban_history: {},
              in_app_purchases: {},
              permissions: [],
              undo_timeout: "min",
              monthly_purchases: {},
              allowed_to_send_gifts: true,
              mfa_enabled: false,
              allowed_to_receive_gifts: true,
              gift_history: {}
            }
          },
          items: {
            "Currency:MtxPurchased": {
              "templateId": "Currency:MtxPurchased",
              "attributes": {
                "platform": "Shared"
              },
              "quantity": 0
            }
          }
        },
        profile0: {
          accountId: accountId,
          profileId: 'profile0',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          rvn: 0,
          commandRevision: 0,
          wipeNumber: 1,
          version: 'no_version',
          stats: {
            attributes: {
              mtx_purchase_history: {
                refundsUsed: 0,
                refundCredits: 3,
                purchases: []
              }
            }
          },
          items: {
            "Currency:MtxPurchased": {
              "templateId": "Currency:MtxPurchased",
              "attributes": {
                "platform": "Shared"
              },
              "quantity": 0
            }
          }
        },
        common_public: {
          accountId: accountId,
          profileId: 'common_public',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          rvn: 0,
          commandRevision: 0,
          wipeNumber: 1,
          version: 'no_version',
          stats: {
            attributes: {}
          },
          items: {}
        }
      }
    });

    await Friends.create({
      created: new Date(),
      accountId: accountId,
      list: {
        accepted: [],
        incoming: [],
        outgoing: [],
        blocked: []
      }
    });

    await UserStats.create({
      accountId: accountId,
      displayName: username,
      solo: {
        wins: 0,
        kills: 0,
        matchesplayed: 0,
        placetop1: 0,
        placetop10: 0,
        placetop25: 0,
        score: 0,
        playersoutlived: 0,
        minutesplayed: 0
      },
      duo: {
        wins: 0,
        kills: 0,
        matchesplayed: 0,
        placetop1: 0,
        placetop5: 0,
        placetop12: 0,
        score: 0,
        playersoutlived: 0,
        minutesplayed: 0
      },
      squad: {
        wins: 0,
        kills: 0,
        matchesplayed: 0,
        placetop1: 0,
        placetop3: 0,
        placetop6: 0,
        score: 0,
        playersoutlived: 0,
        minutesplayed: 0
      },
      ltm: {
        wins: 0,
        kills: 0,
        matchesplayed: 0,
        score: 0,
        playersoutlived: 0,
        minutesplayed: 0
      }
    });
    
    res.json({ 
      success: true, 
      message: 'Account created successfully',
      accountId: accountId
    });
  } catch (err) {
    log.error('Failed to register account', err);
    res.status(500).json({ error: 'Failed to create account', details: err.message });
  }
});

app.get('/api/launcher/user-data', verifySessionMiddleware, async (req, res) => {
  try {
    const user = await User.findOne({ _id: req.user._id }).lean();

    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    let avatarDecorationUrl = null;
    if (user.discordAvatarDecorationData && user.discordAvatarDecorationData.asset) {
      avatarDecorationUrl = `https://cdn.discordapp.com/avatar-decorations/${user.discordAvatarDecorationData.asset}.png`;
    }

    res.json({
      success: true,
      accountId: user.accountId,
      avatar: user.discordAvatar || (user.discordId && user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png?size=256` : null),
      username: user.username,
      discriminator: user.discriminator || null,
      discordId: user.discordId,
      email: user.email,
      externalPassword: user.externalPassword,
      avatarDecoration: user.avatarDecoration || (user.discordAvatarDecorationData && user.discordAvatarDecorationData.asset) || null,
      level: Number(user.level || 0),
      xp: Number(user.xp || 0),
      vbucks: Number(user.vbucks || 0),
      wins: Number(user.wins || 0),
      kills: Number(user.kills || 0),
      deaths: Number(user.deaths || 0),
      kd: user.deaths > 0 ? parseFloat(((user.kills || 0) / (user.deaths || 1)).toFixed(2)) : Number(user.kills || 0),
      matchesPlayed: Number(user.matchesPlayed || 0),
      createdAt: user.created,
      isAdmin: user.isAdmin || false,
      basicDonator: user.basicDonator || user.donator || false,
      donator: user.donator || user.basicDonator || false,
      mediumDonator: user.mediumDonator || false,
      highDonator: user.highDonator || false,
      ultimateDonator: user.ultimateDonator || false,
      benefitsGiven: user.benefitsGiven || { basic: false, medium: false, high: false, ultimate: false },
      donatorSince: user.donatorSince || null
    });
  } catch (err) {
    log.error('Failed to get launcher user data', err);
    res.status(500).json({ success: false, error: 'Failed to fetch user data' });
  }
});

app.get('/api/launcher/shop', verifySessionMiddleware, async (req, res) => {
  try {
    const catalog = functions.getItemShop();

    const featuredStore = (catalog.storefronts || []).find(s => s.name === 'BRWeeklyStorefront') || { catalogEntries: [] };
    const dailyStore = (catalog.storefronts || []).find(s => s.name === 'BRDailyStorefront') || { catalogEntries: [] };

    async function fetchIconByName(nameOrId) {
      try {
        if (/^(CID_|BID_|SPID_|Pickaxe_ID_|Glider_ID_|Music_ID_)/i.test(nameOrId)) {
          try {
            const respId = await axios.get(`https://fortnite-api.com/v2/cosmetics/br/${encodeURIComponent(nameOrId)}`, { timeout: 3000 });
            const dataId = respId.data && respId.data.data;
            if (dataId) {
              return {
                displayName: dataId.displayName || dataId.name || null,
                smallIcon: dataId.images && (dataId.images.smallIcon || dataId.images.icon || null),
                rarity: dataId.rarity && (dataId.rarity.value || dataId.rarity.displayValue) || null
              };
            }
          } catch (e) {
          }
        }

        const resp = await axios.get(`https://fortnite-api.com/v2/cosmetics/br/search?name=${encodeURIComponent(nameOrId)}`, { timeout: 3000 });
        const data = resp.data && resp.data.data;
        if (data) {
          return {
            displayName: data.displayName || data.name || null,
            smallIcon: data.images && (data.images.smallIcon || data.images.icon || null),
            rarity: data.rarity && (data.rarity.value || data.rarity.displayValue) || null
          };
        }
      } catch (e) {
      }
      return null;
    }

    async function mapEntry(entry, ownedTemplates) {
      let name = entry.devName || (entry.itemGrants && entry.itemGrants[0] && entry.itemGrants[0].templateId) || 'Unknown Item';
      try {
        if (entry.metaInfo && Array.isArray(entry.metaInfo)) {
          const m = entry.metaInfo.find(mi => mi.key && mi.key.toLowerCase() === 'displayname');
          if (m && m.value) name = m.value;
        }
      } catch (e) {}

      name = name.replace(/\[VIRTUAL\]\d+ x /i, '').replace(/ for .*$/i, '').trim();

      const templateId = entry.itemGrants && entry.itemGrants[0] && entry.itemGrants[0].templateId;
      const type = templateId ? templateId.split(':')[0] : 'Item';
      const price = (entry.prices && entry.prices[0] && entry.prices[0].finalPrice) || 0;

      let displayName = null;
      let imageUrl = null;
      let resolvedRarity = (entry.meta && entry.meta.Rarity) || null;

      if (templateId && templateId.includes(':')) {
        const token = templateId.split(':')[1];
        if (token) {
          const found = await fetchIconByName(token);
          if (found) {
            displayName = found.displayName || displayName;
            imageUrl = imageUrl || found.smallIcon;
            resolvedRarity = resolvedRarity || (found.rarity || null);
          }
        }
      }

      if (!displayName && entry.devName) {
        const cleaned = entry.devName.replace(/[_\-\d]+/g, ' ').replace(/\s+/g, ' ').trim();
        const found = await fetchIconByName(cleaned);
        if (found) {
          displayName = found.displayName || found.name || cleaned;
          imageUrl = imageUrl || found.smallIcon;
          resolvedRarity = resolvedRarity || (found.rarity || null);
        }
      }

      if (!imageUrl && entry.displayAssetPath) {
        const lastToken = entry.displayAssetPath.split('/').pop().split('.').pop();
        if (lastToken) {
          const found = await fetchIconByName(lastToken);
          if (found) {
            displayName = displayName || found.displayName || found.name || null;
            imageUrl = imageUrl || found.smallIcon;
            resolvedRarity = resolvedRarity || (found.rarity || null);
          }
        }
      }

      if (!displayName) {
        displayName = name.replace(/[:_\-]/g, ' ').replace(/\s+/g, ' ').trim();
      }

      if (!imageUrl) {
        imageUrl = 'https://via.placeholder.com/256?text=No+Image';
      }

      const owned = !!(entry.itemGrants && entry.itemGrants[0] && entry.itemGrants[0].templateId && ownedTemplates && ownedTemplates.has(entry.itemGrants[0].templateId));

      return {
        _id: entry.offerId || entry.devName || Math.random().toString(36).slice(2),
        name: displayName,
        type,
        rarity: (entry.meta && entry.meta.Rarity) || resolvedRarity || 'common',
        price,
        imageUrl,
        owned,
        templateId: entry.itemGrants && entry.itemGrants[0] && entry.itemGrants[0].templateId,
        raw: entry
      };
    }

    let ownedTemplates = new Set();
    try {
      const profileData = await Profile.findOne({ accountId: req.user.accountId }).lean();
      if (profileData && profileData.profiles && profileData.profiles['common_core'] && profileData.profiles['common_core'].items) {
        const itemsObj = profileData.profiles['common_core'].items || {};
        Object.values(itemsObj).forEach(it => {
          if (it && it.templateId) ownedTemplates.add(it.templateId);
        });
      }
    } catch (e) {
    }

    const featured = await Promise.all((featuredStore.catalogEntries || []).map(entry => mapEntry(entry, ownedTemplates)));
    const daily = await Promise.all((dailyStore.catalogEntries || []).map(entry => mapEntry(entry, ownedTemplates)));

    const f = featured || [];
    const d = daily || [];

    if ((!featured || featured.length === 0) && (!daily || daily.length === 0)) {
      const allEntries = (catalog.storefronts || []).flatMap(s => s.catalogEntries || []);
      const mappedAll = await Promise.all(allEntries.map(mapEntry));
      const unique = [];
      const seen = new Set();
      for (const it of mappedAll) {
        if (!seen.has(it._id)) {
          seen.add(it._id);
          unique.push(it);
        }
      }
      featured.push(...unique);
    }

    res.json({
      success: true,
      featured,
      daily,
      featuredBundles: [],
      dailyBundles: [],
      rotation: [],
      bundles: [],
      nextRotation: new Date(Date.now() + (catalog.refreshInterval || 24) * 60 * 60 * 1000).toISOString()
    });
  } catch (err) {
    log.error('Failed to get launcher shop', err);
    res.status(500).json({ success: false, error: 'Failed to fetch shop' });
  }
});

app.get('/api/launcher/leaderboard', verifySessionMiddleware, async (req, res) => {
  try {
    const filter = (req.query.filter || 'wins').toLowerCase();
    const allowed = ['wins','kills','deaths'];
    if (!allowed.includes(filter)) return res.status(400).json({ success: false, error: 'Invalid filter' });

    const sortField = filter;
    // Apenas utilizadores com showInLeaderboard === true (campo obrigatório)
    const users = await User.find({ showInLeaderboard: true, isServer: { $ne: true } }).sort({ [sortField]: -1 }).limit(100).lean();

    const mapped = users.map(u => ({
      username: u.username,
      discordId: u.discordId || null,
      avatar: u.avatar || null,
      avatarUrl: u.discordAvatar || null,
      avatarDecoration: u.discordAvatarDecorationData?.asset || u.avatarDecoration || null,
      level: Number(u.level || 0),
      wins: Number(u.wins || 0),
      kills: Number(u.kills || 0),
      deaths: Number(u.deaths || 0)
    }));

    res.json(mapped);
  } catch (err) {
    log.error('Failed to get launcher leaderboard', err);
    res.status(500).json({ success: false, error: 'Failed to fetch leaderboard' });
  }
});

app.post('/api/launcher/claim-rewards', verifySessionMiddleware, async (req, res) => {
  try {
    const user = await User.findOne({ _id: req.user._id });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    const now = Date.now();
    const COOLDOWN = 60 * 60 * 1000;

    if (user.lastRewardClaim && (now - user.lastRewardClaim) < COOLDOWN) {
      const timeLeft = COOLDOWN - (now - user.lastRewardClaim);
      return res.status(400).json({ success: false, error: 'Cooldown active', timeLeft });
    }

    const amount = 100;
    user.vbucks = (user.vbucks || 0) + amount;
    user.lastRewardClaim = now;
    await user.save();

    const urls = ['https://guns.lol/santi.2._', 'https://guns.lol/salvinhaa'];
    const url = urls[Math.floor(Math.random() * urls.length)];

    res.json({ success: true, message: `Claimed ${amount} V-Bucks`, url, vbucks: user.vbucks });
  } catch (err) {
    log.error('Failed to claim rewards', err);
    res.status(500).json({ success: false, error: 'Failed to claim rewards' });
  }
});

app.post('/api/launcher/purchase-item', verifySessionMiddleware, async (req, res) => {
  try {
    const { itemId } = req.body;

    if (!itemId) {
      return res.status(400).json({ success: false, error: 'Missing itemId' });
    }

    const offer = functions.getOfferID(itemId);
    if (!offer || !offer.offerId) {
      return res.status(404).json({ success: false, error: 'Offer not found' });
    }

    const entry = offer.offerId;
    const price = (entry.prices && entry.prices[0] && entry.prices[0].finalPrice) || 0;

    const user = await User.findOne({ _id: req.user._id }).lean();
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    let profileDoc = await Profile.findOne({ accountId: req.user.accountId });
    if (!profileDoc) {
      profileDoc = new Profile({ created: new Date(), accountId: req.user.accountId, profiles: { common_core: { items: {} } } });
    }

    const commonItems = (profileDoc.profiles && profileDoc.profiles['common_core'] && profileDoc.profiles['common_core'].items) || {};
    const athenaItems = (profileDoc.profiles && profileDoc.profiles['athena'] && profileDoc.profiles['athena'].items) || {};

    const itemGrants = entry.itemGrants || [];
    for (const grant of itemGrants) {
      if (!grant || !grant.templateId) continue;
      const tmpl = grant.templateId.toLowerCase();
      const foundInCommon = Object.values(commonItems).find(it => it && it.templateId && it.templateId.toLowerCase() === tmpl);
      const foundInAthena = Object.values(athenaItems).find(it => it && it.templateId && it.templateId.toLowerCase() === tmpl);
      if (foundInCommon || foundInAthena) {
        return res.status(400).json({ success: false, error: 'Item already owned' });
      }
    }

    if ((user.vbucks || 0) < price) {
      return res.status(400).json({ success: false, error: 'Insufficient V-Bucks' });
    }

    await User.updateOne({ _id: user._id }, { $inc: { vbucks: -price } });

    if (!profileDoc.profiles['common_core']) profileDoc.profiles['common_core'] = { items: {} };
    if (!profileDoc.profiles['common_core'].items) profileDoc.profiles['common_core'].items = {};

    for (const grant of itemGrants) {
      if (!grant || !grant.templateId) continue;
      const templateId = grant.templateId;
      const key = `Purchased:${templateId}:${functions.MakeID()}`;
      profileDoc.profiles['common_core'].items[key] = {
        templateId,
        attributes: {
          item_seen: true,
          favorite: false
        },
        quantity: 1
      };
    }

    await profileDoc.save();

    const updatedUser = await User.findOne({ _id: user._id }).lean();

    res.json({ success: true, message: 'Purchase successful', itemId, vbucks: updatedUser.vbucks });
  } catch (err) {
    log.error('Failed to purchase item', err);
    res.status(500).json({ success: false, error: 'Purchase failed' });
  }
});

app.post('/api/reward-kill', async (req, res) => {
  try {
    const { accountId, kills, playlist } = req.body;

    if (!accountId) {
      return res.status(400).json({ success: false, error: 'Missing accountId' });
    }

    const killCount = kills || 1;

    // Get playlist specific rewards or use default (V-Bucks only, hype calculated at match end)
    const playlistRewards = config.arenaRewards[playlist] || config.arenaRewards.default;
    const vbucksPerKill = playlistRewards.kill.vbucks;

    const vbucksReward = killCount * vbucksPerKill;

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    user.vbucks = (user.vbucks || 0) + vbucksReward;
    user.kills = (user.kills || 0) + killCount;

    await user.save();

    log.debug(`[REWARD KILL] ${user.username} earned ${vbucksReward} V-Bucks for ${killCount} kills in ${playlist || 'default'} (Hype calculated at match end)`);

    log.AutoRotation(`[Game Reward] Kill reward: ${accountId} +${vbucksReward} vbucks (${killCount} kills)`);



    // Sync vbucks to Profile MongoDB so PurchaseCatalogEntry sees the updated value
    await syncVbucksToProfile(accountId, user.vbucks);

    // CRITICAL: Invalidate profile cache so client gets fresh data from users collection
    if (global.invalidateProfileCache) {
      global.invalidateProfileCache(accountId);
      log.debug(`[REWARD KILL] Invalidated profile cache for ${accountId}`);
    }

    res.json({
      success: true,
      message: `Added ${vbucksReward} V-Bucks for ${killCount} kills`,
      vbucks: user.vbucks
    });
  } catch (err) {
    log.error('Failed to process kill reward', err);
    res.status(500).json({ success: false, error: 'Failed to process kill reward' });
  }
});

app.post('/api/reward-win', async (req, res) => {
  try {
    const { accountId, playlist } = req.body;

    if (!accountId) {
      return res.status(400).json({ success: false, error: 'Missing accountId' });
    }

    // Get playlist specific rewards or use default
    const playlistRewards = config.arenaRewards[playlist] || config.arenaRewards.default;
    const vbucksPerWin = playlistRewards.win.vbucks;

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    user.vbucks = (user.vbucks || 0) + vbucksPerWin;
    user.wins = (user.wins || 0) + 1;

    await user.save();

    log.backend(`[REWARD WIN] ${user.username} earned ${vbucksPerWin} V-Bucks for victory in ${playlist || 'default'} (Hype calculated at match end)`);

    log.AutoRotation(`[Game Reward] Win reward: ${accountId} +${vbucksPerWin} vbucks`);

    // Sync vbucks to Profile MongoDB so PurchaseCatalogEntry sees the updated value
    await syncVbucksToProfile(accountId, user.vbucks);

    // CRITICAL: Invalidate profile cache so client gets fresh data from users collection
    if (global.invalidateProfileCache) {
      global.invalidateProfileCache(accountId);
      log.debug(`[REWARD WIN] Invalidated profile cache for ${accountId}`);
    }

    res.json({
      success: true,
      message: `Added ${vbucksPerWin} V-Bucks for match win`,
      vbucks: user.vbucks
    });
  } catch (err) {
    log.error('Failed to process win reward', err);
    res.status(500).json({ success: false, error: 'Failed to process win reward' });
  }
});

// Bus loss penalty endpoint
app.post('/api/reward-bus-loss', async (req, res) => {
  try {
    const { accountId, playlist } = req.body;

    if (!accountId) {
      return res.status(400).json({ success: false, error: 'Missing accountId' });
    }

    // Get playlist specific penalties or use default
    const playlistRewards = config.arenaRewards[playlist] || config.arenaRewards.default;
    const arenaPointsPenalty = playlistRewards.busLoss.arenaPoints;

    if (arenaPointsPenalty === 0) {
      return res.json({ success: true, message: 'No penalty for this playlist' });
    }

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    user.hype = Math.max(0, (user.hype || 0) + arenaPointsPenalty); // Don't go negative

    // Calculate and update division
    const divisionInfo = calculateDivision(user.hype);
    user.division = divisionInfo.id;

    await user.save();

    log.debug(`[BUS LOSS] ${user.username} lost ${Math.abs(arenaPointsPenalty)} Hype for bus loss in ${playlist || 'default'}`);

    res.json({
      success: true,
      message: `Removed ${Math.abs(arenaPointsPenalty)} Hype for leaving in bus`,
      hype: user.hype,
      division: user.division
    });
  } catch (err) {
    log.error('Failed to process bus loss penalty', err);
    res.status(500).json({ success: false, error: 'Failed to process bus loss' });
  }
});

// Sync user.arenaPoints to arena.hype AND user.vbucks to profile (fix for existing users)
// Get user stats (kills, wins, hype, vbucks, division)
app.get('/api/user-stats/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const divisionInfo = calculateDivision(user.hype || 0);

    res.json({
      success: true,
      accountId: user.accountId,
      username: user.username,
      hype: user.hype || 0,
      division: divisionInfo,
      vbucks: user.vbucks || 0,
      kills: user.kills || 0,
      wins: user.wins || 0,
      deaths: user.deaths || 0,
      matchesPlayed: user.matchesPlayed || 0,
      level: user.level || 1,
      xp: user.xp || 0
    });
  } catch (err) {
    log.error('Failed to get user stats', err);
    res.status(500).json({ success: false, error: 'Failed to get user stats' });
  }
});

// Get arena division info
app.get('/api/arena-division/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const divisionInfo = calculateDivision(user.hype || 0);

    res.json({
      success: true,
      accountId: accountId,
      hype: user.hype || 0,
      division: divisionInfo,
      allDivisions: config.arenaDivisions
    });
  } catch (err) {
    log.error('Failed to get arena division', err);
    res.status(500).json({ success: false, error: 'Failed to get division' });
  }
});

// Get current hype for a player (used by gameserver to initialize TournamentScore)
app.get('/api/get-hype/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;

    log.debug(`[Get Hype] Request for accountId: ${accountId}`);

    const user = await User.findOne({ accountId });
    if (!user) {
      log.error(`[Get Hype] User not found: ${accountId}`);
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const hype = user.hype || 0;
    const division = user.division || 0;

    log.debug(`[Get Hype] Returning for ${user.username}: hype=${hype}, division=${division}`);

    res.json({
      success: true,
      accountId: user.accountId,
      hype: hype,
      division: division
    });
  } catch (err) {
    log.error('[Get Hype] Failed to get hype', err);
    res.status(500).json({ success: false, error: 'Failed to get hype' });
  }
});

app.post('/api/add-xp', async (req, res) => {
  try {
    const { accountId, xp } = req.body;

    if (!accountId || !xp) {
      return res.status(400).json({ success: false, error: 'Missing accountId or xp' });
    }

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const xpPerLevel = 1000;
    user.xp = (user.xp || 0) + xp;

    const newLevel = Math.floor(user.xp / xpPerLevel) + 1;
    const oldLevel = user.level || 1;

    if (newLevel > oldLevel) {
      user.level = newLevel;
      log.AutoRotation(`[Level UP] ${accountId} reached Level ${newLevel}!`);
    }

    await user.save();

    res.json({ 
      success: true, 
      message: `Added ${xp} XP`, 
      level: user.level, 
      xp: user.xp,
      leveledUp: newLevel > oldLevel
    });
  } catch (err) {
    log.error('Failed to process XP', err);
    res.status(500).json({ success: false, error: 'Failed to process XP' });
  }
});

app.post('/api/add-game-stats', async (req, res) => {
  try {
    const { accountId, kills, wins, deaths, arenaPoints } = req.body;

    if (!accountId) {
      return res.status(400).json({ success: false, error: 'Missing accountId' });
    }

    const user = await User.findOne({ accountId });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    if (kills) user.kills = (user.kills || 0) + kills;
    if (wins) user.wins = (user.wins || 0) + wins;
    if (deaths) user.deaths = (user.deaths || 0) + deaths;
    if (arenaPoints) {
      user.hype = (user.hype || 0) + arenaPoints;
      // Calculate and update division
      const divisionInfo = calculateDivision(user.hype);
      user.division = divisionInfo.id;
    }

    user.matchesPlayed = (user.matchesPlayed || 0) + 1;

    await user.save();

    log.AutoRotation(`[Game Stats] ${accountId}: +${kills || 0}K +${wins || 0}W +${deaths || 0}D +${arenaPoints || 0}H`);

    // Player count and phase are updated by the gameserver via /api/report-match-state
    // No manual tracking needed here

    res.json({
      success: true,
      message: 'Game stats updated',
      stats: {
        kills: user.kills,
        wins: user.wins,
        deaths: user.deaths,
        hype: user.hype,
        division: user.division,
        matchesPlayed: user.matchesPlayed
      }
    });
  } catch (err) {
    log.error('Failed to process game stats', err);
    res.status(500).json({ success: false, error: 'Failed to process game stats' });
  }
});

// ── GET /api/launcher/username-change-status ───────────────────────────────
app.get('/api/launcher/username-change-status', verifySessionMiddleware, async (req, res) => {
  try {
    const user = await User.findOne({ _id: req.user._id }).lean();
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    const isDonator = !!(user.basicDonator || user.mediumDonator || user.highDonator || user.ultimateDonator || user.donator);
    const COOLDOWN_DAYS = 14;
    const COOLDOWN_MS = COOLDOWN_DAYS * 24 * 60 * 60 * 1000;

    let canChange = false;
    let daysLeft = 0;

    if (isDonator) {
      if (!user.lastUsernameChange) {
        canChange = true;
      } else {
        const elapsed = Date.now() - new Date(user.lastUsernameChange).getTime();
        if (elapsed >= COOLDOWN_MS) {
          canChange = true;
        } else {
          daysLeft = Math.ceil((COOLDOWN_MS - elapsed) / (24 * 60 * 60 * 1000));
        }
      }
    }

    res.json({
      isDonator,
      canChange,
      daysLeft,
      currentUsername: user.username,
      lastChange: user.lastUsernameChange || null
    });
  } catch (err) {
    log.error('Failed to get username status', err);
    res.status(500).json({ success: false, error: 'Failed to get status' });
  }
});

// ── POST /api/launcher/change-username ────────────────────────────────────
app.post('/api/launcher/change-username', verifySessionMiddleware, async (req, res) => {
  try {
    const { newUsername } = req.body;

    if (!newUsername || typeof newUsername !== 'string') {
      return res.status(400).json({ success: false, error: 'Missing newUsername' });
    }

    const trimmed = newUsername.trim();

    if (!/^[a-zA-Z0-9_-]{3,20}$/.test(trimmed)) {
      return res.status(400).json({ success: false, error: 'Username must be 3-20 chars, only letters, numbers, _ and -' });
    }

    const user = await User.findOne({ _id: req.user._id });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    // Donator check
    const isDonator = !!(user.basicDonator || user.mediumDonator || user.highDonator || user.ultimateDonator || user.donator);
    if (!isDonator) {
      return res.status(403).json({ success: false, error: 'Only donators can change their username' });
    }

    // Cooldown check
    const COOLDOWN_MS = 14 * 24 * 60 * 60 * 1000;
    if (user.lastUsernameChange) {
      const elapsed = Date.now() - new Date(user.lastUsernameChange).getTime();
      if (elapsed < COOLDOWN_MS) {
        const daysLeft = Math.ceil((COOLDOWN_MS - elapsed) / (24 * 60 * 60 * 1000));
        return res.status(400).json({ success: false, error: `You can change your username again in ${daysLeft} day(s).`, daysLeft });
      }
    }

    // Uniqueness check
    const existing = await User.findOne({ username_lower: trimmed.toLowerCase() });
    if (existing && existing._id.toString() !== user._id.toString()) {
      return res.status(400).json({ success: false, error: 'Username already taken' });
    }

    user.username = trimmed;
    user.username_lower = trimmed.toLowerCase();
    user.lastUsernameChange = new Date();
    await user.save();

    res.json({ success: true, username: trimmed });
  } catch (err) {
    log.error('Failed to change username', err);
    res.status(500).json({ success: false, error: 'Failed to change username' });
  }
});

// ── POST /api/report-match-state ─────────────────────────────────────────────
// Called by gameserver - no auth required (same pattern as /api/reward-kill)
app.post('/api/report-match-state', async (req, res) => {
  try {
    const { serverId, phase, currentPlayers, playlist, region } = req.body;

    if (!serverId || !phase) {
      return res.status(400).json({ success: false, error: 'Missing serverId or phase' });
    }

    const validPhases = ['setting_up', 'joinable', 'in_match'];
    if (!validPhases.includes(phase)) {
      return res.status(400).json({ success: false, error: 'Invalid phase' });
    }

    const server = await GameServer.findOne({ serverId });
    if (!server) {
      // Auto-create entry so the gameserver doesn't need pre-configuration
      const newServer = new GameServer({
        serverId,
        ip: '0.0.0.0',
        port: 7777,
        region: region || 'EU',
        supportedPlaylists: playlist ? [playlist] : [],
        maxPlayers: 100,
        status: 'online',
        serverPhase: phase,
        'health.lastHeartbeat': new Date(),
        currentMatch: {
          playlist: playlist || null,
          playersInMatch: currentPlayers || 0,
          maxPlayers: 100,
          phase
        }
      });
      await newServer.save();
      log.backend(`[MatchState] Auto-created server: ${serverId} phase=${phase}`);
      return res.json({ success: true });
    }

    server.serverPhase = phase;
    server.status = 'online';
    server.health.lastHeartbeat = new Date();

    if (region) server.region = region;
    if (playlist) {
      server.currentMatch.playlist = playlist;
      if (!server.supportedPlaylists.includes(playlist)) {
        server.supportedPlaylists.push(playlist);
      }
    }
    if (currentPlayers !== undefined) {
      server.currentMatch.playersInMatch = currentPlayers;
    }
    server.currentMatch.phase = phase;

    if (phase === 'setting_up') {
      server.currentMatch.playersInMatch = 0;
    }

    await server.save();

    log.backend(`[MatchState] ${serverId} -> ${phase} (${currentPlayers || 0} players, ${playlist || 'unknown'})`);
    res.json({ success: true });
  } catch (err) {
    log.error('[MatchState] Error:', err);
    res.status(500).json({ success: false, error: 'Internal error' });
  }
});

// ── GET /api/launcher/matches ─────────────────────────────────────────────────
// Returns live server states for the launcher matches page
app.get('/api/launcher/matches', verifySessionMiddleware, async (req, res) => {
  try {
    const servers = await GameServer.find({}).lean();

    // Load playlist display names from playlist_display.json
    let playlistDisplayNames = {};
    try {
      const playlistDisplayConfig = require('../Config/playlist_display.json');
      if (playlistDisplayConfig && playlistDisplayConfig.playlists) {
        for (const [key, val] of Object.entries(playlistDisplayConfig.playlists)) {
          const name = val.displayName && (val.displayName.en || Object.values(val.displayName)[0]);
          if (name) playlistDisplayNames[key.toLowerCase()] = name;
        }
      }
    } catch (e) {}

    const formatPlaylist = (raw) => {
      if (!raw) return 'Unknown';
      // Extract key from UE path like /Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo
      const parts = raw.split('/');
      const last = parts[parts.length - 1];
      const key = (last.split('.')[0] || last).toLowerCase();
      // Check playlist_display.json first
      if (playlistDisplayNames[key]) return playlistDisplayNames[key];
      // Fallback: humanize
      return key
        .replace(/^playlist_/i, '')
        .replace(/showdown(alt_)?/i, 'Arena ')
        .replace(/defaultsolo/i, 'Solo')
        .replace(/defaultduo/i, 'Duos')
        .replace(/defaultsquad/i, 'Squads')
        .replace(/_/g, ' ')
        .trim()
        .replace(/\b\w/g, c => c.toUpperCase());
    };

    const mapped = servers.map(s => {
      // Source of truth: only what the gameserver reported via /api/report-match-state
      // Phases: setting_up -> joinable -> in_match -> (restart -> setting_up)
      const rawPhase = s.serverPhase || 'setting_up';
      const isOnline = s.status === 'online';
      const playersInMatch = s.currentMatch?.playersInMatch || 0;

      let displayPhase;
      if (!isOnline) {
        displayPhase = 'loading';
      } else if (rawPhase === 'in_match') {
        displayPhase = 'in_match';
      } else if (rawPhase === 'joinable') {
        displayPhase = 'awaiting';
      } else {
        // setting_up or unknown
        displayPhase = 'loading';
      }

      return {
        serverId: s.serverId,
        phase: rawPhase,
        displayPhase,
        status: s.status || 'offline',
        region: s.region || 'EU',
        playlist: formatPlaylist(s.currentMatch?.playlist || (s.supportedPlaylists && s.supportedPlaylists[0]) || null),
        playlistRaw: s.currentMatch?.playlist || (s.supportedPlaylists && s.supportedPlaylists[0]) || null,
        currentPlayers: playersInMatch,
        maxPlayers: s.maxPlayers || 100,
        lastSeen: s.health?.lastHeartbeat || null
      };
    });

    // Group by displayPhase
    const grouped = {
      awaiting: mapped.filter(s => s.displayPhase === 'awaiting'),
      in_match: mapped.filter(s => s.displayPhase === 'in_match'),
      loading:  mapped.filter(s => s.displayPhase === 'loading')
    };

    res.json({ success: true, servers: mapped, grouped });
  } catch (err) {
    log.error('[Launcher Matches] Error:', err);
    res.status(500).json({ success: false, error: 'Internal error' });
  }
});

module.exports = app;