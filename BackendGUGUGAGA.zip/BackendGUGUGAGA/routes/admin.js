const express = require('express');
const app = express.Router();
const User = require('../model/user.js');
const Profile = require('../model/profiles.js');
const log = require('../structs/log.js');
const functions = require('../structs/functions.js');
const fs = require('fs');
const path = require('path');

// Shared helper: sync user.vbucks to Profile MongoDB
async function syncVbucksToProfile(accountId, newVbucks, ProfileModel, logger) {
  try {
    const profiles = await ProfileModel.findOne({ accountId });
    if (!profiles) return;
    let changed = false;
    for (const profileId of ['common_core', 'profile0']) {
      const profile = profiles.profiles[profileId];
      if (!profile || !profile.items) continue;
      let found = false;
      for (const key in profile.items) {
        if (profile.items[key].templateId && profile.items[key].templateId.toLowerCase().startsWith('currency:mtx')) {
          profile.items[key].quantity = newVbucks;
          found = true; changed = true; break;
        }
      }
      if (!found) {
        profile.items['Currency:MtxPurchased'] = { templateId: 'Currency:MtxPurchased', attributes: { platform: 'EpicPC' }, quantity: newVbucks };
        changed = true;
      }
      if (changed) {
        profile.rvn = (profile.rvn || 0) + 1;
        profile.commandRevision = (profile.commandRevision || 0) + 1;
        profile.updated = new Date().toISOString();
      }
    }
    if (changed) {
      await ProfileModel.updateOne({ accountId }, { $set: { 'profiles.common_core': profiles.profiles['common_core'], 'profiles.profile0': profiles.profiles['profile0'] } });
      if (global.invalidateProfileCache) global.invalidateProfileCache(accountId);
    }
  } catch (err) {
    if (logger) logger.error('[syncVbucks] Failed:', err);
  }
}

// News JSON file path
const newsFilePath = path.join(__dirname, '../Config/news.json');

// Helper functions for news JSON
function readNewsFile() {
  try {
    if (!fs.existsSync(newsFilePath)) {
      fs.writeFileSync(newsFilePath, JSON.stringify({ news: [] }, null, 2));
    }
    const data = fs.readFileSync(newsFilePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    log.error('Error reading news file:', error);
    return { news: [] };
  }
}

function writeNewsFile(data) {
  try {
    fs.writeFileSync(newsFilePath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    log.error('Error writing news file:', error);
    return false;
  }
}

function generateNewsId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

// Middleware to verify admin session
async function verifyAdminMiddleware(req, res, next) {
  try {
    // Try to get sessionID from cookie first, then from header
    const cookieHeader = req.headers.cookie || '';
    const match = cookieHeader.match(/connect\.sid=([^;]+)/);
    let sessionID = match && match[1];

    // Fallback: check x-session-id header (for Electron renderer)
    if (!sessionID) {
      sessionID = req.headers['x-session-id'];
    }

    if (!sessionID || !global.launcherSessions || !global.launcherSessions[sessionID]) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const sessionObj = global.launcherSessions[sessionID];
    const user = await User.findOne({ _id: sessionObj.user._id }).lean();

    if (!user || user.isAdmin !== true) {
      return res.status(403).json({ success: false, error: 'Admin access required' });
    }

    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
  }
}

// GET /api/admin/users - Search users
app.get('/api/admin/users', verifyAdminMiddleware, async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};

    if (search) {
      query = {
        $or: [
          { username: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
          { discordId: search }
        ]
      };
    }

    const users = await User.find(query).limit(50).lean();
    const mapped = users.map(u => ({
      id: u._id,
      username: u.username,
      email: u.email,
      discordId: u.discordId,
      banned: u.banned || false,
      isAdmin: u.isAdmin || false,
      donator: u.donator || false,
      vbucks: u.vbucks || 0,
      level: u.level || 1
    }));

    res.json({ success: true, users: mapped });
  } catch (err) {
    log.error('Admin users search error:', err);
    res.status(500).json({ success: false, error: 'Failed to search users' });
  }
});

// POST /api/admin/ban - Ban user
app.post('/api/admin/ban', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });
    if (user.banned) return res.status(400).json({ success: false, error: 'User already banned' });

    await user.updateOne({ $set: { banned: true } });

    // Kick from game if online
    let refreshToken = global.refreshTokens.findIndex(i => i.accountId == user.accountId);
    if (refreshToken != -1) global.refreshTokens.splice(refreshToken, 1);

    let accessToken = global.accessTokens.findIndex(i => i.accountId == user.accountId);
    if (accessToken != -1) {
      global.accessTokens.splice(accessToken, 1);
      let xmppClient = global.Clients.find(client => client.accountId == user.accountId);
      if (xmppClient) xmppClient.client.close();
    }

    if (accessToken != -1 || refreshToken != -1) functions.UpdateTokens();

    res.json({ success: true, message: `Banned ${user.username}` });
  } catch (err) {
    log.error('Admin ban error:', err);
    res.status(500).json({ success: false, error: 'Failed to ban user' });
  }
});

// POST /api/admin/unban - Unban user
app.post('/api/admin/unban', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });
    if (!user.banned) return res.status(400).json({ success: false, error: 'User is not banned' });

    await user.updateOne({ $set: { banned: false } });

    res.json({ success: true, message: `Unbanned ${user.username}` });
  } catch (err) {
    log.error('Admin unban error:', err);
    res.status(500).json({ success: false, error: 'Failed to unban user' });
  }
});

// POST /api/admin/kick - Kick user from game
app.post('/api/admin/kick', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    let refreshToken = global.refreshTokens.findIndex(i => i.accountId == user.accountId);
    if (refreshToken != -1) global.refreshTokens.splice(refreshToken, 1);

    let accessToken = global.accessTokens.findIndex(i => i.accountId == user.accountId);
    if (accessToken != -1) {
      global.accessTokens.splice(accessToken, 1);
      let xmppClient = global.Clients.find(client => client.accountId == user.accountId);
      if (xmppClient) xmppClient.client.close();
    }

    if (accessToken != -1 || refreshToken != -1) {
      functions.UpdateTokens();
      res.json({ success: true, message: `Kicked ${user.username}` });
    } else {
      res.status(400).json({ success: false, error: 'User is not online' });
    }
  } catch (err) {
    log.error('Admin kick error:', err);
    res.status(500).json({ success: false, error: 'Failed to kick user' });
  }
});

// POST /api/admin/vbucks - Add/Remove V-Bucks
app.post('/api/admin/vbucks', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username, amount } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });
    if (amount === undefined || amount === 0) return res.status(400).json({ success: false, error: 'Amount required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    const newVbucks = Math.max(0, (user.vbucks || 0) + parseInt(amount));
    await user.updateOne({ $set: { vbucks: newVbucks } });

    // Sync to Profile MongoDB so the game/shop shows correct balance
    await syncVbucksToProfile(user.accountId, newVbucks, Profile, log);

    const action = amount > 0 ? 'Added' : 'Removed';
    res.json({ success: true, message: `${action} ${Math.abs(amount)} V-Bucks. New balance: ${newVbucks}` });
  } catch (err) {
    log.error('Admin vbucks error:', err);
    res.status(500).json({ success: false, error: 'Failed to update V-Bucks' });
  }
});

// POST /api/admin/setadmin - Set admin status
app.post('/api/admin/setadmin', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username, isAdmin } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    await user.updateOne({ $set: { isAdmin: isAdmin === true } });

    const status = isAdmin ? 'granted admin to' : 'removed admin from';
    res.json({ success: true, message: `Successfully ${status} ${user.username}` });
  } catch (err) {
    log.error('Admin setadmin error:', err);
    res.status(500).json({ success: false, error: 'Failed to update admin status' });
  }
});

// POST /api/admin/setdonator - Set donator status
app.post('/api/admin/setdonator', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username, tier } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    const update = {
      basicDonator: ['basic', 'medium', 'high', 'ultimate'].includes(tier),
      donator: ['basic', 'medium', 'high', 'ultimate'].includes(tier),
      mediumDonator: ['medium', 'high', 'ultimate'].includes(tier),
      highDonator: ['high', 'ultimate'].includes(tier),
      ultimateDonator: tier === 'ultimate'
    };

    await user.updateOne({ $set: update });

    res.json({ success: true, message: `Set ${user.username} donator tier to: ${tier || 'none'}` });
  } catch (err) {
    log.error('Admin setdonator error:', err);
    res.status(500).json({ success: false, error: 'Failed to update donator status' });
  }
});

// POST /api/admin/addall - Give all items to user
app.post('/api/admin/addall', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    // Load allathena profile
    const fs = require('fs');
    const allAthena = JSON.parse(fs.readFileSync('./Config/DefaultProfiles/allathena.json', 'utf8'));

    await Profile.updateOne(
      { accountId: user.accountId },
      { $set: { 'profiles.athena': allAthena } }
    );

    res.json({ success: true, message: `Gave all items to ${user.username}` });
  } catch (err) {
    log.error('Admin addall error:', err);
    res.status(500).json({ success: false, error: 'Failed to add all items' });
  }
});

// POST /api/admin/removeall - Remove all items from user
app.post('/api/admin/removeall', verifyAdminMiddleware, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ success: false, error: 'Username required' });

    const user = await User.findOne({ username_lower: username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, error: 'User not found' });

    // Load default athena profile
    const fs = require('fs');
    const defaultAthena = JSON.parse(fs.readFileSync('./Config/DefaultProfiles/athena.json', 'utf8'));

    await Profile.updateOne(
      { accountId: user.accountId },
      { $set: { 'profiles.athena': defaultAthena } }
    );

    res.json({ success: true, message: `Removed all items from ${user.username}` });
  } catch (err) {
    log.error('Admin removeall error:', err);
    res.status(500).json({ success: false, error: 'Failed to remove all items' });
  }
});

// GET /api/admin/online - Get online players
app.get('/api/admin/online', verifyAdminMiddleware, async (req, res) => {
  try {
    const onlinePlayers = global.Clients ? global.Clients.length : 0;
    const players = [];

    if (global.Clients) {
      for (const client of global.Clients) {
        const user = await User.findOne({ accountId: client.accountId }).lean();
        if (user) {
          players.push({
            username: user.username,
            accountId: user.accountId
          });
        }
      }
    }

    res.json({ success: true, count: onlinePlayers, players });
  } catch (err) {
    log.error('Admin online error:', err);
    res.status(500).json({ success: false, error: 'Failed to get online players' });
  }
});

// POST /api/admin/restart - Restart backend (schedule)
app.post('/api/admin/restart', verifyAdminMiddleware, async (req, res) => {
  try {
    res.json({ success: true, message: 'Backend will restart in 5 seconds...' });

    setTimeout(() => {
      log.backend('Admin triggered restart');
      process.exit(0);
    }, 5000);
  } catch (err) {
    log.error('Admin restart error:', err);
    res.status(500).json({ success: false, error: 'Failed to restart' });
  }
});

// ==================== NEWS MANAGEMENT (JSON FILE) ====================

// GET /api/news - Get all news (PUBLIC - no auth required)
app.get('/api/news', (req, res) => {
  try {
    const data = readNewsFile();
    // Sort by pinned first, then by createdAt descending
    const sortedNews = data.news.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
    res.json({ success: true, news: sortedNews.slice(0, 50) });
  } catch (err) {
    log.error('Get news error:', err);
    res.status(500).json({ success: false, error: 'Failed to get news' });
  }
});

// POST /api/admin/news - Create news (Admin only)
app.post('/api/admin/news', verifyAdminMiddleware, (req, res) => {
  try {
    const { title, content, pinned } = req.body;

    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Title and content are required' });
    }

    const data = readNewsFile();

    const newNews = {
      _id: generateNewsId(),
      title: title.trim(),
      content: content.trim(),
      author: req.user.username,
      authorId: req.user.accountId || '',
      pinned: pinned === true,
      createdAt: new Date().toISOString()
    };

    data.news.push(newNews);

    if (!writeNewsFile(data)) {
      return res.status(500).json({ success: false, error: 'Failed to save news' });
    }

    log.backend(`News created by ${req.user.username}: ${title}`);
    res.json({ success: true, message: 'News created successfully', news: newNews });
  } catch (err) {
    log.error('Create news error:', err);
    res.status(500).json({ success: false, error: 'Failed to create news' });
  }
});

// DELETE /api/admin/news/:id - Delete news (Admin only)
app.delete('/api/admin/news/:id', verifyAdminMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const data = readNewsFile();

    const newsIndex = data.news.findIndex(n => n._id === id);
    if (newsIndex === -1) {
      return res.status(404).json({ success: false, error: 'News not found' });
    }

    const deletedNews = data.news[newsIndex];
    data.news.splice(newsIndex, 1);

    if (!writeNewsFile(data)) {
      return res.status(500).json({ success: false, error: 'Failed to delete news' });
    }

    log.backend(`News deleted by ${req.user.username}: ${deletedNews.title}`);
    res.json({ success: true, message: 'News deleted successfully' });
  } catch (err) {
    log.error('Delete news error:', err);
    res.status(500).json({ success: false, error: 'Failed to delete news' });
  }
});

// PUT /api/admin/news/:id - Update news (Admin only)
app.put('/api/admin/news/:id', verifyAdminMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, pinned } = req.body;

    const data = readNewsFile();
    const newsIndex = data.news.findIndex(n => n._id === id);

    if (newsIndex === -1) {
      return res.status(404).json({ success: false, error: 'News not found' });
    }

    if (title) data.news[newsIndex].title = title.trim();
    if (content) data.news[newsIndex].content = content.trim();
    if (pinned !== undefined) data.news[newsIndex].pinned = pinned === true;

    if (!writeNewsFile(data)) {
      return res.status(500).json({ success: false, error: 'Failed to update news' });
    }

    log.backend(`News updated by ${req.user.username}: ${data.news[newsIndex].title}`);
    res.json({ success: true, message: 'News updated successfully' });
  } catch (err) {
    log.error('Update news error:', err);
    res.status(500).json({ success: false, error: 'Failed to update news' });
  }
});

// ==================== ANTICHEAT BAN ENDPOINT ====================

// POST /api/anticheat/ban - Ban user from anticheat detection (uses secret token)
app.post('/api/anticheat/ban', async (req, res) => {
  try {
    const { token, email, reason, details, hwid } = req.body;

    // Verify anticheat token
    const ANTICHEAT_SECRET = 'VORZA_AC_SECRET_2026';
    if (token !== ANTICHEAT_SECRET) {
      return res.status(401).json({ success: false, error: 'Invalid anticheat token' });
    }

    if (!email) {
      return res.status(400).json({ success: false, error: 'Email required' });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    if (user.banned) {
      return res.json({ success: true, message: 'User already banned' });
    }

    // Ban user account
    await user.updateOne({
      $set: {
        banned: true,
        bannedReason: reason,
        bannedAt: new Date(),
        bannedHwid: hwid || null
      }
    });

    // Add HWID to global banned list if provided
    if (hwid) {
      if (!global.bannedHwids) {
        global.bannedHwids = new Set();
      }
      global.bannedHwids.add(hwid);

      // Save to file for persistence
      const fs = require('fs');
      const path = require('path');
      const bannedHwidsFile = path.join(__dirname, '../Config/banned-hwids.json');

      try {
        let bannedHwids = [];
        if (fs.existsSync(bannedHwidsFile)) {
          bannedHwids = JSON.parse(fs.readFileSync(bannedHwidsFile, 'utf8'));
        }

        if (!bannedHwids.find(h => h.hwid === hwid)) {
          bannedHwids.push({
            hwid: hwid,
            email: email,
            username: user.username,
            reason: reason,
            bannedAt: new Date().toISOString(),
            details: details
          });

          fs.writeFileSync(bannedHwidsFile, JSON.stringify(bannedHwids, null, 2));
        }
      } catch (err) {
        log.error('Failed to save HWID ban:', err);
      }
    }

    // Kick from game if online
    let refreshToken = global.refreshTokens.findIndex(i => i.accountId == user.accountId);
    if (refreshToken != -1) global.refreshTokens.splice(refreshToken, 1);

    let accessToken = global.accessTokens.findIndex(i => i.accountId == user.accountId);
    if (accessToken != -1) {
      global.accessTokens.splice(accessToken, 1);
      let xmppClient = global.Clients.find(client => client.accountId == user.accountId);
      if (xmppClient) xmppClient.client.close();
    }

    if (accessToken != -1 || refreshToken != -1) functions.UpdateTokens();

    log.backend(`[ANTICHEAT] HWID BAN - ${user.username} (${email}) - Reason: ${reason} - HWID: ${hwid ? hwid.substring(0, 16) + '...' : 'N/A'}`);

    res.json({
      success: true,
      message: `Hardware banned ${user.username}`,
      username: user.username,
      reason: reason,
      hwidBanned: !!hwid
    });
  } catch (err) {
    log.error('Anticheat ban error:', err);
    res.status(500).json({ success: false, error: 'Failed to ban user' });
  }
});

// POST /api/anticheat/check-hwid - Check if HWID is banned (uses secret token)
app.post('/api/anticheat/check-hwid', async (req, res) => {
  try {
    const { token, hwid, email } = req.body;

    // Verify anticheat token
    const ANTICHEAT_SECRET = 'VORZA_AC_SECRET_2026';
    if (token !== ANTICHEAT_SECRET) {
      return res.status(401).json({ success: false, error: 'Invalid anticheat token' });
    }

    if (!hwid) {
      return res.status(400).json({ success: false, error: 'HWID required' });
    }

    // Load banned HWIDs from file
    const fs = require('fs');
    const path = require('path');
    const bannedHwidsFile = path.join(__dirname, '../Config/banned-hwids.json');

    let bannedHwids = [];
    if (fs.existsSync(bannedHwidsFile)) {
      try {
        bannedHwids = JSON.parse(fs.readFileSync(bannedHwidsFile, 'utf8'));
      } catch (err) {
        log.error('Failed to read banned HWIDs:', err);
      }
    }

    // Check if HWID is banned
    const bannedHwid = bannedHwids.find(h => h.hwid === hwid);

    if (bannedHwid) {
      log.backend(`[ANTICHEAT] HWID ban detected - Email: ${email}, HWID: ${hwid.substring(0, 16)}...`);

      return res.json({
        success: true,
        banned: true,
        reason: bannedHwid.reason,
        bannedAt: bannedHwid.bannedAt,
        originalUser: bannedHwid.username
      });
    }

    // Also check if user's account is banned
    if (email) {
      const user = await User.findOne({ email: email.toLowerCase() });
      if (user && user.banned) {
        return res.json({
          success: true,
          banned: true,
          reason: user.bannedReason || 'Account banned',
          bannedAt: user.bannedAt
        });
      }
    }

    res.json({
      success: true,
      banned: false
    });

  } catch (err) {
    log.error('Check HWID error:', err);
    res.status(500).json({ success: false, error: 'Failed to check HWID' });
  }
});

// Initialize banned HWIDs on startup
const bannedHwidsFile = path.join(__dirname, '../Config/banned-hwids.json');

if (!fs.existsSync(path.dirname(bannedHwidsFile))) {
  fs.mkdirSync(path.dirname(bannedHwidsFile), { recursive: true });
}

if (!fs.existsSync(bannedHwidsFile)) {
  fs.writeFileSync(bannedHwidsFile, JSON.stringify([], null, 2));
}

// Load banned HWIDs into memory
try {
  const bannedHwidsData = JSON.parse(fs.readFileSync(bannedHwidsFile, 'utf8'));
  global.bannedHwids = new Set(bannedHwidsData.map(h => h.hwid));
  log.backend(`Loaded ${bannedHwidsData.length} banned HWIDs`);
} catch (err) {
  global.bannedHwids = new Set();
  log.error('Failed to load banned HWIDs:', err);
}

module.exports = app;