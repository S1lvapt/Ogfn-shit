const express = require("express");
const app = express.Router();
const fs = require("fs");
const path = require("path");

// -----------------------------------------------------------------------------
// CONFIG � URLs apontam para IP direto, sem Cloudflare proxy
// -----------------------------------------------------------------------------
const BASE = "http://185.237.96.156:3551";

const LAUNCHER_CONFIG = {
    redirectDllUrl:  `${BASE}}/downloads/VorzaS13.dll`,
    extraDllUrls:    [],
    Client:          `${BASE}/downloads/VorzaClient.dll`,
    eorDll:          `${BASE}/downloads/EditOnRelease.dll`,
    DisablePreEdits:        `${BASE}/downloads/DisablePreEdits.dll`,
    backend:         "http://vorza.fun",
    AftermathProxy:  `${BASE}/downloads/AftermathProxy.dll`,
    VorzaSec:  `${BASE}/downloads/VorzaSec.exe`,
    VorzaPak:        `${BASE}/downloads/VorzaPak.dll`,
    Vorza:        `${BASE}/downloads/Vorza.msi`,
    useBackendParam: true
};

// -----------------------------------------------------------------------------
// GET /api/launcher/config
// -----------------------------------------------------------------------------
app.get("/api/launcher/config", (req, res) => {
    res.json({
        success: true,
        ...LAUNCHER_CONFIG
    });
});

// -----------------------------------------------------------------------------
// GET /api/launcher/paks
// -----------------------------------------------------------------------------
app.get("/api/launcher/paks", (req, res) => {
    const paksDir = path.join(__dirname, "..", "downloads", "Paks");

    try {
        if (!fs.existsSync(paksDir)) {
            return res.status(404).json({
                success: false,
                error: "Paks directory not found",
                files: []
            });
        }

        const files = fs.readdirSync(paksDir);
        const pakFiles = files
            .filter(file => file.endsWith(".pak") || file.endsWith(".sig"))
            .map(file => {
                const filePath = path.join(paksDir, file);
                const stats = fs.statSync(filePath);
                return {
                    name: file,
                    size: stats.size,
                    downloadUrl: `${BASE}/downloads/Paks/${file}`
                };
            });

        res.json({ success: true, files: pakFiles });
    } catch (error) {
        console.error("[/api/launcher/paks] Error:", error);
        res.status(500).json({ success: false, error: error.message, files: [] });
    }
});

// -----------------------------------------------------------------------------
// Fun��o auxiliar: envia ficheiro inteiro de uma vez (sem stream)
// createReadStream fechava a liga��o a meio � "bytes missing"
// res.end(buffer) garante que todos os bytes s�o enviados antes de fechar
// -----------------------------------------------------------------------------
function sendFileFull(res, filePath, fileName) {
    try {
        const buffer = fs.readFileSync(filePath);

        res.removeHeader("Content-Encoding");
        res.setHeader("Content-Encoding",    "identity");
        res.setHeader("Content-Type",        "application/octet-stream");
        res.setHeader("Content-Length",      buffer.length);
        res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
        res.setHeader("Cache-Control",       "no-store, no-transform");
        res.setHeader("Accept-Ranges",       "none");

        res.status(200).end(buffer);
    } catch (err) {
        console.error(`[sendFileFull] Error sending ${fileName}:`, err);
        if (!res.headersSent) {
            res.status(500).json({ success: false, error: "Failed to read file" });
        }
    }
}

// -----------------------------------------------------------------------------
// GET /downloads/Paks/:filename
// -----------------------------------------------------------------------------
app.get("/downloads/Paks/:filename", (req, res) => {
    const safeName = path.basename(req.params.filename);
    const filePath = path.join(__dirname, "..", "downloads", "Paks", safeName);

    if (!safeName.endsWith(".pak") && !safeName.endsWith(".sig")) {
        return res.status(400).json({ success: false, error: "Only .pak and .sig files are allowed" });
    }

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ success: false, error: `File not found: ${safeName}` });
    }

    console.log(`[Paks] Sending ${safeName} (${fs.statSync(filePath).size} bytes)`);
    sendFileFull(res, filePath, safeName);
});

// -----------------------------------------------------------------------------
// GET /downloads/:filename
// DLLs e outros ficheiros
// -----------------------------------------------------------------------------
app.get("/downloads/:filename", (req, res) => {
    const safeName = path.basename(req.params.filename);
    const filePath = path.join(__dirname, "..", "downloads", safeName);

    const allowed = [".dll", ".exe", ".zip"];
    const ext = path.extname(safeName).toLowerCase();
    if (!allowed.includes(ext)) {
        return res.status(400).json({ success: false, error: "File type not allowed" });
    }

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ success: false, error: `File not found: ${safeName}` });
    }

    console.log(`[Downloads] Sending ${safeName} (${fs.statSync(filePath).size} bytes)`);
    sendFileFull(res, filePath, safeName);
});

module.exports = app;
