const express = require('express');
const app = express.Router();
const axios = require('axios');
const functions = require('../structs/functions.js');
const User = require('../model/user.js');
const Profile = require('../model/profiles.js');
const log = require('../structs/log.js');
const config = require('../Config');

let pendingSession = null;
global.launcherSessions = global.launcherSessions || {};

function authErrorPage(errorMsg) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Vorza - Auth Error</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0a0e27 0%,#1a1a2e 50%,#16213e 100%);font-family:'Segoe UI',Roboto,Ubuntu,sans-serif;color:#fff;overflow:hidden}
body::before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse at 30% 20%,rgba(103,202,245,0.06) 0%,transparent 60%),radial-gradient(ellipse at 70% 80%,rgba(103,202,245,0.04) 0%,transparent 60%);pointer-events:none}
.card{position:relative;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:20px;padding:56px 44px;text-align:center;max-width:440px;width:90%;backdrop-filter:blur(40px);-webkit-backdrop-filter:blur(40px);box-shadow:0 8px 32px rgba(0,0,0,0.4);transition:transform .3s cubic-bezier(.4,0,.2,1),box-shadow .3s}
.card:hover{transform:translateY(-4px);box-shadow:0 16px 48px rgba(0,0,0,0.5);border-color:rgba(255,77,77,0.15)}
.icon{width:72px;height:72px;margin:0 auto 28px;background:rgba(255,77,77,0.08);border:1px solid rgba(255,77,77,0.15);border-radius:50%;display:flex;align-items:center;justify-content:center}
.icon svg{width:36px;height:36px}
h1{font-size:24px;font-weight:600;margin-bottom:10px;color:#fff;letter-spacing:-0.3px}
.subtitle{font-size:14px;color:rgba(255,255,255,0.45);margin-bottom:28px;line-height:1.6}
.error-detail{background:rgba(255,77,77,0.06);border:1px solid rgba(255,77,77,0.12);border-radius:12px;padding:14px 18px;font-size:13px;color:#ff6b6b;margin-bottom:28px;word-break:break-word;font-weight:500;letter-spacing:0.2px}
.btn{display:inline-block;padding:13px 36px;background:rgba(103,202,245,0.12);color:#67CAF5;font-weight:600;font-size:14px;border-radius:12px;text-decoration:none;border:1px solid rgba(103,202,245,0.2);transition:all .3s cubic-bezier(.4,0,.2,1);letter-spacing:0.3px}
.btn:hover{background:rgba(103,202,245,0.2);border-color:rgba(103,202,245,0.35);transform:translateY(-2px);box-shadow:0 4px 16px rgba(103,202,245,0.15)}
.divider{width:48px;height:2px;background:linear-gradient(90deg,transparent,rgba(255,77,77,0.3),transparent);margin:0 auto 28px;border-radius:2px}
</style></head><body>
<div class="card">
<div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="#ff4d4d" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg></div>
<h1>Authentication Failed</h1>
<p class="subtitle">Something went wrong during Discord authentication</p>
<div class="divider"></div>
<div class="error-detail">${errorMsg}</div>
<a class="btn" href="/api/auth/discord">Try Again</a>
</div></body></html>`;
}

setInterval(() => {
  if (pendingSession && (Date.now() - pendingSession.createdAt) > 60000) {
    pendingSession = null;
  }
}, 30000);

app.get('/api/auth/discord', (req, res) => {
  try {
    const redirectUri = config.discord.redirectUri;
    const authURL = `https://discord.com/api/oauth2/authorize?client_id=${config.discord.clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=identify`;
    res.redirect(authURL);
  } catch (err) {
    res.status(500).send(authErrorPage('Failed to start OAuth'));
  }
});

app.get('/api/auth/discord/callback', async (req, res) => {
  const code = req.query.code;

  if (req.query.error) {
    return res.status(400).send(authErrorPage(req.query.error_description || req.query.error || 'Access denied'));
  }

  if (!code) {
    return res.status(400).json({ success: false, error: 'No authorization code' });
  }

  try {
    const tokenResp = await axios.post(
      'https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: config.discord.clientId,
        client_secret: config.discord.clientSecret,
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: config.discord.redirectUri
      }).toString(),
      {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 10000
      }
    );

    const userResp = await axios.get('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${tokenResp.data.access_token}` },
      timeout: 10000
    });
    const discordUser = userResp.data;

    const discordAvatarUrl = discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      : `https://cdn.discordapp.com/embed/avatars/${(BigInt(discordUser.id) >> 22n) % 6n}.png`;

    let user = await User.findOne({ discordId: discordUser.id }).lean();

    if (!user) {
      let baseUsername = (discordUser.username || `user${discordUser.id}`).toString().replace(/[^\w\-\s]/g, '').slice(0, 24);
      if (baseUsername.length < 3) baseUsername = `user${discordUser.id}`;

      let usernameCandidate = baseUsername;
      let idx = 0;
      while (await User.findOne({ username: usernameCandidate })) {
        idx++;
        usernameCandidate = `${baseUsername}${idx}`.slice(0, 24);
        if (idx > 99) break;
      }

      const email = `${discordUser.id}@vorza.local`;
      const generatedPassword = functions.MakeID().replace(/-/ig, '').slice(0, 12);

      await functions.registerUser(discordUser.id, usernameCandidate, email, generatedPassword, true);
      user = await User.findOne({ discordId: discordUser.id }).lean();

      if (!user) throw new Error('User creation failed');
    }

    await User.updateOne(
      { discordId: discordUser.id },
      {
        $set: {
          discordUsername: discordUser.username,
          discordAvatar: discordAvatarUrl,
          discordAvatarDecorationData: discordUser.avatar_decoration_data || null,
          avatarDecoration: (discordUser.avatar_decoration_data?.asset) || null,
          discordProfilePicture: discordAvatarUrl
        }
      }
    );
    user = await User.findOne({ discordId: discordUser.id }).lean();

    if (!user.externalPassword) {
      const pwd = functions.MakeID().replace(/-/ig, '').slice(0, 12);
      await User.updateOne({ discordId: discordUser.id }, { $set: { externalPassword: pwd } });
      user.externalPassword = pwd;
    }

    // NOTE: vbucks are the source of truth in user.vbucks - do NOT sync from Profile on login
    // as that would overwrite vbucks earned in-game or via launcher rewards

    const sessionID = functions.MakeID().replace(/-/ig, '');
    user.avatar = user.discordAvatar || user.discordProfilePicture || null;

    pendingSession = { sessionID, user, createdAt: Date.now() };
    global.launcherSessions[sessionID] = { user, createdAt: Date.now() };

    res.cookie('connect.sid', sessionID, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    return res.redirect('http://localhost:3333/callback');

  } catch (err) {
    return res.status(500).send(authErrorPage(err.message || 'Authentication failed'));
  }
});

app.get('/api/auth/get-session', async (req, res) => {
  if (!pendingSession) {
    return res.json({ success: false, error: 'No pending session' });
  }

  const sessionAge = Date.now() - pendingSession.createdAt;
  if (sessionAge > 60000) {
    pendingSession = null;
    return res.json({ success: false, error: 'Session expired' });
  }

  try {
    const user = await User.findOne({ _id: pendingSession.user._id }).lean();

    if (!user) {
      pendingSession = null;
      return res.json({ success: false, error: 'User not found' });
    }

    const response = {
      success: true,
      sessionID: pendingSession.sessionID,
      user: { ...user, avatar: user.discordAvatar || user.discordProfilePicture || null }
    };

    pendingSession = null;
    return res.json(response);

  } catch (err) {
    pendingSession = null;
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/auth/verify', (req, res) => {
  const cookieHeader = req.headers.cookie || '';
  const match = cookieHeader.match(/connect\.sid=([^;]+)/);
  const sessionID = match && match[1];

  if (!sessionID) {
    return res.status(401).json({ authenticated: false, error: 'No session cookie' });
  }

  const sessionObj = global.launcherSessions[sessionID];

  if (!sessionObj) {
    return res.status(401).json({ authenticated: false, error: 'Invalid session' });
  }

  return res.json({
    authenticated: true,
    accountId: sessionObj.user.accountId,
    displayName: sessionObj.user.username
  });
});

module.exports = app;