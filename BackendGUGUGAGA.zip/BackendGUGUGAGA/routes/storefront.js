const express = require("express");
const app = express.Router();
const crypto = require("crypto");
const Profile = require("../model/profiles.js");
const Friends = require("../model/friends.js");
const functions = require("../structs/functions.js");
const log = require("../structs/log.js");
const error = require("../structs/error.js");

const { verifyToken, verifyClient } = require("../tokenManager/tokenVerify.js");
const keychain = require("../responses/keychain.json");

app.get("/fortnite/api/storefront/v2/catalog", (req, res) => {
    log.debug("Request to /fortnite/api/storefront/v2/catalog");
    
    try {
        const catalog = functions.getItemShop();
        
        // Validate catalog response
        if (!catalog || !catalog.storefronts || !Array.isArray(catalog.storefronts)) {
            log.error("[Storefront] Invalid catalog response - missing storefronts");
            return res.status(500).json({ 
                error: "Invalid catalog response",
                storefronts: [] 
            });
        }
        
        // Set cache headers to prevent stale cache issues
        // Use no-cache to force revalidation, but allow short-term caching
        res.setHeader('Cache-Control', 'no-cache, must-revalidate, max-age=0');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        
        // Add ETag for cache validation (based on catalog content hash)
        const catalogHash = crypto
            .createHash('md5')
            .update(JSON.stringify(catalog))
            .digest('hex');
        res.setHeader('ETag', `"${catalogHash}"`);
        
        // Check if client has cached version
        const clientETag = req.headers['if-none-match'];
        if (clientETag === `"${catalogHash}"`) {
            return res.status(304).end(); // Not Modified
        }
        
        log.debug(`[Storefront] Returning catalog with ${catalog.storefronts.length} storefronts`);
        res.json(catalog);
    } catch (error) {
        log.error("[Storefront] Error generating catalog:", error);
        res.setHeader('Cache-Control', 'no-cache, must-revalidate, max-age=0');
        res.status(500).json({ 
            error: "Failed to generate catalog",
            storefronts: [] 
        });
    }
});

app.get("/fortnite/api/storefront/v2/gift/check_eligibility/recipient/:recipientId/offer/:offerId", verifyToken, async (req, res) => {
    log.debug(`Request to /fortnite/api/storefront/v2/gift/check_eligibility/recipient/${req.params.recipientId}/offer/${req.params.offerId}`);
    const findOfferId = functions.getOfferID(req.params.offerId);
    if (!findOfferId) return error.createError(
        "errors.com.epicgames.fortnite.id_invalid",
        `Offer ID (id: "${req.params.offerId}") not found`,
        [req.params.offerId], 16027, undefined, 400, res
    );

    let sender = await Friends.findOne({ accountId: req.user.accountId }).lean();

    if (!sender.list.accepted.find(i => i.accountId == req.params.recipientId) && req.params.recipientId != req.user.accountId) return error.createError(
        "errors.com.epicgames.friends.no_relationship",
        `User ${req.user.accountId} is not friends with ${req.params.recipientId}`,
        [req.user.accountId, req.params.recipientId], 28004, undefined, 403, res
    );

    const profiles = await Profile.findOne({ accountId: req.params.recipientId });

    let athena = profiles.profiles["athena"];

    for (let itemGrant of findOfferId.offerId.itemGrants) {
        for (let itemId in athena.items) {
            if (itemGrant.templateId.toLowerCase() == athena.items[itemId].templateId.toLowerCase()) return error.createError(
                "errors.com.epicgames.modules.gamesubcatalog.purchase_not_allowed",
                `Could not purchase catalog offer ${findOfferId.offerId.devName}, item ${itemGrant.templateId}`,
                [findOfferId.offerId.devName, itemGrant.templateId], 28004, undefined, 403, res
            );
        }
    }

    res.json({
        price: findOfferId.offerId.prices[0],
        items: findOfferId.offerId.itemGrants
    });
});

app.get("/fortnite/api/storefront/v2/keychain", (req, res) => {
    log.debug("Request to /fortnite/api/storefront/v2/keychain");
    res.json(keychain);
});

app.get("/catalog/api/shared/bulk/offers", (req, res) => {
    log.debug("Request to /catalog/api/shared/bulk/offers");
    res.json({});
});

module.exports = app;