const express = require("express");
const app = express.Router();
const User = require("../model/user.js");
const UserStats = require("../model/userstats.js");
const { verifyToken, verifyClient } = require("../tokenManager/tokenVerify.js");
const functions = require("../structs/functions.js");
const log = require("../structs/log.js");

app.get("/*/api/statsv2/leaderboards/:leaderboardName", async (req, res) => {
    log.debug(`GET /*/api/statsv2/leaderboards/${req.params.leaderboardName} called`);
    try {
        const playlist = req.params.leaderboardName.split("playlist_default")[1];
        const typeStat = req.params.leaderboardName.split("_keyboardmouse")[0].split("br_")[1];
        const stats = await UserStats.find({});
        if (!stats) return res.status(404).end();
        const clientsStats = [];
        const finalStats = [];
        let maxSize = 100;

        if (req.query.maxSize) {
            if (req.query.maxSize <= 150 && req.query.maxSize > 0) {
                maxSize = Number(req.query.maxSize);
            } else {
                return res.json({
                    error: "minSize: 1 / maxSize: 100"
                });
            }
        }

        for (var stat of stats) {
            const findUser = await User.findOne({ accountId: stat.accountId });
            if (!findUser) continue;
            // Ignora contas host
            if (findUser.isServer === true) continue;
            // Ignora users que n�o querem aparecer na leaderboard
            if (findUser.showInLeaderboard !== true) continue;
            
            const value = (stat[playlist] && stat[playlist][typeStat]) ? stat[playlist][typeStat] : 0;
            
            clientsStats.push({
                displayName: findUser.username,
                account: findUser.accountId,
                value: value
            });
        }

        clientsStats.sort((a, b) => b.value - a.value);

        for (var finalStat of clientsStats) {
            if (finalStats.length >= maxSize) continue;

            finalStats.push({
                displayName: finalStat.displayName,
                account: finalStat.account,
                value: finalStat.value
            });
        }

        res.json({
            maxSize: maxSize,
            entries: finalStats
        });
    } catch (err) {
        log.error("Error in leaderboards endpoint:", err);
        res.json({
            error: "stat not found"
        });
    }
});

app.post("/fortnite/api/leaderboards/type/global/stat/:leaderboardName/window/:typeLeaderboard", async (req, res) => {
    log.debug(`POST /fortnite/api/leaderboards/type/global/stat/${req.params.leaderboardName}/window/${req.params.typeLeaderboard} called`)
    try {
        const playlist = functions.PlaylistNames(req.params.leaderboardName.split("m0_p")[1]).toLowerCase().replace("playlist_default", "");
        const typeStat = req.params.leaderboardName.split("_pc")[0].split("br_")[1];
        const stats = await UserStats.find({});
        if (!stats) return res.status(404).end();
        const entries = [];

        for (var stat of stats) {
            const user = await User.findOne({ accountId: stat.accountId });
            if (!user) continue;
            // Ignora contas host
            if (user.isServer === true) continue;
            // Ignora users que n�o querem aparecer na leaderboard
            if (user.showInLeaderboard !== true) continue;

            const value = (stat[playlist] && stat[playlist][typeStat]) ? stat[playlist][typeStat] : 0;

            entries.push({
                accountId: user.accountId,
                displayName: user.username,
                rank: 1,
                value: value
            });
        }

        entries.sort((a, b) => b.value - a.value);
        entries.forEach((entry, index) => entry.rank = index + 1);

        res.json({
            statName: req.params.leaderboardName,
            statWindow: req.params.typeLeaderboard,
            entries: entries
        });
    } catch (err) {
        log.error("Error in global leaderboard:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.post("/*/api/statsv2/query", verifyToken, async (req, res) => {
    log.debug(`POST /*/api/statsv2/query called`);
    try {
        if (!req.body.stats) return res.status(400).end();
        const statKey = req.body.stats[0];
        const playlist = statKey.split("playlist_default")[1];
        const typeStat = statKey.split("_keyboardmouse")[0].split("br_")[1];
        const stats = await UserStats.find({});
        if (!stats) return res.status(404).end();
        const clientsStats = [];

        for (var owner of req.body.owners) {
            const individualStat = await UserStats.findOne({ accountId: owner });
            if (!individualStat) continue;
            if (!individualStat[playlist]) continue;
            if (individualStat[playlist][typeStat] == undefined) continue;

            clientsStats.push({
                accountId: individualStat.accountId,
                endTime: req.body.endTime || 0,
                startTime: req.body.startTime || 0,
                stats: {
                    [statKey]: individualStat[playlist][typeStat] || 0
                }
            });
        }

        res.json(clientsStats);
    } catch (err) {
        log.error("Error in stats query:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.get("/fortnite/api/game/v2/leaderboards/cohort/:accountId", verifyToken, async (req, res) => {
    log.debug(`GET /fortnite/api/game/v2/leaderboards/cohort/${req.params.accountId} called`);
    res.json({});
});

app.get("/fortnite/api/stats/accountId/:accountId/bulk/window/:windowType", verifyToken, async (req, res) => {
    try {
        const stats = await UserStats.findOne({ "accountId": req.params.accountId });
        
        if (!stats) {
            return res.json([]);
        }

        const allStats = ["solo", "duo", "squad"];
        const statsList = [];
        const allTypesStats = {
            all: ["br_kills", "br_score", "br_matchesplayed", "br_minutesplayed"],
            solo: ["br_placetop1", "br_placetop10", "br_placetop25"],
            duo: ["br_placetop1", "br_placetop5", "br_placetop12"],
            squad: ["br_placetop1", "br_placetop3", "br_placetop6"]
        }

        for (var stat of allStats) {
            if (!stats[stat]) continue;

            for (var typeStat of allTypesStats.all) {
                statsList.push({
                    name: `${typeStat}_pc_m0_p${functions.PlaylistNames(stat)}`,
                    value: stats[stat][typeStat.replace("br_", "")] || 0,
                    window: req.params.windowType,
                    ownerType: 1
                });
            }

            for (var typeStats of allTypesStats[stat]) {
                statsList.push({
                    name: `${typeStats}_pc_m0_p${functions.PlaylistNames(stat)}`,
                    value: stats[stat][typeStats.replace("br_", "")] || 0,
                    window: req.params.windowType,
                    ownerType: 1
                });
            }
        }

        res.json(statsList);
    } catch (err) {
        log.error("Error in bulk stats:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.get("/*/api/statsv2/account/:accountId", verifyToken, async (req, res) => {
    try {
        const stats = await UserStats.findOne({ accountId: req.params.accountId });

        if (!stats) {
            return res.json({
                accountId: req.params.accountId,
                endTime: 0,
                startTime: req.query.startTime || 0,
                stats: {
                    br_placetop1_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_placetop1_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_placetop1_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_placetop1_keyboardmouse_m0_playlist_solidgold_solo: 0,
                    br_placetop10_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_placetop5_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_placetop3_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_placetop25_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_placetop12_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_placetop6_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_kills_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_kills_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_kills_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_kills_keyboardmouse_m0_playlist_solidgold_solo: 0,
                    br_matchesplayed_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_matchesplayed_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_matchesplayed_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_matchesplayed_keyboardmouse_m0_playlist_solidgold_solo: 0,
                    br_minutesplayed_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_minutesplayed_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_minutesplayed_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_minutesplayed_keyboardmouse_m0_playlist_solidgold_solo: 0,
                    br_playersoutlived_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_playersoutlived_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_playersoutlived_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_playersoutlived_keyboardmouse_m0_playlist_solidgold_solo: 0,
                    br_score_keyboardmouse_m0_playlist_defaultsolo: 0,
                    br_score_keyboardmouse_m0_playlist_defaultduo: 0,
                    br_score_keyboardmouse_m0_playlist_defaultsquad: 0,
                    br_score_keyboardmouse_m0_playlist_solidgold_solo: 0
                }
            });
        }

        const solo = stats.solo || {};
        const duo = stats.duo || {};
        const squad = stats.squad || {};
        const ltm = stats.ltm || {};

        res.json({
            accountId: req.params.accountId,
            endTime: 0,
            startTime: req.query.startTime || 0,
            stats: {
                br_placetop1_keyboardmouse_m0_playlist_defaultsolo: solo.placetop1 || 0,
                br_placetop1_keyboardmouse_m0_playlist_defaultduo: duo.placetop1 || 0,
                br_placetop1_keyboardmouse_m0_playlist_defaultsquad: squad.placetop1 || 0,
                br_placetop1_keyboardmouse_m0_playlist_solidgold_solo: ltm.wins || 0,
                br_placetop10_keyboardmouse_m0_playlist_defaultsolo: solo.placetop10 || 0,
                br_placetop5_keyboardmouse_m0_playlist_defaultduo: duo.placetop5 || 0,
                br_placetop3_keyboardmouse_m0_playlist_defaultsquad: squad.placetop3 || 0,
                br_placetop25_keyboardmouse_m0_playlist_defaultsolo: solo.placetop25 || 0,
                br_placetop12_keyboardmouse_m0_playlist_defaultduo: duo.placetop12 || 0,
                br_placetop6_keyboardmouse_m0_playlist_defaultsquad: squad.placetop6 || 0,
                br_kills_keyboardmouse_m0_playlist_defaultsolo: solo.kills || 0,
                br_kills_keyboardmouse_m0_playlist_defaultduo: duo.kills || 0,
                br_kills_keyboardmouse_m0_playlist_defaultsquad: squad.kills || 0,
                br_kills_keyboardmouse_m0_playlist_solidgold_solo: ltm.kills || 0,
                br_matchesplayed_keyboardmouse_m0_playlist_defaultsolo: solo.matchesplayed || 0,
                br_matchesplayed_keyboardmouse_m0_playlist_defaultduo: duo.matchesplayed || 0,
                br_matchesplayed_keyboardmouse_m0_playlist_defaultsquad: squad.matchesplayed || 0,
                br_matchesplayed_keyboardmouse_m0_playlist_solidgold_solo: ltm.matchesplayed || 0,
                br_minutesplayed_keyboardmouse_m0_playlist_defaultsolo: solo.minutesplayed || 0,
                br_minutesplayed_keyboardmouse_m0_playlist_defaultduo: duo.minutesplayed || 0,
                br_minutesplayed_keyboardmouse_m0_playlist_defaultsquad: squad.minutesplayed || 0,
                br_minutesplayed_keyboardmouse_m0_playlist_solidgold_solo: ltm.minutesplayed || 0,
                br_playersoutlived_keyboardmouse_m0_playlist_defaultsolo: solo.playersoutlived || 0,
                br_playersoutlived_keyboardmouse_m0_playlist_defaultduo: duo.playersoutlived || 0,
                br_playersoutlived_keyboardmouse_m0_playlist_defaultsquad: squad.playersoutlived || 0,
                br_playersoutlived_keyboardmouse_m0_playlist_solidgold_solo: ltm.playersoutlived || 0,
                br_score_keyboardmouse_m0_playlist_defaultsolo: solo.score || 0,
                br_score_keyboardmouse_m0_playlist_defaultduo: duo.score || 0,
                br_score_keyboardmouse_m0_playlist_defaultsquad: squad.score || 0,
                br_score_keyboardmouse_m0_playlist_solidgold_solo: ltm.score || 0
            }
        });
    } catch (err) {
        log.error("Error in account stats:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});

module.exports = app;