const express = require("express");
const app = express.Router();
const path = require("path");
const axios = require("axios");
const functions = require("../structs/functions.js");
const log = require("../structs/log.js");

// Serve the shop interface HTML
app.get("/", (req, res) => {
    log.debug("Serving shop UI");
    res.sendFile(path.join(__dirname, "..", "Website", "Data", "html", "shop.html"));
});

// Cache for Fortnite API cosmetic lookups (itemId -> { name, icon })
const cosmeticCache = new Map();
const CACHE_TTL = 3600000; // 1 hour

async function fetchCosmeticInfo(itemId) {
    if (!itemId) return null;

    // Check cache
    const cached = cosmeticCache.get(itemId);
    if (cached && (Date.now() - cached.timestamp < CACHE_TTL)) {
        return cached.data;
    }

    try {
        const resp = await axios.get(`https://fortnite-api.com/v2/cosmetics/br/${encodeURIComponent(itemId)}`, { timeout: 5000 });
        const data = resp.data && resp.data.data;
        if (data) {
            const result = {
                name: data.name || null,
                icon: (data.images && (data.images.smallIcon || data.images.icon)) || null
            };
            cosmeticCache.set(itemId, { data: result, timestamp: Date.now() });
            return result;
        }
    } catch (e) {
        // ignore
    }

    return null;
}

// API endpoint to get shop data in a simplified format
app.get("/api/shop/items", async (req, res) => {
    try {
        const catalog = functions.getItemShop();

        const shopData = {
            featured: [],
            daily: []
        };

        if (catalog && catalog.storefronts) {
            async function mapEntry(entry, defaultTileSize) {
                const firstItem = entry.itemGrants && entry.itemGrants.length > 0 ? entry.itemGrants[0].templateId : null;
                const itemId = firstItem ? firstItem.split(':')[1] : null;

                // Fetch real name and image from Fortnite API
                let name = null;
                let imageUrl = null;

                if (itemId) {
                    const info = await fetchCosmeticInfo(itemId);
                    if (info) {
                        name = info.name;
                        imageUrl = info.icon;
                    }
                }

                // Fallback image
                if (!imageUrl && itemId) {
                    imageUrl = `https://fortnite-api.com/images/cosmetics/br/${itemId}/icon.png`;
                }

                // Fallback name from devName
                if (!name) {
                    name = entry.devName || "Unknown Item";
                }

                return {
                    name,
                    price: entry.prices[0]?.finalPrice || 0,
                    items: entry.itemGrants.map(grant => grant.templateId),
                    offerId: entry.offerId,
                    tileSize: entry.meta?.TileSize || defaultTileSize,
                    imageUrl
                };
            }

            // Process Featured items
            const featured = catalog.storefronts.find(s => s.name === "BRWeeklyStorefront");
            if (featured && featured.catalogEntries) {
                shopData.featured = await Promise.all(
                    featured.catalogEntries.map(entry => mapEntry(entry, "Normal"))
                );
            }

            // Process Daily items
            const daily = catalog.storefronts.find(s => s.name === "BRDailyStorefront");
            if (daily && daily.catalogEntries) {
                shopData.daily = await Promise.all(
                    daily.catalogEntries.map(entry => mapEntry(entry, "Small"))
                );
            }
        }

        res.json(shopData);
    } catch (error) {
        console.error("Error fetching shop data:", error);
        res.status(500).json({ error: "Failed to load shop data" });
    }
});

// Serve static files for shop UI
app.use("/shop-assets", express.static(path.join(__dirname, "..", "Website", "Data")));

module.exports = app;
