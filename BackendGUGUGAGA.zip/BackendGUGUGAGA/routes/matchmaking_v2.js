/**
 * Matchmaking v2 � ticket assina um JWT com TODOS os dados necess�rios.
 * Rubidium usa jwt.sign() no ticket e jwt.verify() no matchmaker WS.
 * Aqui fazemos o mesmo: o matchmaker n�o precisa de DB para nada.
 */
const express   = require("express");
const app       = express.Router();
const jwt       = require("jsonwebtoken");
const config    = require("../Config/config.json");
const functions = require("../structs/functions.js");
const log       = require("../structs/log.js");
const error     = require("../structs/error.js");
const { verifyToken } = require("../tokenManager/tokenVerify.js");
const qs        = require("qs");

function findServer(playlist) {
    if (!Array.isArray(config.gameServers)) return null;
    let s = config.gameServers.find(s =>
        s.enabled !== false &&
        Array.isArray(s.playlists) &&
        s.playlists.some(p => p.toLowerCase() === (playlist || "").toLowerCase())
    );
    if (!s) s = config.gameServers.find(s => s.enabled !== false);
    return s || null;
}

// -- Ticket --------------------------------------------------------------------
app.get("/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId", verifyToken, async (req, res) => {
    try {
        if (req.user.isServer === true) return res.status(403).end();

        const params    = qs.parse(req.url.split("?")[1], { ignoreQueryPrefix: true });
        const bucketId  = params["bucketId"];
        const customKey = params["player.option.customKey"];

        if (typeof bucketId !== "string" || bucketId.split(":").length !== 4)
            return res.status(400).end();

        const playlist = bucketId.split(":")[3];
        const buildId  = bucketId.split(":")[0];
        const region   = bucketId.split(":")[2] || "EU";

        let server = findServer(playlist);

        // Custom match key override
        if (typeof customKey === "string") {
            try {
                const MMCode = require("../model/mmcodes.js");
                const code   = await MMCode.findOne({ code_lower: customKey.toLowerCase() });
                if (!code) {
                    return error.createError(
                        "errors.com.epicgames.common.matchmaking.code.not_found",
                        `The matchmaking code "${customKey}" was not found`,
                        [], 1013, "invalid_code", 404, res
                    );
                }
                server = { ip: code.ip, port: code.port || 7777, id: "custom" };
            } catch (e) {
                log.error("[Matchmaking] Custom key error:", e.message);
            }
        }

        // Obter membros da party do jogador (para squad MM)
        let partyMembers = req.user.accountId; // default solo = string
        try {
            const party = Object.values(global.parties || {})
                .find(p => p.members.some(m => m.account_id === req.user.accountId));
            if (party && party.members.length > 1) {
                partyMembers = party.members.map(m => m.account_id);
            }
        } catch (_) {}

        // JWT com TODOS os dados que o matchmaker precisa � como o Rubidium
        const signaturePayload = {
            accountId:     req.user.accountId,
            displayName:   req.user.username || req.user.accountId,
            playlist,
            buildId,
            region,
            bucketId,
            partyMembers,                                  // string (solo) ou array (squad)
            serverAddress: server ? server.ip       : null,
            serverPort:    server ? (server.port || 7777) : 7777,
            serverId:      server ? (server.id || server.serverId || "gs-001") : null,
            hasPriority:   !!(req.user.basicDonator || req.user.donator ||
                              req.user.mediumDonator || req.user.highDonator || req.user.ultimateDonator)
        };

        // Assinar JWT com o mesmo secret que todo o backend usa
        const signature = jwt.sign(signaturePayload, global.JWT_SECRET, { expiresIn: "10m" });

        const matchmakerIP = config.matchmakerIP || "127.0.0.1:8081";
        const serviceUrl   = (matchmakerIP.startsWith("ws://") || matchmakerIP.startsWith("wss://"))
            ? matchmakerIP
            : `ws://${matchmakerIP}`;

        log.backend(`[Matchmaking] Ticket ? ${req.user.accountId} | ${playlist} | servidor: ${server ? server.ip : "NONE"}`);

        // Rubidium devolve: payload = accountId, signature = JWT
        return res.json({
            serviceUrl,
            ticketType: "mms-player",
            payload:    req.user.accountId,
            signature:  signature
        });

    } catch (err) {
        log.error("[Matchmaking] Ticket error:", err);
        return res.status(500).json({ error: "Internal server error" });
    }
});

// -- Session -------------------------------------------------------------------
app.get("/fortnite/api/matchmaking/session/:sessionId", verifyToken, async (req, res) => {
    try {
        const raw = await global.kv.get(`playerPlaylist:${req.user.accountId}`);
        if (!raw) {
            return error.createError(
                "errors.com.epicgames.common.matchmaking.session.not_found",
                "Session not found or expired",
                [], 1014, "session_not_found", 404, res
            );
        }
        const info       = JSON.parse(raw);
        const sessionKey = functions.MakeID().replace(/-/ig, "").toUpperCase();
        await global.kv.setTTL(`sessionKey:${req.params.sessionId}`, sessionKey, 300000);
        const now = new Date().toISOString();
        return res.json({
            id:               req.params.sessionId,
            ownerId:          functions.MakeID().replace(/-/ig, "").toUpperCase(),
            ownerName:        `[DS]${info.serverId || "vorza"}`,
            serverName:       `[DS]${info.serverId || "vorza"}`,
            serverAddress:    info.ip,
            serverPort:       parseInt(info.port || 7777),
            createdDateTime:  now,
            maxPublicPlayers: 100,
            openPublicPlayers: 75,
            maxPrivatePlayers: 0,
            openPrivatePlayers: 0,
            attributes: {
                REGION_s:                  "EU",
                GAMEMODE_s:                "FORTATHENA",
                ALLOWBROADCASTING_b:       true,
                SUBREGION_s:               "ES",
                DCID_s:                    "VORZA-EUES-" + (info.serverId || "001").toUpperCase(),
                tenant_s:                  "Fortnite",
                MATCHMAKINGPOOL_s:         "Any",
                STORMSHIELDDEFENSETYPE_i:  0,
                HOTFIXVERSION_i:           0,
                PLAYLISTNAME_s:            info.playlist,
                SESSIONKEY_s:              sessionKey,
                TENANT_s:                  "Fortnite",
                BEACONPORT_i:              15009,
                AVERAGEPING_i:             15
            },
            publicPlayers:   [{ accountId: req.user.accountId, sessionId: req.params.sessionId }],
            privatePlayers:  [],
            totalPlayers:    1,
            allowJoinInProgress: true,
            shouldAdvertise: false,
            isDedicated:     true,
            usesStats:       true,
            allowInvites:    false,
            usesPresence:    false,
            allowJoinViaPresence: true,
            allowJoinViaPresenceFriendsOnly: false,
            buildUniqueId:   info.buildId || "0",
            matchQuality:    1.0,
            restrictionsPenalty: 0,
            lastUpdated:     now,
            started:         true
        });
    } catch (err) {
        log.error("[Matchmaking] Session error:", err);
        return res.status(500).json({ error: "Internal server error" });
    }
});

// -- Endpoints auxiliares ------------------------------------------------------
app.get("/fortnite/api/game/v2/matchmaking/account/:accountId/session/:sessionId", async (req, res) => {
    let key = await global.kv.get(`sessionKey:${req.params.sessionId}`);
    if (!key) { key = functions.MakeID().replace(/-/ig, "").toUpperCase(); await global.kv.setTTL(`sessionKey:${req.params.sessionId}`, key, 300000); }
    res.json({ accountId: req.params.accountId, sessionId: req.params.sessionId, key });
});

app.post("/fortnite/api/gamesession/v1/account/:accountId/token/:sessionId", async (req, res) => {
    const k = functions.MakeID().replace(/-/ig, "").toUpperCase();
    await global.kv.setTTL(`sessionToken:${req.params.sessionId}`, k, 300000);
    res.json({ token: k });
});

app.get("/fortnite/api/gamesession/v1/account/:accountId/token/:sessionId", async (req, res) => {
    const k = functions.MakeID().replace(/-/ig, "").toUpperCase();
    await global.kv.setTTL(`sessionToken:${req.params.sessionId}`, k, 300000);
    res.json({ token: k });
});

app.get("/fortnite/api/matchmaking/session/:sessionId/key",             (req, res) => res.json({ key: functions.MakeID().replace(/-/ig,"").toUpperCase() }));
app.get("/fortnite/api/game/v2/matchmaking/session/:sessionId/key",     (req, res) => res.json({ key: functions.MakeID().replace(/-/ig,"").toUpperCase() }));
app.post("/fortnite/api/matchmaking/session/:sessionId/join",           verifyToken, (req, res) => res.status(204).end());
app.post("/fortnite/api/matchmaking/session/*/join",                    (req, res) => res.status(204).end());
app.post("/fortnite/api/matchmaking/session/matchMakingRequest",        (req, res) => res.json([]));
app.get("/fortnite/api/matchmaking/session/findPlayer/*",               (req, res) => res.status(200).end());

module.exports = app;