const express = require("express");
const router = express.Router();
const User = require("../model/user");
const log = require("../structs/log");

// ===== SISTEMA DE DIVIS�ES =====
const DIVISIONS = {
    0: { name: "Open League Division I", minHype: 0 },
    1: { name: "Open League Division II", minHype: 500 },
    2: { name: "Open League Division III", minHype: 1000 },
    3: { name: "Contender League Division I", minHype: 2000 },
    4: { name: "Contender League Division II", minHype: 4000 },
    5: { name: "Contender League Division III", minHype: 6000 },
    6: { name: "Champion League", minHype: 8000 },
    7: { name: "Champion League (Elite)", minHype: 10000 }
};

// Bus fare (custo de entrada por divis�o)
const BUS_FARE = {
    0: 0,   // Open I - Free
    1: 10,  // Open II
    2: 20,  // Open III
    3: 30,  // Contender I
    4: 40,  // Contender II
    5: 50,  // Contender III
    6: 60,  // Champion
    7: 60   // Champion Elite
};

/**
 * Calcular divis�o baseado em hype points
 */
function calculateDivision(hype) {
    if (hype >= 10000) return 7;
    if (hype >= 8000) return 6;
    if (hype >= 6000) return 5;
    if (hype >= 4000) return 4;
    if (hype >= 2000) return 3;
    if (hype >= 1000) return 2;
    if (hype >= 500) return 1;
    return 0;
}

/**
 * Calcular mudan�a de hype baseado na performance
 * NOTE: Bus Fare is already deducted in /api/arena/entry, so we don't deduct it here
 */
function calculateHypeChange(kills, placement) {
    let hypeChange = 0;

    // Kill points (+20 each)
    hypeChange += kills * 20;

    // Placement points
    if (placement === 1) {
        hypeChange += 300; // Victory Royale
    } else if (placement >= 2 && placement <= 5) {
        hypeChange += 100; // Top 5
    } else if (placement >= 6 && placement <= 15) {
        hypeChange += 60; // Top 15
    } else if (placement >= 16 && placement <= 25) {
        hypeChange += 30; // Top 25
    }
    // No points for 26+

    return hypeChange;
}

/**
 * POST /api/arena/update
 * Atualizar stats de arena ap�s uma partida
 * 
 * Body:
 * {
 *   accountId: string,
 *   kills: number,
 *   placement: number,
 *   damage: number (optional),
 *   matchId: string (optional)
 * }
 */
router.post("/api/arena/update", async (req, res) => {
    try {
        const { accountId, kills, placement, damage, matchId } = req.body;

        log.backend(`[Arena Update] *** REQUEST RECEIVED *** accountId=${accountId}, kills=${kills}, placement=${placement}`);
        log.backend(`[Arena Update] Full request body: ${JSON.stringify(req.body)}`);

        // Valida��o
        if (!accountId || typeof kills !== "number" || typeof placement !== "number") {
            log.error(`[Arena Update] Validation failed: accountId=${accountId}, kills type=${typeof kills}, placement type=${typeof placement}`);
            return res.status(400).json({
                error: "Missing required fields: accountId, kills, placement"
            });
        }

        if (kills < 0 || placement < 1 || placement > 100) {
            log.error(`[Arena Update] Invalid values: kills=${kills}, placement=${placement}`);
            return res.status(400).json({
                error: "Invalid values: kills must be >= 0, placement must be 1-100"
            });
        }

        // Get user
        let user = await User.findOne({ accountId });
        if (!user) {
            log.error(`[Arena Update] User not found: ${accountId}`);
            return res.status(404).json({
                error: "User not found"
            });
        }

        const oldHype = user.hype || 0;
        const oldDivision = user.division || 0;
        
        log.backend(`[Arena Update] User found: ${accountId}, current hype=${oldHype}, division=${oldDivision}`);

        // Calcular hype change (Bus Fare already deducted at match entry)
        const hypeChange = calculateHypeChange(kills, placement);
        log.backend(`[Arena Update] Calculated hypeChange: ${hypeChange} (${kills} kills, placement ${placement})`);
        
        user.hype = (user.hype || 0) + hypeChange;

        // Prevenir hype negativo
        if (user.hype < 0) user.hype = 0;

        // Calcular nova divis�o
        const newDivision = calculateDivision(user.hype);
        user.division = newDivision;

        // Atualizar stats b�sicos
        user.kills = (user.kills || 0) + kills;
        user.matchesPlayed = (user.matchesPlayed || 0) + 1;

        const hasWon = placement === 1;
        const hasDied = placement > 1; // If not #1, player died

        if (hasWon) {
            user.wins = (user.wins || 0) + 1;
        } else if (hasDied) {
            user.deaths = (user.deaths || 0) + 1;
        }

        // Guardar user data
        await user.save();

        log.backend(`[Arena Update] *** SUCCESS *** Updated ${accountId}: ${oldHype} -> ${user.hype} hype (${hypeChange > 0 ? '+' : ''}${hypeChange}), division ${oldDivision} -> ${newDivision}`);
        log.backend(`[Arena Update] Stats: ${kills}K/${hasWon ? '1W' : hasDied ? '1D' : ''} (+${user.matchesPlayed} matches)`);

        // Response
        res.json({
            success: true,
            accountId,
            arena: {
                hype: user.hype,
                hypeChange,
                oldHype,
                division: newDivision,
                oldDivision,
                divisionName: DIVISIONS[newDivision].name,
                promoted: newDivision > oldDivision,
                demoted: newDivision < oldDivision
            },
            match: {
                kills,
                placement,
                hasWon,
                damage: damage || 0
            },
            stats: {
                totalKills: user.kills,
                totalWins: user.wins,
                totalMatches: user.matchesPlayed
            }
        });

    } catch (err) {
        log.error("[Arena] Error updating stats:", err);
        res.status(500).json({
            error: "Failed to update arena stats",
            message: err.message
        });
    }
});

/**
 * GET /api/arena/:accountId
 * Ver stats de arena de um jogador
 */
router.get("/api/arena/:accountId", async (req, res) => {
    try {
        const { accountId } = req.params;

        let user = await User.findOne({ accountId });
        if (!user) {
            return res.status(404).json({
                error: "User not found"
            });
        }

        const hype = user.hype || 0;
        const division = user.division || 0;

        res.json({
            accountId,
            hype,
            division,
            divisionName: DIVISIONS[division].name,
            busFare: BUS_FARE[division],
            nextDivision: division < 7 ? {
                division: division + 1,
                name: DIVISIONS[division + 1].name,
                hypeRequired: DIVISIONS[division + 1].minHype,
                hypeNeeded: DIVISIONS[division + 1].minHype - hype
            } : null
        });

    } catch (err) {
        log.error("[Arena] Error fetching stats:", err);
        res.status(500).json({
            error: "Failed to fetch arena stats",
            message: err.message
        });
    }
});

/**
 * GET /api/arena/leaderboard
 * Leaderboard de arena (top 100 jogadores)
 */
router.get("/api/arena/leaderboard", async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const skip = parseInt(req.query.skip) || 0;

        const users = await User.find()
            .sort({ hype: -1 })
            .limit(limit)
            .skip(skip)
            .select("accountId username discordUsername hype division")
            .lean();

        const enrichedLeaderboard = users.map((user, index) => ({
            rank: skip + index + 1,
            accountId: user.accountId,
            username: user.username || user.discordUsername || "Unknown",
            hype: user.hype || 0,
            division: user.division || 0,
            divisionName: DIVISIONS[user.division || 0].name
        }));

        res.json({
            leaderboard: enrichedLeaderboard,
            total: await User.countDocuments()
        });

    } catch (err) {
        log.error("[Arena] Error fetching leaderboard:", err);
        res.status(500).json({
            error: "Failed to fetch leaderboard",
            message: err.message
        });
    }
});

/**
 * POST /api/arena/reset/:accountId
 * Reset arena stats (admin only)
 */
router.post("/api/arena/reset/:accountId", async (req, res) => {
    try {
        const { accountId } = req.params;

        // TODO: Adicionar verifica��o de admin aqui
        // if (!req.user.isAdmin) return res.status(403).json({ error: "Unauthorized" });

        await User.updateOne(
            { accountId },
            { $set: { hype: 0, division: 0 } }
        );

        log.debug(`[Arena] Reset stats for ${accountId}`);

        res.json({
            success: true,
            message: "Arena stats reset successfully",
            accountId
        });

    } catch (err) {
        log.error("[Arena] Error resetting stats:", err);
        res.status(500).json({
            error: "Failed to reset arena stats",
            message: err.message
        });
    }
});

/**
 * POST /api/arena/entry
 * Descontar Bus Fare quando jogador entra na partida
 *
 * Body:
 * {
 *   accountId: string
 * }
 */
router.post("/api/arena/entry", async (req, res) => {
    try {
        const { accountId } = req.body;

        log.backend(`[Arena Entry] *** BUS FARE REQUEST *** accountId=${accountId}`);

        if (!accountId) {
            return res.status(400).json({
                error: "Missing accountId"
            });
        }

        let user = await User.findOne({ accountId });
        if (!user) {
            return res.status(404).json({
                error: "User not found"
            });
        }

        const currentDivision = user.division || 0;
        const busFare = BUS_FARE[currentDivision] || 0;

        const oldHype = user.hype || 0;

        // Descontar Bus Fare
        user.hype = Math.max(0, (user.hype || 0) - busFare);

        // Recalcular divis�o (pode descer se ficou sem hype)
        const newDivision = calculateDivision(user.hype);
        user.division = newDivision;

        await user.save();

        log.debug(`[Arena Entry] ${accountId}: Paid bus fare -${busFare} hype (${oldHype} -> ${user.hype}), Division: ${DIVISIONS[currentDivision].name}`);

        res.json({
            success: true,
            accountId,
            busFare,
            oldHype,
            newHype: user.hype,
            division: newDivision,
            divisionName: DIVISIONS[newDivision].name
        });

    } catch (err) {
        log.error("[Arena Entry] Error charging bus fare:", err);
        res.status(500).json({
            error: "Failed to charge bus fare",
            message: err.message
        });
    }
});

module.exports = router;