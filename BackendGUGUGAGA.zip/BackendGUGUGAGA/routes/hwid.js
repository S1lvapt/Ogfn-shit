const express = require("express");
const router = express.Router();
const HWIDBan = require("../model/hwidbans.js");
const User = require("../model/user.js");
const log = require("../structs/log.js");

/**
 * Endpoint para launcher verificar se HWID está banido
 * GET /api/hwid/check?hwid=...
 */
router.get("/api/hwid/check", async (req, res) => {
    try {
        const { hwid } = req.query;

        if (!hwid || hwid.trim() === "") {
            return res.status(400).json({
                error: "Missing HWID parameter",
                banned: false
            });
        }

        // Verificar se HWID está banido
        const ban = await HWIDBan.findOne({ hwid: hwid.trim() });

        if (!ban) {
            return res.json({
                banned: false,
                message: "HWID not banned"
            });
        }

        // Verificar se ban expirou (se não for permanente)
        if (!ban.isPermanent && ban.expiresAt && new Date() > ban.expiresAt) {
            // Ban expirou - remover
            await HWIDBan.deleteOne({ _id: ban._id });
            log.backend(`[HWID] Ban expired and removed for HWID: ${hwid.substring(0, 8)}...`);

            return res.json({
                banned: false,
                message: "Ban has expired"
            });
        }

        // HWID está banido
        log.backend(`[HWID] Blocked login attempt from banned HWID: ${hwid.substring(0, 8)}...`);

        return res.json({
            banned: true,
            reason: ban.reason,
            bannedAt: ban.bannedAt,
            isPermanent: ban.isPermanent,
            expiresAt: ban.expiresAt,
            message: ban.isPermanent
                ? `Your hardware is permanently banned. Reason: ${ban.reason}`
                : `Your hardware is temporarily banned until ${ban.expiresAt}. Reason: ${ban.reason}`
        });

    } catch (error) {
        log.error("[HWID] Error checking HWID ban:", error.message);
        return res.status(500).json({
            error: "Internal server error",
            banned: false
        });
    }
});

/**
 * Endpoint para banir um HWID (admin only)
 * POST /api/hwid/ban
 */
router.post("/api/hwid/ban", async (req, res) => {
    try {
        const { hwid, accountId, reason, bannedBy, duration } = req.body;

        if (!hwid || hwid.trim() === "") {
            return res.status(400).json({ error: "HWID is required" });
        }

        if (!accountId || accountId.trim() === "") {
            return res.status(400).json({ error: "Account ID is required" });
        }

        // Buscar username
        const user = await User.findOne({ accountId });
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        // Verificar se já está banido
        const existing = await HWIDBan.findOne({ hwid: hwid.trim() });
        if (existing) {
            return res.status(409).json({
                error: "HWID already banned",
                ban: existing
            });
        }

        // Calcular expiração
        let expiresAt = null;
        let isPermanent = true;

        if (duration && duration > 0) {
            // Temporary ban (duration em dias)
            isPermanent = false;
            expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + duration);
        }

        // Criar ban
        const ban = await HWIDBan.create({
            hwid: hwid.trim(),
            accountId,
            username: user.username,
            reason: reason || "No reason provided",
            bannedBy: bannedBy || "System",
            isPermanent,
            expiresAt,
            bannedAt: new Date()
        });

        log.backend(`[HWID] Banned HWID ${hwid.substring(0, 8)}... for user ${user.username} (${accountId})`);

        return res.json({
            success: true,
            message: "HWID banned successfully",
            ban
        });

    } catch (error) {
        log.error("[HWID] Error banning HWID:", error.message);
        return res.status(500).json({ error: "Internal server error" });
    }
});

/**
 * Endpoint para desbanir um HWID (admin only)
 * DELETE /api/hwid/unban
 */
router.delete("/api/hwid/unban", async (req, res) => {
    try {
        const { hwid } = req.body;

        if (!hwid || hwid.trim() === "") {
            return res.status(400).json({ error: "HWID is required" });
        }

        const ban = await HWIDBan.findOneAndDelete({ hwid: hwid.trim() });

        if (!ban) {
            return res.status(404).json({ error: "HWID not found in ban list" });
        }

        log.backend(`[HWID] Unbanned HWID ${hwid.substring(0, 8)}... (was banned for: ${ban.reason})`);

        return res.json({
            success: true,
            message: "HWID unbanned successfully",
            ban
        });

    } catch (error) {
        log.error("[HWID] Error unbanning HWID:", error.message);
        return res.status(500).json({ error: "Internal server error" });
    }
});

/**
 * Endpoint para listar todos os HWIDs banidos (admin only)
 * GET /api/hwid/list
 */
router.get("/api/hwid/list", async (req, res) => {
    try {
        const bans = await HWIDBan.find().sort({ bannedAt: -1 });

        return res.json({
            success: true,
            count: bans.length,
            bans: bans.map(ban => ({
                hwid: ban.hwid.substring(0, 8) + "...", // Ofuscar HWID parcialmente
                username: ban.username,
                accountId: ban.accountId,
                reason: ban.reason,
                bannedBy: ban.bannedBy,
                bannedAt: ban.bannedAt,
                isPermanent: ban.isPermanent,
                expiresAt: ban.expiresAt
            }))
        });

    } catch (error) {
        log.error("[HWID] Error listing bans:", error.message);
        return res.status(500).json({ error: "Internal server error" });
    }
});

/**
 * Middleware para verificar HWID em login
 * Adiciona HWID ao banco de dados do usuário
 */
router.post("/api/hwid/register", async (req, res) => {
    try {
        const { accountId, hwid } = req.body;

        if (!accountId || !hwid) {
            return res.status(400).json({ error: "Missing parameters" });
        }

        // Atualizar HWID do usuário
        const user = await User.findOne({ accountId });
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        // Adicionar HWID ao histórico do usuário
        if (!user.hwidHistory) {
            user.hwidHistory = [];
        }

        // Adicionar apenas se for novo
        if (!user.hwidHistory.includes(hwid)) {
            user.hwidHistory.push(hwid);
            user.currentHWID = hwid;
            user.lastHWIDUpdate = new Date();
            await user.save();

            log.backend(`[HWID] Registered new HWID for ${user.username}: ${hwid.substring(0, 8)}...`);
        }

        return res.json({
            success: true,
            message: "HWID registered"
        });

    } catch (error) {
        log.error("[HWID] Error registering HWID:", error.message);
        return res.status(500).json({ error: "Internal server error" });
    }
});

module.exports = router;
