/**
 * Playlist Information API
 * Serves custom playlist display data to the client
 */

const express = require("express");
const app = express.Router();
const playlistDisplay = require("../structs/playlistDisplay.js");
const log = require("../structs/log.js");

/**
 * Get all available playlists with display information
 */
app.get("/fortnite/api/game/v2/br-inventory/playlists", (req, res) => {
    log.debug("GET /fortnite/api/game/v2/br-inventory/playlists called");

    const language = req.query.language || req.headers['accept-language']?.split(',')[0]?.split('-')[0] || 'en';

    const playlists = playlistDisplay.getAllPlaylists(language);

    res.json({
        playlists: Object.entries(playlists).map(([name, data]) => ({
            playlistName: name,
            ...data
        })),
        totalPlaylists: Object.keys(playlists).length,
        language: language
    });
});

/**
 * Get specific playlist information
 */
app.get("/fortnite/api/game/v2/br-inventory/playlist/:playlistId", (req, res) => {
    log.debug(`GET /fortnite/api/game/v2/br-inventory/playlist/${req.params.playlistId} called`);

    const language = req.query.language || req.headers['accept-language']?.split(',')[0]?.split('-')[0] || 'en';
    const playlistName = req.params.playlistId;

    const playlistInfo = playlistDisplay.formatForAPI(playlistName, language);

    res.json(playlistInfo);
});

/**
 * Get playlist rules and tips
 */
app.get("/fortnite/api/game/v2/br-inventory/playlist/:playlistId/rules", (req, res) => {
    log.debug(`GET /fortnite/api/game/v2/br-inventory/playlist/${req.params.playlistId}/rules called`);

    const language = req.query.language || req.headers['accept-language']?.split(',')[0]?.split('-')[0] || 'en';
    const playlistName = req.params.playlistId;

    const display = playlistDisplay.getPlaylistDisplay(playlistName, language);

    res.json({
        playlistName: playlistName,
        rules: display.rules || { displayRules: [], tips: [] }
    });
});

/**
 * Get Arena divisions and rewards
 */
app.get("/fortnite/api/game/v2/br-inventory/arena/divisions", (req, res) => {
    log.debug("GET /fortnite/api/game/v2/br-inventory/arena/divisions called");

    // Load from playlist_display.json
    const arenaPlaylist = playlistDisplay.getPlaylistDisplay('Playlist_ShowdownAlt_Solo');

    res.json({
        divisions: arenaPlaylist.rewards?.arena_divisions || [
            {"name": "Open League", "hype_required": 0, "bus_fare": 0},
            {"name": "Contender League", "hype_required": 2000, "bus_fare": 20},
            {"name": "Champion League", "hype_required": 4000, "bus_fare": 30}
        ]
    });
});

module.exports = app;
