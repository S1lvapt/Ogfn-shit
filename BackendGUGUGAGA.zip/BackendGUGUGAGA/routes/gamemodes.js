const express = require("express");
const app = express.Router();
const Gamemode = require("../model/gamemodes.js");
const { verifyToken, verifyAdmin } = require("../tokenManager/tokenVerify.js");
const log = require("../structs/log.js");
const error = require("../structs/error.js");

// Cache for gamemodes list
let gamemodesCache = null;
let gamemodesCacheTime = 0;
const GAMEMODES_CACHE_TTL = 60000; // 1 minute

// Get all active gamemodes
app.get("/fortnite/api/gamemodes/public", async (req, res) => {
    try {
        // Check cache first
        if (gamemodesCache && (Date.now() - gamemodesCacheTime < GAMEMODES_CACHE_TTL)) {
            return res.json({
                status: "success",
                gamemodes: gamemodesCache
            });
        }

        const gamemodes = await Gamemode.find({
            isActive: true
        }).select('-__v -advancedSettings').sort({ createdAt: -1 }).lean();

        // Update cache
        gamemodesCache = gamemodes;
        gamemodesCacheTime = Date.now();

        res.json({
            status: "success",
            gamemodes: gamemodes
        });
    } catch (err) {
        log.error("Error fetching gamemodes:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.fetch_failed",
            "Failed to fetch gamemodes",
            [], 2001, "gamemode_error", 500, res
        );
    }
});

// Get specific gamemode details
app.get("/fortnite/api/gamemodes/:gamemodeId", verifyToken, async (req, res) => {
    try {
        const gamemode = await Gamemode.findOne({
            gamemodeId: req.params.gamemodeId,
            isActive: true
        }).lean();

        if (!gamemode) {
            return error.createError(
                "errors.com.epicgames.gamemode.not_found",
                `Gamemode ${req.params.gamemodeId} not found`,
                [], 2002, "gamemode_not_found", 404, res
            );
        }

        res.json({
            status: "success",
            gamemode: gamemode
        });
    } catch (err) {
        log.error("Error fetching gamemode:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.fetch_failed",
            "Failed to fetch gamemode",
            [], 2001, "gamemode_error", 500, res
        );
    }
});

// Admin: Get all gamemodes
app.get("/fortnite/api/admin/gamemodes/all", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const gamemodes = await Gamemode.find({}).sort({ createdAt: -1 });
        res.json({
            status: "success",
            count: gamemodes.length,
            gamemodes: gamemodes
        });
    } catch (err) {
        log.error("Error fetching all gamemodes:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.fetch_failed",
            "Failed to fetch gamemodes",
            [], 2001, "gamemode_error", 500, res
        );
    }
});

// Admin: Create new gamemode
app.post("/fortnite/api/admin/gamemodes/create", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const gamemodeData = req.body;

        // Check if gamemode already exists
        const existing = await Gamemode.findOne({ gamemodeId: gamemodeData.gamemodeId });
        if (existing) {
            return error.createError(
                "errors.com.epicgames.gamemode.already_exists",
                `Gamemode ${gamemodeData.gamemodeId} already exists`,
                [], 2003, "gamemode_exists", 400, res
            );
        }

        gamemodeData.createdBy = req.user.accountId;

        const gamemode = new Gamemode(gamemodeData);
        await gamemode.save();

        log.debug(`Gamemode created: ${gamemode.gamemodeId} by ${req.user.displayName}`);

        res.status(201).json({
            status: "success",
            message: "Gamemode created successfully",
            gamemode: gamemode
        });
    } catch (err) {
        log.error("Error creating gamemode:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.create_failed",
            "Failed to create gamemode",
            [err.message], 2004, "gamemode_error", 500, res
        );
    }
});

// Admin: Update gamemode
app.put("/fortnite/api/admin/gamemodes/:gamemodeId", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const gamemode = await Gamemode.findOneAndUpdate(
            { gamemodeId: req.params.gamemodeId },
            {
                ...req.body,
                updatedAt: Date.now()
            },
            { new: true }
        );

        if (!gamemode) {
            return error.createError(
                "errors.com.epicgames.gamemode.not_found",
                `Gamemode ${req.params.gamemodeId} not found`,
                [], 2002, "gamemode_not_found", 404, res
            );
        }

        log.debug(`Gamemode updated: ${gamemode.gamemodeId} by ${req.user.displayName}`);

        res.json({
            status: "success",
            message: "Gamemode updated successfully",
            gamemode: gamemode
        });
    } catch (err) {
        log.error("Error updating gamemode:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.update_failed",
            "Failed to update gamemode",
            [err.message], 2005, "gamemode_error", 500, res
        );
    }
});

// Admin: Delete gamemode
app.delete("/fortnite/api/admin/gamemodes/:gamemodeId", verifyToken, verifyAdmin, async (req, res) => {
    try {
        const gamemode = await Gamemode.findOneAndDelete({
            gamemodeId: req.params.gamemodeId
        });

        if (!gamemode) {
            return error.createError(
                "errors.com.epicgames.gamemode.not_found",
                `Gamemode ${req.params.gamemodeId} not found`,
                [], 2002, "gamemode_not_found", 404, res
            );
        }

        log.debug(`Gamemode deleted: ${gamemode.gamemodeId} by ${req.user.displayName}`);

        res.json({
            status: "success",
            message: "Gamemode deleted successfully"
        });
    } catch (err) {
        log.error("Error deleting gamemode:", err);
        return error.createError(
            "errors.com.epicgames.gamemode.delete_failed",
            "Failed to delete gamemode",
            [err.message], 2006, "gamemode_error", 500, res
        );
    }
});

module.exports = app;
