/**
 * Region Status API
 * Provides region and server status information
 */

const express = require("express");
const app = express.Router();
const log = require("../structs/log.js");
const config = require("../Config/config.json");
const regionManager = require("../structs/regionManager.js");

/**
 * Get all regions with status
 */
app.get("/api/v1/regions", (req, res) => {
    log.debug("GET /api/v1/regions called");

    const regions = regionManager.getAllRegions();

    res.json({
        regions: regions.map(region => ({
            id: region.regionId,
            name: region.regionName,
            displayName: region.displayName,
            location: region.location,
            ping: region.averagePing,
            enabled: region.enabled,
            playlists: region.playlists
        })),
        defaultRegion: "AutoRegion",
        autoSelectEnabled: true
    });
});

/**
 * Get specific region info
 */
app.get("/api/v1/regions/:regionId", (req, res) => {
    log.debug(`GET /api/v1/regions/${req.params.regionId} called`);

    const region = regionManager.getRegionById(req.params.regionId);

    if (!region) {
        return res.status(404).json({
            error: "Region not found"
        });
    }

    res.json({
        id: region.regionId,
        name: region.regionName,
        displayName: region.displayName,
        location: region.location,
        ip: region.ip,
        port: region.port,
        ping: region.averagePing,
        enabled: region.enabled,
        playlists: region.playlists
    });
});

/**
 * Get best region (for auto-select)
 */
app.get("/api/v1/regions/auto/best", (req, res) => {
    log.debug("GET /api/v1/regions/auto/best called");

    const bestRegion = regionManager.getBestRegion();

    if (!bestRegion) {
        return res.status(404).json({
            error: "No regions available"
        });
    }

    res.json({
        id: bestRegion.regionId,
        name: bestRegion.regionName,
        displayName: `${bestRegion.displayName} ${bestRegion.averagePing}ms`,
        location: bestRegion.location,
        ip: bestRegion.ip,
        port: bestRegion.port,
        ping: bestRegion.averagePing,
        auto: true
    });
});

module.exports = app;
