/**
 * Ping/QoS API
 * Handles ping tests for server regions
 */

const express = require("express");
const app = express.Router();
const log = require("../structs/log.js");
const config = require("../Config/config.json");

/**
 * Ping test endpoint for QoS (Quality of Service)
 * Returns server information and allows client to calculate ping
 */
app.get("/api/v1/fortnite-br/surfaces/:region/target", (req, res) => {
    log.debug(`GET /api/v1/fortnite-br/surfaces/${req.params.region}/target called`);

    const region = req.params.region;

    // Find server for this region
    const server = config.gameServers.find(s => s.region === region || s.region.includes(region));

    if (!server) {
        return res.status(404).json({
            error: "Region not found"
        });
    }

    res.json({
        region: server.region,
        ip: server.ip,
        port: server.port,
        timestamp: Date.now()
    });
});

/**
 * Simple ping endpoint
 */
app.post("/fortnite/api/game/v2/matchmakingservice/datarouter/ping", (req, res) => {
    log.debug("POST /fortnite/api/game/v2/matchmakingservice/datarouter/ping called");

    // Return timestamp for ping calculation
    res.json({
        timestamp: Date.now(),
        pong: true
    });
});

/**
 * Region ping endpoint
 */
app.post("/region/ping", (req, res) => {
    log.debug("POST /region/ping called");

    // Return all available servers with their info
    const servers = config.gameServers.filter(s => s.enabled).map(server => ({
        region: server.region,
        regionName: server.regionName || server.region,
        ip: server.ip,
        port: server.port,
        location: server.location,
        averagePing: server.averagePing || 0
    }));

    res.json({
        servers: servers,
        timestamp: Date.now()
    });
});

module.exports = app;
