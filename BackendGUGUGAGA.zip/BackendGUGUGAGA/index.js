const express = require("express");
const mongoose = require("mongoose");
const fs = require("fs");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const path = require("path");
const kv = require("./structs/kv.js");
const config = require('./Config');
const WebSocket = require('ws');
const https = require("https");

const log = require("./structs/log.js");
const functions = require("./structs/functions.js");
const AutoBackendRestart = require("./structs/autobackendrestart.js");
const { runAutoSetup } = require("./structs/auto_setup.js");
const healthMonitor = require("./structs/health_monitor.js");

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    log.error("UNCAUGHT EXCEPTION:", error);
    console.error(error);
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
    log.error("UNHANDLED REJECTION:", reason);
    console.error(reason);
});

const app = express();

if (!fs.existsSync("./ClientSettings")) fs.mkdirSync("./ClientSettings");
const PORT = config.port;
const WEBSITEPORT = config.Website.websiteport;

let httpsServer;

if (config.bEnableHTTPS) {
    const httpsOptions = {
        cert: fs.readFileSync(config.ssl.cert),
        ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
        key: fs.readFileSync(config.ssl.key)
    };

    httpsServer = https.createServer(httpsOptions, app);
}

if (!fs.existsSync("./ClientSettings")) fs.mkdirSync("./ClientSettings");

global.JWT_SECRET = functions.MakeID();

console.log('Made By .salvinhaa. and santi.2\n');

// Auto Setup - Configura tudo automaticamente na primeira vez
runAutoSetup();

// Ensure tokenManager directory exists
if (!fs.existsSync("./tokenManager")) {
    fs.mkdirSync("./tokenManager", { recursive: true });
}

// Check if tokens.json exists, if not create it
if (!fs.existsSync("./tokenManager/tokens.json")) {
    log.backend("Creating tokens.json file...");
    fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify({
        accessTokens: [],
        refreshTokens: [],
        clientTokens: []
    }, null, 2));
}

let tokens;
try {
    tokens = JSON.parse(fs.readFileSync("./tokenManager/tokens.json").toString());
} catch (err) {
    log.error("Error reading tokens.json, creating new one:", err);
    tokens = {
        accessTokens: [],
        refreshTokens: [],
        clientTokens: []
    };
    fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify(tokens, null, 2));
}

// Clean expired tokens
for (let tokenType in tokens) {
    if (!Array.isArray(tokens[tokenType])) {
        tokens[tokenType] = [];
        continue;
    }

    for (let tokenIndex in tokens[tokenType]) {
        try {
            let decodedToken = jwt.decode(tokens[tokenType][tokenIndex].token.replace("eg1~", ""));

            if (decodedToken && DateAddHours(new Date(decodedToken.creation_date), decodedToken.hours_expire).getTime() <= new Date().getTime()) {
                tokens[tokenType].splice(Number(tokenIndex), 1);
            }
        } catch (err) {
            // Invalid token, remove it
            tokens[tokenType].splice(Number(tokenIndex), 1);
        }
    }
}

fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify(tokens, null, 2));

global.accessTokens = tokens.accessTokens || [];
global.refreshTokens = tokens.refreshTokens || [];
global.clientTokens = tokens.clientTokens || [];
global.kv = kv;

global.exchangeCodes = [];

// Auto-generate access tokens from valid refresh tokens on startup
(async () => {
    if (global.accessTokens.length === 0 && global.refreshTokens.length > 0) {
        log.backend("No access tokens found, generating from refresh tokens...");

        const tokenCreation = require("./tokenManager/tokenCreation.js");
        const User = require("./model/user.js");
        const jwt = require("jsonwebtoken");

        for (let rt of global.refreshTokens) {
            try {
                let rtDecoded = jwt.decode(rt.token.replace("eg1~", ""));

                // Check if refresh token is still valid
                let rtExpired = new Date(rtDecoded.creation_date).getTime() + (rtDecoded.hours_expire * 60 * 60 * 1000) <= new Date().getTime();

                if (!rtExpired) {
                    // Get user from database
                    let user = await User.findOne({ accountId: rtDecoded.sub });

                    if (user && !user.banned) {
                        // Ensure user has matchmakingId
                        if (!user.matchmakingId) {
                            const matchmakingId = functions.MakeID().replace(/-/ig, "");
                            await User.updateOne(
                                { accountId: user.accountId },
                                { $set: { matchmakingId: matchmakingId } }
                            );
                            user.matchmakingId = matchmakingId;
                            log.backend(`Generated matchmakingId for: ${user.username}`);
                        }

                        // Generate new access token (7 days)
                        tokenCreation.createAccess(user, rtDecoded.clid, "refresh_token", rtDecoded.dvid, 168);
                        log.backend(`Generated access token for: ${user.username}`);
                    }
                }
            } catch (err) {
                // Skip invalid refresh tokens
            }
        }

        functions.UpdateTokens();
        log.backend(`Generated ${global.accessTokens.length} access tokens from refresh tokens`);
    }
})();

let updateFound = false;

const packageJson = JSON.parse(fs.readFileSync(path.join(__dirname, "./package.json")).toString());
if (!packageJson) throw new Error("Failed to parse package.json");
const version = packageJson.version;

app.get("/tos", (req, res) => {
    log.backend('ToS page requested');
    const tosPath = path.join(__dirname, 'public', 'tos.html');
    log.backend(`ToS file path: ${tosPath}`);
    res.sendFile(tosPath);
});

const DatabaseOptimizer = require("./structs/database_optimizer.js");

mongoose.set('strictQuery', true);

// Use optimized connection settings
const connectionOptions = DatabaseOptimizer.getOptimizedConnectionOptions();

mongoose.connect(config.mongodb.database, connectionOptions).then(async () => {

    // Create indexes for better performance
    await DatabaseOptimizer.createIndexes(mongoose.connection);

    // Show database statistics
    await DatabaseOptimizer.getStats(mongoose.connection);

    // Start health monitor
    healthMonitor.start();
});

mongoose.connection.on("error", err => {
    log.error("MongoDB failed to connect, please make sure you have MongoDB installed and running.");
    throw err;
});

// Rate limiter geral (excluir rotas internas do game server)
const generalLimiter = rateLimit({ windowMs: 0.5 * 60 * 1000, max: 200 });
app.use((req, res, next) => {
    // Rotas internas do game server nao precisam de rate limit
    const gameServerRoutes = ['/api/reward-kill', '/api/reward-win', '/api/arena/', '/api/get-hype', '/api/add-xp', '/api/add-game-stats', '/api/gameserver/'];
    if (gameServerRoutes.some(r => req.path.startsWith(r))) return next();
    return generalLimiter(req, res, next);
});
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log requests middleware (disabled for clean logs)
app.use((req, res, next) => {
    next();
});

// CORS middleware for launcher requests
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, Cookie');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});


fs.readdirSync("./Api").forEach(fileName => {
    try {
        app.use(require(`./Api/${fileName}`));
    } catch (err) {
        log.error(`VORZA API Error: Failed to load ${fileName}: ${err.message}`);
        log.error(err.stack || err);
    }
});

fs.readdirSync("./routes").forEach(fileName => {
    try {
        app.use(require(`./routes/${fileName}`));
    } catch (err) {
        log.error(`VORZA Routes Error: Failed to load ${fileName}: ${err.message}`);
        log.error(err.stack || err);
    }
});

app.use('/downloads', express.static(path.join(__dirname, 'downloads')));

// Serve playlist images
app.use('/playlist-images', express.static(path.join(__dirname, 'downloads'), {
    setHeaders: (res) => {
        res.set('Content-Type', 'image/jpeg');
        res.set('Access-Control-Allow-Origin', '*');
    }
}));

app.get("/unknown", (req, res) => {
    log.debug('GET /unknown endpoint called');
    res.json({ msg: "Vorza" });
});

let server;
if (config.bEnableHTTPS) {
    server = httpsServer.listen(PORT, '0.0.0.0', () => {
        log.backend(`Backend started listening on port ${PORT} (SSL Enabled)`);
        require("./xmpp/xmpp.js");
        if (config.discord.bUseDiscordBot === true) {
            require("./DiscordBot");
        }
        if (config.bUseAutoRotate === true) {
            try {
                require("./structs/autorotate.js");
            } catch (err) {
                log.error("[AUTO-ROTATE] Failed to load autorotate.js:", err.message);
                console.error(err);
            }
        }
    }).on("error", async (err) => {
        if (err.code === "EADDRINUSE") {
            log.error(`Port ${PORT} is already in use!\nClosing in 3 seconds...`);
            await functions.sleep(3000);
            process.exit(0);
        } else {
            throw err;
        }
    });
} else {
    server = app.listen(PORT, '0.0.0.0', () => {
        log.backend(`Backend started listening on port ${PORT} (SSL Disabled)`);
        require("./xmpp/xmpp.js");
        if (config.discord.bUseDiscordBot === true) {
            require("./DiscordBot");
        }
        if (config.bUseAutoRotate === true) {
            try {
                require("./structs/autorotate.js");
            } catch (err) {
                log.error("[AUTO-ROTATE] Failed to load autorotate.js:", err.message);
                console.error(err);
            }
        }
    }).on("error", async (err) => {
        if (err.code === "EADDRINUSE") {
            log.error(`Port ${PORT} is already in use!\nClosing in 3 seconds...`);
            await functions.sleep(3000);
            process.exit(0);
        } else {
            throw err;
        }
    });
}

if (config.bEnableAutoBackendRestart === true) {
    AutoBackendRestart.scheduleRestart(config.bRestartTime);
}

if (config.bEnableCalderaService === true) {
    const createCalderaService = require('./CalderaService/calderaservice');
    const calderaService = createCalderaService();

    let calderaHttpsOptions;
    if (config.bEnableHTTPS) {
        calderaHttpsOptions = {
            cert: fs.readFileSync(config.ssl.cert),
            ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
            key: fs.readFileSync(config.ssl.key)
        };
    }

    if (config.bEnableHTTPS) {
        const calderaHttpsServer = https.createServer(calderaHttpsOptions, calderaService);
        
        if (!config.bGameVersion) {
            log.calderaservice("Please define a version in the config!")
            return;
        }

        calderaHttpsServer.listen(config.bCalderaServicePort, '0.0.0.0', () => {
            log.calderaservice(`Caldera Service started listening on port ${config.bCalderaServicePort} (SSL Enabled)`);
        }).on("error", async (err) => {
            if (err.code === "EADDRINUSE") {
                log.calderaservice(`Caldera Service port ${config.bCalderaServicePort} is already in use!\nClosing in 3 seconds...`);
                await functions.sleep(3000);
                process.exit(1);
            } else {
                throw err;
            }
        });
    } else {
        if (!config.bGameVersion) {
            log.calderaservice("Please define a version in the config!")
            return;
        }

        calderaService.listen(config.bCalderaServicePort, '0.0.0.0', () => {
            log.calderaservice(`Caldera Service started listening on port ${config.bCalderaServicePort} (SSL Disabled)`);
        }).on("error", async (err) => {
            if (err.code === "EADDRINUSE") {
                log.calderaservice(`Caldera Service port ${config.bCalderaServicePort} is already in use!\nClosing in 3 seconds...`);
                await functions.sleep(3000);
                process.exit(1);
            } else {
                throw err;
            }
        });
    }
}

if (config.Website.bUseWebsite === true) {
    const websiteApp = express();
    require('./Website/website')(websiteApp);

    let httpsOptions;
    if (config.bEnableHTTPS) {
        httpsOptions = {
            cert: fs.readFileSync(config.ssl.cert),
            ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
            key: fs.readFileSync(config.ssl.key)
        };
    }

    if (config.bEnableHTTPS) {
        const httpsServer = https.createServer(httpsOptions, websiteApp);
        httpsServer.listen(config.Website.websiteport, '0.0.0.0', () => {
            log.website(`Website started listening on port ${config.Website.websiteport} (SSL Enabled)`);
        }).on("error", async (err) => {
            if (err.code === "EADDRINUSE") {
                log.error(`Website port ${config.Website.websiteport} is already in use!\nClosing in 3 seconds...`);
                await functions.sleep(3000);
                process.exit(1);
            } else {
                throw err;
            }
        });
    } else {
        websiteApp.listen(config.Website.websiteport, '0.0.0.0', () => {
            log.website(`Website started listening on port ${config.Website.websiteport} (SSL Disabled)`);
        }).on("error", async (err) => {
            if (err.code === "EADDRINUSE") {
                log.error(`Website port ${config.Website.websiteport} is already in use!\nClosing in 3 seconds...`);
                await functions.sleep(3000);
                process.exit(1);
            } else {
                throw err;
            }
        });
    }
}

app.use((req, res, next) => {
    const url = req.originalUrl;
    log.debug(`Missing endpoint: ${req.method} ${url} request port ${req.socket.localPort}`);
    if (req.url.includes("..")) {
        res.redirect("https://youtu.be/dQw4w9WgXcQ");
        return;
    }

    // Serve HTML 404 page for browser requests
    const accept = req.headers['accept'] || '';
    if (accept.includes('text/html')) {
        return res.status(404).sendFile(path.join(__dirname, 'Website', 'Data', 'html', '404.html'));
    }

    // Standard 404 error response for API/game requests
    res.status(404).json({
        errorCode: "errors.com.epicgames.common.not_found",
        errorMessage: "Sorry the resource you were trying to find could not be found",
        messageVars: [],
        numericErrorCode: 1004,
        originatingService: "any",
        intent: "prod"
    });
});

function DateAddHours(pdate, number) {
    let date = pdate;
    date.setHours(date.getHours() + number);

    return date;
}

module.exports = app;