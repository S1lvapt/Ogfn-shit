#!/bin/bash

echo "=== Vorza WebSocket Ubuntu Fix ==="
echo ""

# 1. Check if port 8081 is already in use
echo "[1] Checking if port 8081 is in use..."
sudo netstat -tlnp | grep 8081
if [ $? -eq 0 ]; then
    echo "WARNING: Port 8081 is already in use!"
    echo "Run: sudo kill -9 \$(sudo lsof -t -i:8081) to kill the process"
else
    echo "Port 8081 is available"
fi
echo ""

# 2. Check firewall status
echo "[2] Checking firewall status..."
sudo ufw status | grep 8081
if [ $? -ne 0 ]; then
    echo "Port 8081 is NOT allowed in firewall"
    echo "Opening port 8081..."
    sudo ufw allow 8081/tcp
    sudo ufw reload
    echo "Port 8081 opened!"
else
    echo "Port 8081 is already allowed in firewall"
fi
echo ""

# 3. Check if Node.js has permissions
echo "[3] Checking Node.js permissions..."
which node
node --version
echo ""

# 4. Test if ports 3551 and 8081 are open
echo "[4] Testing if ports are listening..."
echo "Port 3551 (Backend):"
sudo netstat -tlnp | grep 3551
echo "Port 8081 (WebSocket):"
sudo netstat -tlnp | grep 8081
echo ""

# 5. Install wscat for testing
echo "[5] Installing wscat for WebSocket testing..."
sudo npm install -g wscat
echo ""

echo "=== Fix Complete ==="
echo ""
echo "Next steps:"
echo "1. Stop your backend if running (Ctrl+C)"
echo "2. Start backend: node index.js"
echo "3. Test WebSocket: wscat -c ws://localhost:8081"
echo "4. If still fails, send backend logs"
