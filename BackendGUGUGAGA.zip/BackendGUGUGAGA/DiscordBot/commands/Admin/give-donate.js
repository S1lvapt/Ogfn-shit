const Users = require('../../../model/user');
const Profiles = require('../../../model/profiles');
const { MessageEmbed } = require('discord.js');
const config = require('../../../Config/config.json');
const fs = require('fs');
const path = require('path');
const log = require('../../../structs/log.js');

module.exports = {
    commandInfo: {
        name: "give-donate",
        description: "Manually give donation benefits to a user (use when auto-sync fails)",
        options: [
            {
                name: "user",
                description: "The target user (mention or Discord ID)",
                required: true,
                type: 6
            },
            {
                name: "tier",
                description: "Which tier to give",
                required: true,
                type: 3,
                choices: [
                    { name: "Basic (Green name + Priority MM)", value: "basic" },
                    { name: "Medium (Blue + 5k VBucks)", value: "medium" },
                    { name: "High (Orange + Skins + 2k VBucks)", value: "high" },
                    { name: "Ultimate (Purple + All + 10k VBucks)", value: "ultimate" }
                ]
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: false });

        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        const selectedUser = interaction.options.getUser('user');
        const tier = interaction.options.getString('tier');

        if (!selectedUser) {
            return interaction.editReply({ content: "Invalid user specified.", ephemeral: true });
        }

        // Find user in database
        const userData = await Users.findOne({ discordId: selectedUser.id });
        if (!userData) {
            return interaction.editReply({
                content: `User ${selectedUser.username} does not have a linked Vorza account. They need to login with Discord first!`,
                ephemeral: true
            });
        }

        const update = {};
        const benefits = [];
        const now = new Date();

        // Check if already received
        const benefitsGiven = userData.benefitsGiven || { basic: false, medium: false, high: false, ultimate: false };

        try {
            // BASIC
            if (tier === 'basic') {
                if (benefitsGiven.basic) {
                    return interaction.editReply({ content: `${selectedUser.username} already has Basic Donator benefits!` });
                }
                update.basicDonator = true;
                update.donator = true;
                update['benefitsGiven.basic'] = true;
                update['donatorSince.basic'] = now;
                benefits.push("Priority Matchmaking");
                benefits.push("Green name in launcher");
            }

            // MEDIUM
            if (tier === 'medium') {
                if (benefitsGiven.medium) {
                    return interaction.editReply({ content: `${selectedUser.username} already has Medium Donator benefits!` });
                }
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update['donatorSince.medium'] = now;
                update.vbucks = (userData.vbucks || 0) + 5000;
                // V-Bucks s� no User � n�o escrever no Profile
                benefits.push("+5,000 V-Bucks");
                benefits.push("Priority Matchmaking");
                benefits.push("Blue name in launcher");
            }

            // HIGH - ALL SKINS (including Series) but NO pickaxes, gliders, dances, backpacks
            if (tier === 'high') {
                if (benefitsGiven.high) {
                    return interaction.editReply({ content: `${selectedUser.username} already has High Donator benefits!` });
                }
                update.highDonator = true;
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                update['benefitsGiven.high'] = true;
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update['donatorSince.high'] = now;
                update.vbucks = (userData.vbucks || 0) + 2000;
                // V-Bucks s� no User � n�o escrever no Profile

                // Give ALL SKINS (including Series) but NO pickaxes, gliders, dances, backpacks
                const highPath = path.join(__dirname, '../../../Config/DefaultProfiles/highathena.json');

                if (fs.existsSync(highPath)) {
                    const skinsProfile = JSON.parse(fs.readFileSync(highPath, 'utf8'));
                    await Profiles.updateOne(
                        { accountId: userData.accountId },
                        { $set: { 'profiles.athena': skinsProfile } }
                    );
                    benefits.push("ALL Skins (including Series)");
                    benefits.push("(No pickaxes, gliders, dances, backpacks)");
                } else {
                    benefits.push("ERROR: highathena.json not found!");
                    log.error(`highathena.json not found! Run: node scripts/generateHighAthena.js`);
                }

                benefits.push("+2,000 V-Bucks");
                benefits.push("Orange name in launcher");
            }

            // ULTIMATE - ALL cosmetics (skins, pickaxes, dances, backpacks, EVERYTHING)
            if (tier === 'ultimate') {
                if (benefitsGiven.ultimate) {
                    return interaction.editReply({ content: `${selectedUser.username} already has Ultimate Donator benefits!` });
                }
                update.ultimateDonator = true;
                update.highDonator = true;
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                update['benefitsGiven.ultimate'] = true;
                update['benefitsGiven.high'] = true;
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update['donatorSince.ultimate'] = now;
                update.vbucks = (userData.vbucks || 0) + 10000;
                // V-Bucks s� no User � n�o escrever no Profile

                // Give ALL cosmetics (skins, pickaxes, dances, backpacks, gliders, emotes, wraps, etc.)
                const allPath = path.join(__dirname, '../../../Config/DefaultProfiles/allathena.json');
                if (fs.existsSync(allPath)) {
                    const allAthena = JSON.parse(fs.readFileSync(allPath, 'utf8'));
                    await Profiles.updateOne(
                        { accountId: userData.accountId },
                        { $set: { 'profiles.athena': allAthena } }
                    );
                    benefits.push("ALL Cosmetics (Skins, Pickaxes, Dances, Backpacks, Gliders, Emotes, Wraps...)");
                }

                benefits.push("+10,000 V-Bucks");
                benefits.push("Priority Matchmaking");
                benefits.push("Purple name in launcher");
            }

            // Save to database
            await userData.updateOne({ $set: update });

            // Create embed
            const tierColors = {
                basic: '#4CAF50',
                medium: '#2196F3',
                high: '#FF9800',
                ultimate: '#9C27B0'
            };

            const tierNames = {
                basic: 'Basic Donator',
                medium: 'Medium Donator',
                high: 'High Donator',
                ultimate: 'Ultimate Donator'
            };

            const embed = new MessageEmbed()
                .setTitle(`${tierNames[tier]} Benefits Given!`)
                .setDescription(`Successfully gave **${tierNames[tier]}** benefits to <@${selectedUser.id}> (${userData.username})`)
                .addField("Benefits Given:", benefits.map(b => `� ${b}`).join('\n'))
                .setColor(tierColors[tier])
                .setFooter({ text: `Given by ${interaction.user.username}` })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            // Try to DM the user
            try {
                const dmEmbed = new MessageEmbed()
                    .setTitle(`Thank you for your donation!`)
                    .setDescription(`You are now a **${tierNames[tier]}**!\n\nYour benefits are **permanent** and will never be removed.`)
                    .addField("Your Benefits:", benefits.map(b => `� ${b}`).join('\n'))
                    .setColor(tierColors[tier])
                    .setFooter({ text: "Restart your game to see the changes!" })
                    .setTimestamp();

                await selectedUser.send({ embeds: [dmEmbed] });
            } catch (e) {
                // User has DMs disabled
            }

            log.bot(`[DONATE] Manually gave ${tier} benefits to ${userData.username} by ${interaction.user.username}`);

        } catch (error) {
            log.error(`[DONATE] Error giving benefits: ${error.message}`);
            console.error(error);
            return interaction.editReply({ content: `Error: ${error.message}` });
        }
    }
};
