const Users = require('../../../model/user');
const Profiles = require('../../../model/profiles');
const { MessageEmbed } = require('discord.js');
const config = require('../../../Config/config.json');
const fs = require('fs');
const path = require('path');

module.exports = {
    commandInfo: {
        name: "apply-donator-benefits",
        description: "Apply all benefits for a donator tier (vbucks, skins, etc.)",
        options: [
            {
                name: "user",
                description: "The target user (mention or Discord ID)",
                required: true,
                type: 6
            },
            {
                name: "tier",
                description: "Which tier: basic, medium, high, ultimate",
                required: true,
                type: 3,
                choices: [
                    { name: "Basic (Green name + Priority MM)", value: "basic" },
                    { name: "Medium (Blue + 5k VBucks + Priority MM)", value: "medium" },
                    { name: "High (Orange + All Skins including Series + 2k VBucks)", value: "high" },
                    { name: "Ultimate (Purple + All cosmetics + 10k VBucks + Priority MM)", value: "ultimate" }
                ]
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: false });

        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        const selectedUser = interaction.options.getUser('user');
        const tier = interaction.options.getString('tier');

        if (!selectedUser) return interaction.editReply({ content: "Invalid user specified.", ephemeral: true });

        const user = await Users.findOne({ discordId: selectedUser.id }) || await Users.findOne({ username: selectedUser.username });
        if (!user) return interaction.editReply({ content: "That user does not own an account.", ephemeral: true });

        const benefits = [];
        const update = {};
        const now = new Date();

        // Check if benefits were already given
        const benefitsGiven = user.benefitsGiven || { basic: false, medium: false, high: false, ultimate: false };

        // Set appropriate donator flags (cascading - higher tiers include lower)
        // Benefits are PERMANENT
        switch (tier) {
            case 'ultimate':
                update.ultimateDonator = true;
                update.highDonator = true;
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                if (!user.donatorSince?.ultimate) update['donatorSince.ultimate'] = now;
                break;
            case 'high':
                update.highDonator = true;
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                if (!user.donatorSince?.high) update['donatorSince.high'] = now;
                break;
            case 'medium':
                update.mediumDonator = true;
                update.basicDonator = true;
                update.donator = true;
                if (!user.donatorSince?.medium) update['donatorSince.medium'] = now;
                break;
            case 'basic':
                update.basicDonator = true;
                update.donator = true;
                if (!user.donatorSince?.basic) update['donatorSince.basic'] = now;
                break;
        }

        // Apply tier-specific benefits (only if not already given)
        try {
            if (tier === 'basic' && !benefitsGiven.basic) {
                // Basic: Priority matchmaking + Green name (no items/vbucks)
                update['benefitsGiven.basic'] = true;
                benefits.push("Priority Matchmaking");
                benefits.push("Green name in launcher");
            } else if (tier === 'basic' && benefitsGiven.basic) {
                benefits.push("(Already received - Priority Matchmaking)");
                benefits.push("(Already received - Green name)");
            }

            if (tier === 'medium' && !benefitsGiven.medium) {
                // Medium: 5000 V-Bucks + Priority MM + Blue name
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update.vbucks = (user.vbucks || 0) + 5000;
                // V-Bucks s� no User � n�o escrever no Profile
                benefits.push("+5,000 V-Bucks");
                benefits.push("Priority Matchmaking");
                benefits.push("Blue name in launcher");
            } else if (tier === 'medium' && benefitsGiven.medium) {
                benefits.push("(Already received - 5,000 V-Bucks)");
            }

            if (tier === 'high' && !benefitsGiven.high) {
                // High: All skins (except series) + 2000 V-Bucks + Orange name
                update['benefitsGiven.high'] = true;
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update.vbucks = (user.vbucks || 0) + 2000;
                // V-Bucks s� no User � n�o escrever no Profile

                // Load high donator skins (all including series) or fallback to all
                let skinsProfile;
                const highAthenaPath = path.join(__dirname, '../../../Config/DefaultProfiles/highathena.json');
                const allAthenaPath = path.join(__dirname, '../../../Config/DefaultProfiles/allathena.json');

                if (fs.existsSync(highAthenaPath)) {
                    skinsProfile = JSON.parse(fs.readFileSync(highAthenaPath, 'utf8'));
                    benefits.push("ALL Skins (including Series)");
                } else if (fs.existsSync(allAthenaPath)) {
                    skinsProfile = JSON.parse(fs.readFileSync(allAthenaPath, 'utf8'));
                    benefits.push("All skins");
                }

                if (skinsProfile) {
                    await Profiles.updateOne(
                        { accountId: user.accountId },
                        { $set: { 'profiles.athena': skinsProfile } }
                    );
                }

                benefits.push("+2,000 V-Bucks");
                benefits.push("Orange name in launcher");
            } else if (tier === 'high' && benefitsGiven.high) {
                benefits.push("(Already received - Skins + 2,000 V-Bucks)");
            }

            if (tier === 'ultimate' && !benefitsGiven.ultimate) {
                // Ultimate: ALL cosmetics + 10000 V-Bucks + Purple name + Priority MM
                update['benefitsGiven.ultimate'] = true;
                update['benefitsGiven.high'] = true;
                update['benefitsGiven.medium'] = true;
                update['benefitsGiven.basic'] = true;
                update.vbucks = (user.vbucks || 0) + 10000;
                // V-Bucks s� no User � n�o escrever no Profile

                // Load all cosmetics
                const allAthenaPath = path.join(__dirname, '../../../Config/DefaultProfiles/allathena.json');
                if (fs.existsSync(allAthenaPath)) {
                    const allAthena = JSON.parse(fs.readFileSync(allAthenaPath, 'utf8'));
                    await Profiles.updateOne(
                        { accountId: user.accountId },
                        { $set: { 'profiles.athena': allAthena } }
                    );
                    benefits.push("ALL Cosmetics");
                }

                benefits.push("+10,000 V-Bucks");
                benefits.push("Priority Matchmaking");
                benefits.push("Purple name in launcher");
            } else if (tier === 'ultimate' && benefitsGiven.ultimate) {
                benefits.push("(Already received - All cosmetics + 10,000 V-Bucks)");
            }

            // Update user flags
            await user.updateOne({ $set: update });

            // Create success embed
            const tierColors = {
                basic: '#4CAF50',     // Green
                medium: '#2196F3',    // Blue
                high: '#FF9800',      // Orange
                ultimate: '#9C27B0'   // Purple
            };

            const tierNames = {
                basic: 'Basic Donator',
                medium: 'Medium Donator',
                high: 'High Donator',
                ultimate: 'Ultimate Donator'
            };

            const embed = new MessageEmbed()
                .setTitle(`${tierNames[tier]} Benefits Applied!`)
                .setDescription(`Successfully applied **${tierNames[tier]}** benefits to <@${selectedUser.id}>`)
                .addField("Benefits Given:", benefits.map(b => `� ${b}`).join('\n'))
                .setColor(tierColors[tier])
                .setFooter({ text: `Applied by ${interaction.user.username}` })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error applying donator benefits:', error);
            return interaction.editReply({ content: `Error applying benefits: ${error.message}`, ephemeral: true });
        }
    }
};
