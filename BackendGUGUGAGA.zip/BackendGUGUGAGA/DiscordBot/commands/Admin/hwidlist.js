const { MessageEmbed } = require("discord.js");
const HWIDBan = require("../../../model/hwidbans.js");

module.exports = {
    commandInfo: {
        name: "hwidlist",
        description: "List all HWID bans",
        options: []
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const config = require('../../../Config');
        const { moderators } = config;

        if (!moderators.includes(interaction.user.id)) {
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription("You do not have moderator permissions.")
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }

        try {
            const bans = await HWIDBan.find().sort({ bannedAt: -1 }).limit(25);

            if (bans.length === 0) {
                const embed = new MessageEmbed()
                    .setTitle("HWID Bans")
                    .setDescription("No HWID bans found.")
                    .setColor("GREEN")
                    .setFooter({ text: "Vorza", iconURL: "" })
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            const embed = new MessageEmbed()
                .setTitle(`🔒 HWID Bans (${bans.length})`)
                .setDescription("List of all hardware ID bans (showing last 25):")
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            bans.forEach((ban, index) => {
                const type = ban.isPermanent ? "🔴 Permanent" : `🟡 ${ban.expiresAt ? `Until ${ban.expiresAt.toLocaleDateString()}` : 'Temporary'}`;
                embed.addField(
                    `${index + 1}. ${ban.username}`,
                    `**Type:** ${type}\n` +
                    `**Reason:** ${ban.reason}\n` +
                    `**By:** ${ban.bannedBy}\n` +
                    `**Date:** ${ban.bannedAt.toLocaleDateString()}`,
                    false
                );
            });

            await interaction.editReply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error(error);
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription(`Failed to list HWID bans: ${error.message}`)
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }
    }
};
