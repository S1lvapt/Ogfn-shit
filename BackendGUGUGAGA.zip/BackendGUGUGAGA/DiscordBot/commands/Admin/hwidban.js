const { MessageEmbed } = require("discord.js");
const Users = require("../../../model/user.js");
const HWIDBan = require("../../../model/hwidbans.js");

module.exports = {
    commandInfo: {
        name: "hwidban",
        description: "Ban a user's hardware ID (HWID)",
        options: [
            {
                name: "username",
                description: "The Vorza username to ban",
                required: true,
                type: 3 // string
            },
            {
                name: "reason",
                description: "Reason for the HWID ban",
                required: false,
                type: 3
            },
            {
                name: "duration",
                description: "Duration in days (leave empty for permanent)",
                required: false,
                type: 4 // integer
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const config = require('../../../Config');
        const { moderators } = config;

        if (!moderators.includes(interaction.user.id)) {
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription("You do not have moderator permissions.")
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }

        const username = interaction.options.getString("username");
        const reason = interaction.options.getString("reason") || "No reason provided";
        const duration = interaction.options.getInteger("duration");

        try {
            // Find user
            const user = await Users.findOne({ username: username });

            if (!user) {
                const embed = new MessageEmbed()
                    .setTitle("Error")
                    .setDescription(`User **${username}** not found.`)
                    .setColor("RED")
                    .setFooter({ text: "Vorza", iconURL: "" })
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            // Check if user has HWID
            if (!user.currentHWID || user.currentHWID.trim() === "") {
                const embed = new MessageEmbed()
                    .setTitle("Error")
                    .setDescription(`User **${username}** has no HWID registered yet. They must login at least once.`)
                    .setColor("RED")
                    .setFooter({ text: "Vorza", iconURL: "" })
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            // Check if already banned
            const existing = await HWIDBan.findOne({ hwid: user.currentHWID });
            if (existing) {
                const embed = new MessageEmbed()
                    .setTitle("Error")
                    .setDescription(`User **${username}**'s HWID is already banned!\n\n` +
                        `**Reason:** ${existing.reason}\n` +
                        `**Banned by:** ${existing.bannedBy}\n` +
                        `**Type:** ${existing.isPermanent ? 'Permanent' : 'Temporary'}`)
                    .setColor("RED")
                    .setFooter({ text: "Vorza", iconURL: "" })
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            // Calculate expiration
            let expiresAt = null;
            let isPermanent = true;

            if (duration && duration > 0) {
                isPermanent = false;
                expiresAt = new Date();
                expiresAt.setDate(expiresAt.getDate() + duration);
            }

            // Create ban
            const ban = await HWIDBan.create({
                hwid: user.currentHWID,
                accountId: user.accountId,
                username: user.username,
                reason,
                bannedBy: interaction.user.username,
                isPermanent,
                expiresAt,
                bannedAt: new Date()
            });

            // Also ban the account
            await user.updateOne({ $set: { banned: true } });

            // Kick from game if online
            let refreshToken = global.refreshTokens.findIndex(i => i.accountId == user.accountId);
            if (refreshToken != -1) global.refreshTokens.splice(refreshToken, 1);

            let accessToken = global.accessTokens.findIndex(i => i.accountId == user.accountId);
            if (accessToken != -1) {
                global.accessTokens.splice(accessToken, 1);
                let xmppClient = global.Clients.find(client => client.accountId == user.accountId);
                if (xmppClient) xmppClient.client.close();
            }

            const embed = new MessageEmbed()
                .setTitle("✅ HWID Banned Successfully")
                .setDescription(`**${username}** has been hardware banned!`)
                .addField("Account ID", user.accountId, true)
                .addField("HWID", user.currentHWID.substring(0, 12) + "...", true)
                .addField("Type", isPermanent ? "**Permanent**" : `Temporary (${duration} days)`, true)
                .addField("Reason", reason)
                .addField("Banned By", interaction.user.username)
                .setColor("RED")
                .setFooter({ text: "User will be blocked from launcher", iconURL: "" })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error(error);
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription(`Failed to ban HWID: ${error.message}`)
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }
    }
};
