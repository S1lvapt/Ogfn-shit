const Users = require('../../../model/user');
const config = require('../../../Config/config.json');
const { MessageEmbed } = require('discord.js');

module.exports = {
    commandInfo: {
        name: "removevbucks",
        description: "Lets you change a user's amount of V-Bucks",
        options: [
            {
                name: "user",
                description: "The user you want to change the V-Bucks of",
                required: true,
                type: 6
            },
            {
                name: "vbucks",
                description: "The amount of V-Bucks you want to remove (Can be a negative number to add V-Bucks)",
                required: true,
                type: 4
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        const selectedUser = interaction.options.getUser('user');
        const selectedUserId = selectedUser?.id;
        const user = await Users.findOne({ discordId: selectedUserId });

        if (!user) {
            return interaction.editReply({ content: "That user does not own an account", ephemeral: true });
        }

        const vbucks = parseInt(interaction.options.getInteger('vbucks'));
        if (isNaN(vbucks) || vbucks === 0) {
            return interaction.editReply({ content: "Invalid V-Bucks amount specified.", ephemeral: true });
        }

        // V-Bucks s� no User � n�o escrever no Profile
        const updatedUser = await Users.findOneAndUpdate(
            { accountId: user.accountId },
            { $inc: { vbucks: -vbucks } },
            { new: true }
        );
        if (!updatedUser) {
            return interaction.editReply({ content: "That user does not own an account", ephemeral: true });
        }
        const newVbucks = Math.max(0, updatedUser.vbucks ?? 0);

        if (newVbucks < 0 || newVbucks >= 1000000) {
            return interaction.editReply({
                content: "V-Bucks amount is out of valid range after the update.",
                ephemeral: true
            });
        }

        const embed = new MessageEmbed()
            .setTitle("V-Bucks Updated")
            .setDescription(`Successfully removed **${vbucks}** V-Bucks from <@${selectedUserId}>`)
            .setThumbnail("")
            .setColor("GREEN")
            .setFooter({
                text: "Vorza",
                iconURL: ""
            })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed], ephemeral: true });

        return { newQuantityCommonCore: newVbucks, newQuantityProfile0: newVbucks };
    }
};