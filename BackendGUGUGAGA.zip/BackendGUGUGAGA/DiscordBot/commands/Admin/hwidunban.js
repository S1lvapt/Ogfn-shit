const { MessageEmbed } = require("discord.js");
const HWIDBan = require("../../../model/hwidbans.js");

module.exports = {
    commandInfo: {
        name: "hwidunban",
        description: "Remove a hardware ID ban",
        options: [
            {
                name: "username",
                description: "The username to unban",
                required: true,
                type: 3 // string
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const config = require('../../../Config');
        const { moderators } = config;

        if (!moderators.includes(interaction.user.id)) {
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription("You do not have moderator permissions.")
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }

        const username = interaction.options.getString("username");

        try {
            // Find ban by username
            const ban = await HWIDBan.findOne({ username });

            if (!ban) {
                const embed = new MessageEmbed()
                    .setTitle("Error")
                    .setDescription(`No HWID ban found for user **${username}**.`)
                    .setColor("RED")
                    .setFooter({ text: "Vorza", iconURL: "" })
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed], ephemeral: true });
            }

            // Remove ban
            await HWIDBan.deleteOne({ _id: ban._id });

            const embed = new MessageEmbed()
                .setTitle("✅ HWID Unbanned Successfully")
                .setDescription(`**${username}** has been hardware unbanned!`)
                .addField("Account ID", ban.accountId, true)
                .addField("HWID", ban.hwid.substring(0, 12) + "...", true)
                .addField("Was Banned For", ban.reason)
                .addField("Originally Banned By", ban.bannedBy)
                .addField("Unbanned By", interaction.user.username)
                .setColor("GREEN")
                .setFooter({ text: "User can now login again", iconURL: "" })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error(error);
            const embed = new MessageEmbed()
                .setTitle("Error")
                .setDescription(`Failed to unban HWID: ${error.message}`)
                .setColor("RED")
                .setFooter({ text: "Vorza", iconURL: "" })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed], ephemeral: true });
        }
    }
};
