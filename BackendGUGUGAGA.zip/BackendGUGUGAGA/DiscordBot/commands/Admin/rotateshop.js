const { MessageEmbed } = require("discord.js");
const fs = require("fs");

module.exports = {
    commandInfo: {
        name: "rotateshop",
        description: "Manually rotate the item shop immediately.",
        options: []
    },
    execute: async (interaction) => {
        try {
            await interaction.deferReply({ ephemeral: true });

            const config = JSON.parse(fs.readFileSync("./Config/config.json").toString());

            if (!config.moderators.includes(interaction.user.id)) {
                return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
            }

            const loadingEmbed = new MessageEmbed()
                .setTitle("?? Rotating Shop...")
                .setDescription("Generating new item shop, please wait...")
                .setColor("YELLOW")
                .setFooter({ text: "Vorza" })
                .setTimestamp();

            await interaction.editReply({ embeds: [loadingEmbed], ephemeral: true });

            // Call the autorotate module's rotateNow export
            const autorotate = require("../../../structs/autorotate.js");
            await autorotate.rotateNow();

            const successEmbed = new MessageEmbed()
                .setTitle("? Shop Rotated!")
                .setDescription("The item shop has been successfully rotated.\nPlayers will see the new shop next time they open it.")
                .setColor("GREEN")
                .setFooter({ text: "Vorza" })
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed], ephemeral: true });

        } catch (error) {
            console.error("Rotateshop command error:", error);
            try {
                const errorEmbed = new MessageEmbed()
                    .setTitle("? Rotation Failed")
                    .setDescription(`An error occurred while rotating the shop:\n\`${error.message}\``)
                    .setColor("RED")
                    .setFooter({ text: "Vorza" })
                    .setTimestamp();

                await interaction.editReply({ embeds: [errorEmbed], ephemeral: true });
            } catch (e) {
                console.error("Failed to send error reply:", e);
            }
        }
    }
};