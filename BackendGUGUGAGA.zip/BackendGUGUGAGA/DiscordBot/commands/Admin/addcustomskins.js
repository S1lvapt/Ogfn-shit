const { MessageEmbed } = require("discord.js");
const path = require("path");
const fs = require("fs");
const Users = require('../../../model/user.js');
const Profiles = require('../../../model/profiles.js');
const log = require("../../../structs/log.js");
const config = require('../../../Config/config.json');

module.exports = {
    commandInfo: {
        name: "addcustomskins",
        description: "Gives all custom .pak skins to a user",
        options: [
            {
                name: "user",
                description: "The user you want to give the custom skins to",
                required: true,
                type: 6
            }
        ]
    },
    execute: async (interaction) => {
        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.reply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const selectedUser = interaction.options.getUser('user');
        const selectedUserId = selectedUser?.id;

        try {
            const targetUser = await Users.findOne({ discordId: selectedUserId });
            if (!targetUser) {
                return interaction.editReply({ content: "That user does not own an account" });
            }

            const profile = await Profiles.findOne({ accountId: targetUser.accountId });
            if (!profile) {
                return interaction.editReply({ content: "That user does not have a profile" });
            }

            const customSkinsPath = path.join(__dirname, "../../../Config/customskins.json");
            if (!fs.existsSync(customSkinsPath)) {
                return interaction.editReply({ content: "customskins.json not found in Config folder." });
            }

            const customSkinIds = JSON.parse(fs.readFileSync(customSkinsPath, 'utf8'));
            if (!Array.isArray(customSkinIds) || customSkinIds.length === 0) {
                return interaction.editReply({ content: "No custom skins configured in customskins.json." });
            }

            const athena = profile.profiles.athena;
            let addedCount = 0;

            for (const templateId of customSkinIds) {
                const itemKey = templateId;

                if (athena.items[itemKey]) continue;

                athena.items[itemKey] = {
                    templateId: templateId,
                    attributes: {
                        max_level_bonus: 0,
                        level: 1,
                        item_seen: true,
                        xp: 0,
                        variants: [],
                        favorite: false
                    },
                    quantity: 1
                };
                addedCount++;
            }

            if (addedCount === 0) {
                return interaction.editReply({ content: "That user already has all custom skins." });
            }

            athena.rvn++;
            athena.commandRevision++;
            athena.updated = new Date().toISOString();

            await Profiles.updateOne(
                { accountId: targetUser.accountId },
                { $set: { 'profiles.athena': athena } }
            );

            const embed = new MessageEmbed()
                .setTitle("Custom Skins Added")
                .setDescription(`Successfully added **${addedCount}** custom skins to **${selectedUser.username}**`)
                .setColor("GREEN")
                .setFooter({
                    text: "Restart the game to see the changes",
                    iconURL: "",
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            log.error("An error occurred:", error);
            interaction.editReply({ content: "An error occurred while processing the request." });
        }
    }
};
