const User = require("../../../model/user.js");
const { MessageEmbed } = require("discord.js");
const fs = require("fs");

module.exports = {
    commandInfo: {
        name: "admin",
        description: "Grant or revoke admin privileges for a user.",
        options: [
            {
                name: "user",
                description: "The Discord user to update.",
                required: true,
                type: 6
            },
            {
                name: "give",
                description: "Give admin (True) or remove admin (False).",
                required: true,
                type: 5
            }
        ]
    },
    execute: async (interaction) => {
        try {
            await interaction.deferReply({ ephemeral: true });

            // Load config fresh each time
            const config = JSON.parse(fs.readFileSync("./Config/config.json").toString());

            if (!config.moderators.includes(interaction.user.id)) {
                return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
            }

            const selectedUser = interaction.options.getUser("user");
            const adminStatus = interaction.options.getBoolean("give");

            if (!selectedUser) {
                return interaction.editReply({ content: "Please mention a valid user.", ephemeral: true });
            }

            if (adminStatus === null || adminStatus === undefined) {
                return interaction.editReply({ content: "Please select True or False.", ephemeral: true });
            }

            const targetUser = await User.findOne({ discordId: selectedUser.id });

            if (!targetUser) {
                return interaction.editReply({ content: "That user does not have a Vorza account.", ephemeral: true });
            }

            const currentAdminStatus = targetUser.isAdmin === true;

            if (currentAdminStatus === adminStatus) {
                const statusText = adminStatus ? "already an admin" : "not an admin";
                return interaction.editReply({ content: `**${targetUser.username}** is ${statusText}.`, ephemeral: true });
            }

            await User.updateOne({ discordId: selectedUser.id }, { $set: { isAdmin: adminStatus } });

            const actionText = adminStatus ? "granted admin privileges to" : "revoked admin privileges from";

            const embed = new MessageEmbed()
                .setTitle("Admin Status Updated")
                .setDescription(`Successfully ${actionText} **${targetUser.username}** (<@${selectedUser.id}>).`)
                .setColor(adminStatus ? "GREEN" : "RED")
                .setFooter({ text: "Vorza" })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            console.error("Admin command error:", error);
            try {
                await interaction.editReply({ content: `Error: ${error.message}`, ephemeral: true });
            } catch (e) {
                console.error("Failed to send error reply:", e);
            }
        }
    }
}
