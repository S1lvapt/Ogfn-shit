const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const fs   = require("fs");
const path = require("path");

const CONFIG_PATH = path.resolve(__dirname, "../../Config/config.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("gameserver")
        .setDescription("Liga ou desliga um servidor de jogo")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addStringOption(opt =>
            opt.setName("id")
                .setDescription("ID do servidor (ex: gs-001)")
                .setRequired(true)
        )
        .addStringOption(opt =>
            opt.setName("estado")
                .setDescription("Ligar ou desligar o servidor")
                .setRequired(true)
                .addChoices(
                    { name: "🟢 Ligar",   value: "on"  },
                    { name: "🔴 Desligar", value: "off" }
                )
        ),

    async execute(interaction) {
        const serverId = interaction.options.getString("id");
        const estado   = interaction.options.getString("estado");
        const enabled  = estado === "on";

        try {
            // Lê config actual
            const raw    = fs.readFileSync(CONFIG_PATH, "utf8");
            const config = JSON.parse(raw);

            if (!config.gameServers || !Array.isArray(config.gameServers)) {
                return interaction.reply({ content: "❌ Nenhum gameServer configurado.", ephemeral: true });
            }

            const server = config.gameServers.find(s => s.id === serverId);
            if (!server) {
                const ids = config.gameServers.map(s => s.id).join(", ");
                return interaction.reply({ content: `❌ Servidor \`${serverId}\` não encontrado.\nServidores disponíveis: \`${ids}\``, ephemeral: true });
            }

            const wasEnabled = server.enabled === true;
            if (wasEnabled === enabled) {
                return interaction.reply({
                    content: `ℹ️ O servidor \`${serverId}\` já está ${enabled ? "ligado 🟢" : "desligado 🔴"}.`,
                    ephemeral: true
                });
            }

            // Actualiza o enabled
            server.enabled = enabled;

            // Escreve o config de volta (com formatação)
            fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 4), "utf8");

            const embed = new EmbedBuilder()
                .setTitle(enabled ? "🟢 Servidor Ligado" : "🔴 Servidor Desligado")
                .setColor(enabled ? 0x00ff00 : 0xff0000)
                .addFields(
                    { name: "Servidor",  value: `\`${serverId}\``,                inline: true },
                    { name: "IP",        value: `\`${server.ip}:${server.port}\``, inline: true },
                    { name: "Playlists", value: server.playlists?.join(", ") || "N/A", inline: false },
                    { name: "Estado",    value: enabled
                        ? "✅ Online — jogadores podem entrar"
                        : "❌ Offline — jogadores ficam em Finding Match",
                        inline: false
                    }
                )
                .setFooter({ text: "Vorza Matchmaking" })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (err) {
            console.error("[gameserver cmd] Erro:", err);
            await interaction.reply({ content: `❌ Erro: ${err.message}`, ephemeral: true });
        }
    }
};
