const Users = require('../../../model/user');
const Profiles = require('../../../model/profiles');
const { MessageEmbed } = require('discord.js');
const config = require('../../../Config/config.json');
const fs = require('fs');
const path = require('path');

module.exports = {
    commandInfo: {
        name: "set-donator",
        description: "Set or unset donator flags on a user (optionally apply benefits).",
        options: [
            {
                name: "user",
                description: "The target user (mention or Discord ID)",
                required: true,
                type: 6
            },
            {
                name: "type",
                description: "Which donator flag: basic, medium, high, ultimate",
                required: true,
                type: 3,
                choices: [
                    { name: "Basic (Green name + Priority MM)", value: "basic" },
                    { name: "Medium (Blue + 5k VBucks)", value: "medium" },
                    { name: "High (Orange + Skins + 2k VBucks)", value: "high" },
                    { name: "Ultimate (Purple + All + 10k VBucks)", value: "ultimate" }
                ]
            },
            {
                name: "value",
                description: "on or off",
                required: true,
                type: 3,
                choices: [
                    { name: "On", value: "on" },
                    { name: "Off", value: "off" }
                ]
            },
            {
                name: "apply_benefits",
                description: "Also give the tier benefits (vbucks, skins)?",
                required: false,
                type: 5 // Boolean
            }
        ]
    },
    execute: async (interaction) => {
        await interaction.deferReply({ ephemeral: false });

        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.editReply({ content: "You do not have moderator permissions.", ephemeral: true });
        }

        const selectedUser = interaction.options.getUser('user');
        const type = interaction.options.getString('type')?.toLowerCase();
        const value = interaction.options.getString('value')?.toLowerCase();
        const applyBenefits = interaction.options.getBoolean('apply_benefits') || false;

        if (!selectedUser) return interaction.editReply({ content: "Invalid user specified.", ephemeral: true });
        if (!['basic','donator','medium','high','ultimate'].includes(type)) return interaction.editReply({ content: "Type must be one of: basic, medium, high, ultimate.", ephemeral: true });
        if (!['on','off'].includes(value)) return interaction.editReply({ content: "Value must be 'on' or 'off'.", ephemeral: true });

        const user = await Users.findOne({ discordId: selectedUser.id }) || await Users.findOne({ username: selectedUser.username });
        if (!user) return interaction.editReply({ content: "That user does not own an account.", ephemeral: true });

        const update = {};
        const benefits = [];

        // Set donator flags (cascading for higher tiers)
        // Benefits are PERMANENT - we only add, never remove
        const now = new Date();

        if (value === 'on') {
            switch (type) {
                case 'ultimate':
                    update.ultimateDonator = true;
                    update.highDonator = true;
                    update.mediumDonator = true;
                    update.basicDonator = true;
                    update.donator = true;
                    if (!user.donatorSince?.ultimate) update['donatorSince.ultimate'] = now;
                    break;
                case 'high':
                    update.highDonator = true;
                    update.mediumDonator = true;
                    update.basicDonator = true;
                    update.donator = true;
                    if (!user.donatorSince?.high) update['donatorSince.high'] = now;
                    break;
                case 'medium':
                    update.mediumDonator = true;
                    update.basicDonator = true;
                    update.donator = true;
                    if (!user.donatorSince?.medium) update['donatorSince.medium'] = now;
                    break;
                case 'basic':
                case 'donator':
                    update.basicDonator = true;
                    update.donator = true;
                    if (!user.donatorSince?.basic) update['donatorSince.basic'] = now;
                    break;
            }
        } else {
            // When turning off - WARNING: this removes the tier (use with caution)
            if (type === 'basic' || type === 'donator') {
                update.basicDonator = false;
                update.donator = false;
                update.mediumDonator = false;
                update.highDonator = false;
                update.ultimateDonator = false;
            }
            if (type === 'medium') {
                update.mediumDonator = false;
                update.highDonator = false;
                update.ultimateDonator = false;
            }
            if (type === 'high') {
                update.highDonator = false;
                update.ultimateDonator = false;
            }
            if (type === 'ultimate') update.ultimateDonator = false;
        }

        // Apply benefits if requested and value is 'on'
        if (applyBenefits && value === 'on') {
            try {
                if (type === 'medium' || type === 'high' || type === 'ultimate') {
                    let vbucksAmount = 0;
                    if (type === 'medium') vbucksAmount = 5000;
                    if (type === 'high') vbucksAmount = 2000;
                    if (type === 'ultimate') vbucksAmount = 10000;

                    update.vbucks = (user.vbucks || 0) + vbucksAmount;
                    // V-Bucks s� no User � n�o escrever no Profile
                    benefits.push(`+${vbucksAmount.toLocaleString()} V-Bucks`);
                }

                if (type === 'high' || type === 'ultimate') {
                    let skinsProfile;
                    const highAthenaPath = path.join(__dirname, '../../../Config/DefaultProfiles/highathena.json');
                    const allAthenaPath = path.join(__dirname, '../../../Config/DefaultProfiles/allathena.json');

                    if (type === 'high' && fs.existsSync(highAthenaPath)) {
                        skinsProfile = JSON.parse(fs.readFileSync(highAthenaPath, 'utf8'));
                        benefits.push("ALL Skins (including Series)");
                    } else if (fs.existsSync(allAthenaPath)) {
                        skinsProfile = JSON.parse(fs.readFileSync(allAthenaPath, 'utf8'));
                        benefits.push("All cosmetics");
                    }

                    if (skinsProfile) {
                        await Profiles.updateOne(
                            { accountId: user.accountId },
                            { $set: { 'profiles.athena': skinsProfile } }
                        );
                    }
                }

                benefits.push("Priority Matchmaking");
            } catch (error) {
                console.error('Error applying benefits:', error);
            }
        }

        await user.updateOne({ $set: update });

        const tierColors = {
            basic: '#4CAF50',
            donator: '#4CAF50',
            medium: '#2196F3',
            high: '#FF9800',
            ultimate: '#9C27B0'
        };

        const embed = new MessageEmbed()
            .setTitle("Donator Status Updated")
            .setDescription(`Updated **${type}** to **${value}** for <@${selectedUser.id}>`)
            .setColor(value === 'on' ? tierColors[type] : 'RED')
            .setTimestamp();

        if (benefits.length > 0) {
            embed.addField("Benefits Applied:", benefits.map(b => `� ${b}`).join('\n'));
        }

        await interaction.editReply({ embeds: [embed] });
    }
};