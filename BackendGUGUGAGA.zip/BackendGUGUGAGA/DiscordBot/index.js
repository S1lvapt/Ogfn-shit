const { Client, Intents, MessageEmbed } = require("discord.js");
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_BANS] });
const fs = require("fs");
const path = require("path");
const config = require('../Config');
const log = require("../structs/log.js");
const Users = require("../model/user.js");
const { checkAndCleanupDiscord } = require("../structs/discord_auto_cleanup.js");

client.once("ready", async () => {
   

    // Auto cleanup - limpa cache se comandos mudaram
    await checkAndCleanupDiscord(client);

    if (config.bEnableBackendStatus) {
        if (!config.bBackendStatusChannelId || config.bBackendStatusChannelId.trim() === "") {
            log.error("The channel ID has not been set in config.json for bEnableBackendStatus.");
        } else {
            const channel = client.channels.cache.get(config.bBackendStatusChannelId);
            if (!channel) {
                log.error(`Cannot find the channel with ID ${config.bBackendStatusChannelId}`);
            } else {
                const embed = new MessageEmbed()
                    .setTitle("Backend Online")
                    .setDescription("Vorza is now online")
                    .setColor("GREEN")
                    .setFooter({
                        text: "Vorza",
                        iconURL: "",
                    })
                    .setTimestamp();

                channel.send({ embeds: [embed] }).catch(err => {
                    log.error(err);
                });
            }
        }
    }

    if (config.discord.bEnableInGamePlayerCount) {
        function updateBotStatus() {
            if (global.Clients && Array.isArray(global.Clients)) {
                client.user.setActivity(`${global.Clients.length} player(s)`, { type: "WATCHING" });
            }
        }

        updateBotStatus();
        setInterval(updateBotStatus, 10000);
    }

    let commands = client.application.commands;

    const loadCommands = async (dir) => {
        const files = fs.readdirSync(dir);
        for (const file of files) {
            const filePath = path.join(dir, file);
            if (fs.lstatSync(filePath).isDirectory()) {
                await loadCommands(filePath);
            } else if (file.endsWith(".js")) {
                try {
                    const command = require(filePath);
                    await commands.create(command.commandInfo);
                    log.bot("Registered command: " + command.commandInfo.name);
                } catch (e) {
                    log.error("Failed to register command " + file + ": " + e.message);
                }
            }
        }
    };

    await loadCommands(path.join(__dirname, "commands"));
    log.bot("All commands registered!");
});

client.on("interactionCreate", async interaction => {
    if (!interaction.isApplicationCommand()) return;

    const executeCommand = (dir, commandName) => {
        const commandPath = path.join(dir, commandName + ".js");
        if (fs.existsSync(commandPath)) {
            require(commandPath).execute(interaction);
            return true;
        }
        const subdirectories = fs.readdirSync(dir).filter(subdir => fs.lstatSync(path.join(dir, subdir)).isDirectory());
        for (const subdir of subdirectories) {
            if (executeCommand(path.join(dir, subdir), commandName)) {
                return true;
            }
        }
        return false;
    };

    executeCommand(path.join(__dirname, "commands"), interaction.commandName);
});

client.on("guildBanAdd", async (ban) => {
    if (!config.bEnableCrossBans) 
        return;

    const memberBan = await ban.fetch();

    if (memberBan.user.bot)
        return;

    const userData = await Users.findOne({ discordId: memberBan.user.id });

    if (userData && userData.banned !== true) {
        await userData.updateOne({ $set: { banned: true } });

        let refreshToken = global.refreshTokens.findIndex(i => i.accountId == userData.accountId);

        if (refreshToken != -1)
            global.refreshTokens.splice(refreshToken, 1);
        let accessToken = global.accessTokens.findIndex(i => i.accountId == userData.accountId);

        if (accessToken != -1) {
            global.accessTokens.splice(accessToken, 1);
            let xmppClient = global.Clients.find(client => client.accountId == userData.accountId);
            if (xmppClient)
                xmppClient.client.close();
        }

        if (accessToken != -1 || refreshToken != -1) {
            await functions.UpdateTokens();
        }

        log.debug(`user ${memberBan.user.username} (ID: ${memberBan.user.id}) was banned on the discord and also in the game (Cross Ban active).`);
    }
});

client.on("guildBanRemove", async (ban) => {
    if (!config.bEnableCrossBans)
        return;

    if (ban.user.bot)
        return;

    const userData = await Users.findOne({ discordId: ban.user.id });

    if (userData && userData.banned === true) {
        await userData.updateOne({ $set: { banned: false } });

        log.debug(`User ${ban.user.username} (ID: ${ban.user.id}) is now unbanned.`);
    }
});

// Donator role sync - when someone gets a donator role
// This runs AUTOMATICALLY when someone buys a donation and gets the role
// BENEFITS ARE PERMANENT - they are never removed even if user leaves Discord
client.on("guildMemberUpdate", async (oldMember, newMember) => {
    // Debug log to confirm event is firing
    log.bot(`[DONATE] guildMemberUpdate event fired for ${newMember.user.username} (${newMember.id})`);

    try {
        if (!config.discord.donatorRoles) {
            log.bot("[DONATE] donatorRoles not configured in config.json");
            return;
        }

        const roles = config.discord.donatorRoles;
        const oldRoles = oldMember.roles.cache;
        const newRoles = newMember.roles.cache;

        // Debug: Log role IDs being checked
        log.bot(`[DONATE] Checking roles for ${newMember.user.username} (${newMember.id})`);
        log.bot(`[DONATE] Config role IDs - Basic: ${roles.basic}, Medium: ${roles.medium}, High: ${roles.high}, Ultimate: ${roles.ultimate}`);

        // Check if any donator role was ADDED (we ignore removals - benefits are permanent)
        const basicAdded = roles.basic && !oldRoles.has(roles.basic) && newRoles.has(roles.basic);
        const mediumAdded = roles.medium && !oldRoles.has(roles.medium) && newRoles.has(roles.medium);
        const highAdded = roles.high && !oldRoles.has(roles.high) && newRoles.has(roles.high);
        const ultimateAdded = roles.ultimate && !oldRoles.has(roles.ultimate) && newRoles.has(roles.ultimate);

        log.bot(`[DONATE] Role changes - Basic: ${basicAdded}, Medium: ${mediumAdded}, High: ${highAdded}, Ultimate: ${ultimateAdded}`);

        // Only process if a donator role was ADDED
        if (!basicAdded && !mediumAdded && !highAdded && !ultimateAdded) {
            log.bot(`[DONATE] No donator role was added for ${newMember.user.username}`);
            return;
        }

        const userData = await Users.findOne({ discordId: newMember.id });
        if (!userData) {
            log.bot(`[DONATE] User ${newMember.user.username} (Discord ID: ${newMember.id}) got donator role but has no linked account!`);
            // Try to notify the user
            try {
                await newMember.send(`You received a donator role but your Discord account is not linked to a Vorza account. Please login to Vorza with Discord to receive your benefits!`);
            } catch (e) {}
            return;
        }

        log.bot(`[DONATE] Found user account: ${userData.username} (${userData.accountId})`);

    const Profile = require("../model/profiles.js");
    const fs = require("fs");

    const update = {};
    const benefits = [];
    const now = new Date();

    // Initialize benefitsGiven if it doesn't exist
    const benefitsGiven = userData.benefitsGiven || { basic: false, medium: false, high: false, ultimate: false };
    const donatorSince = userData.donatorSince || { basic: null, medium: null, high: null, ultimate: null };

    // BASIC DONATE: Priority Matchmaking + Green name
    if (basicAdded && !benefitsGiven.basic) {
        update.basicDonator = true;
        update.donator = true; // Legacy compatibility
        update['benefitsGiven.basic'] = true;
        update['donatorSince.basic'] = now;

        benefits.push("Priority Matchmaking");
        benefits.push("Green name in launcher");
        log.bot(`[DONATE] Activated Basic Donator for ${newMember.user.username}`);
    }

    // MEDIUM DONATE: +5000 V-Bucks + Blue name + Priority MM
    if (mediumAdded && !benefitsGiven.medium) {
        update.mediumDonator = true;
        update.basicDonator = true;
        update.donator = true;
        update['benefitsGiven.medium'] = true;
        update['donatorSince.medium'] = now;
        update.vbucks = (userData.vbucks || 0) + 5000;
        // V-Bucks s  no User   n o escrever no Profile

        benefits.push("+5,000 V-Bucks");
        benefits.push("Priority Matchmaking");
        benefits.push("Blue name in launcher");
        log.bot(`[DONATE] Gave 5000 V-Bucks to ${newMember.user.username} (Medium Donator)`);
    }

    // HIGH DONATE: ALL SKINS (including Series) but NO pickaxes/gliders/dances/backpacks + 2000 V-Bucks + Orange name
    if (highAdded && !benefitsGiven.high) {
        update.highDonator = true;
        update.mediumDonator = true;
        update.basicDonator = true;
        update.donator = true;
        update['benefitsGiven.high'] = true;
        update['donatorSince.high'] = now;
        update.vbucks = (userData.vbucks || 0) + 2000;
        // V-Bucks s  no User   n o escrever no Profile
        benefits.push("+2,000 V-Bucks");

        // Give ALL SKINS (including Series) but NO pickaxes, gliders, dances, backpacks, etc.
        try {
            const highPath = './Config/DefaultProfiles/highathena.json';

            if (fs.existsSync(highPath)) {
                const skinProfile = JSON.parse(fs.readFileSync(highPath, 'utf8'));
                await Profile.updateOne(
                    { accountId: userData.accountId },
                    { $set: { 'profiles.athena': skinProfile } }
                );
                benefits.push("ALL Skins (including Series)");
                benefits.push("(No pickaxes, gliders, dances, backpacks)");
            } else {
                log.error(`[DONATE] highathena.json not found! Run: node scripts/generateHighAthena.js`);
            }

            benefits.push("Orange name in launcher");
            log.bot(`[DONATE] Gave ALL skins + 2000 V-Bucks to ${newMember.user.username} (High Donator)`);
        } catch (err) {
            log.error(`Failed to give skins to High Donator: ${err.message}`);
        }
    }

    // ULTIMATE DONATE: ALL cosmetics (skins, pickaxes, dances, backpacks, EVERYTHING) + 10000 V-Bucks + Purple name + Priority MM
    if (ultimateAdded && !benefitsGiven.ultimate) {
        update.ultimateDonator = true;
        update.highDonator = true;
        update.mediumDonator = true;
        update.basicDonator = true;
        update.donator = true;
        update['benefitsGiven.ultimate'] = true;
        update['donatorSince.ultimate'] = now;
        update.vbucks = (userData.vbucks || 0) + 10000;
        // V-Bucks s  no User   n o escrever no Profile
        benefits.push("+10,000 V-Bucks");

        // Give ALL cosmetics (skins, pickaxes, dances, backpacks, gliders, emotes, wraps, etc.)
        try {
            const allPath = './Config/DefaultProfiles/allathena.json';
            if (fs.existsSync(allPath)) {
                const allAthena = JSON.parse(fs.readFileSync(allPath, 'utf8'));
                await Profile.updateOne(
                    { accountId: userData.accountId },
                    { $set: { 'profiles.athena': allAthena } }
                );
                benefits.push("ALL Cosmetics (Skins, Pickaxes, Dances, Backpacks, Gliders, Emotes, Wraps...)");
            }
            benefits.push("Priority Matchmaking");
            benefits.push("Purple name in launcher");
            log.bot(`[DONATE] Gave ALL cosmetics + 10000 V-Bucks to ${newMember.user.username} (Ultimate Donator)`);
        } catch (err) {
            log.error(`Failed to give cosmetics to Ultimate Donator: ${err.message}`);
        }
    }

    // Save all updates to database
    if (Object.keys(update).length > 0) {
        await userData.updateOne({ $set: update });
    }

    // Send DM to user confirming their benefits
    if (benefits.length > 0) {
        try {
            const tierName = ultimateAdded ? "Ultimate" : highAdded ? "High" : mediumAdded ? "Medium" : "Basic";
            const tierColor = ultimateAdded ? 0x9C27B0 : highAdded ? 0xFF9800 : mediumAdded ? 0x2196F3 : 0x4CAF50;

            const embed = new MessageEmbed()
                .setTitle(`Thank you for your donation!`)
                .setDescription(`You are now a **${tierName} Donator**!\n\nYour benefits are **permanent** and will never be removed.`)
                .addField("Your Benefits:", benefits.map(b => `  ${b}`).join('\n'))
                .setColor(tierColor)
                .setFooter({ text: "Restart your game to see the changes!" })
                .setTimestamp();

            await newMember.send({ embeds: [embed] }).catch(() => {
                // User has DMs disabled, ignore
            });
        } catch (err) {
            // Failed to send DM, not critical
        }

        log.bot(`[DONATE] Benefits given to ${newMember.user.username}: ${benefits.join(', ')}`);
    } else {
        log.bot(`[DONATE] No new benefits to give to ${newMember.user.username} (already received)`);
    }
    } catch (error) {
        log.error(`[DONATE] Error processing donator role: ${error.message}`);
        console.error(error);
    }
});

//AntiCrash System
client.on("error", (err) => {
    console.log("Discord API Error:", err);
});
  
process.on("unhandledRejection", (reason, p) => {
    console.log("Unhandled promise rejection:", reason, p);
});
  
process.on("uncaughtException", (err, origin) => {
    console.log("Uncaught Exception:", err, origin);
});
  
process.on("uncaughtExceptionMonitor", (err, origin) => {
    console.log("Uncaught Exception Monitor:", err, origin);
});

client.login(config.discord.bot_token);