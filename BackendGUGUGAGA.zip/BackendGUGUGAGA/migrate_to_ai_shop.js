const fs = require('fs');
const path = require('path');


const oldAutoRotatePath = path.join(__dirname, 'structs', 'autorotate.js');
const backupPath = path.join(__dirname, 'structs', 'autorotate.js.backup');

try {
    if (fs.existsSync(oldAutoRotatePath)) {
        fs.copyFileSync(oldAutoRotatePath, backupPath);
    }
} catch (err) {
    console.error('✗ Error creating backup:', err.message);
}

// 2. Substituir autorotate.js pelo nov
const newAutoRotatePath = path.join(__dirname, 'structs', 'autorotate_v2.js');

try {
    if (fs.existsSync(newAutoRotatePath)) {
        fs.copyFileSync(newAutoRotatePath, oldAutoRotatePath);

    } else {
        console.error('✗ autorotate_v2.js not found!');
    }
} catch (err) {
    console.error('✗ Error replacing file:', err.message);
}

const smartShopPath = path.join(__dirname, 'structs', 'smart_shop_ai.js');

if (fs.existsSync(smartShopPath)) {
} else {
    console.error('✗ smart_shop_ai.js not found!');
}

const healthMonitorPath = path.join(__dirname, 'structs', 'health_monitor.js');

if (fs.existsSync(healthMonitorPath)) {
} else {
    console.error('✗ health_monitor.js not found!');
}

const configPath = path.join(__dirname, 'Config', 'config.json');

try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

    // Atualizar configurações para mais itens
    if (config.bDailyItemsAmount < 12) {
        config.bDailyItemsAmount = 12;
    }

    if (config.bFeaturedItemsAmount < 8) {
        config.bFeaturedItemsAmount = 8;
    }

    // Adicionar nova configuração se não existir
    if (!config.bWeeklyItemsAmount) {
        config.bWeeklyItemsAmount = 6;
    }

    // Salvar config atualizado
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

} catch (err) {
}

// 6. Adicionar integração com health monitor no index.js
const indexPath = path.join(__dirname, 'index.js');

try {
    let indexContent = fs.readFileSync(indexPath, 'utf-8');

    // Verificar se já tem o health monitor
    if (!indexContent.includes('health_monitor')) {
        // Adicionar import do health monitor após outros requires
        const requireLine = 'const AutoBackendRestart = require("./structs/autobackendrestart.js");';
        const newRequire = requireLine + '\nconst healthMonitor = require("./structs/health_monitor.js");';

        indexContent = indexContent.replace(requireLine, newRequire);

        // Adicionar inicialização do health monitor após MongoDB connect
        const mongooseLine = 'mongoose.connect(config.mongodb.database, () => {';
        const healthStart = mongooseLine + '\n    log.backend("App successfully connected to MongoDB!");\n    \n    // Start health monitor\n    healthMonitor.start();';

        indexContent = indexContent.replace(
            mongooseLine + '\n    log.backend("App successfully connected to MongoDB!");',
            healthStart
        );

        fs.writeFileSync(indexPath, indexContent);
    } else {
    }

} catch (err) {
}

try {
} catch (err) {
}

