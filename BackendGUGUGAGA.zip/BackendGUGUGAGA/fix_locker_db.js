/**
 * fix_locker_db.js
 * 
 * Corre este script UMA VEZ para reparar todos os perfis athena
 * que t�m o active_loadout_index a apontar para um loadout inexistente.
 * 
 * Como usar:
 *   node fix_locker_db.js
 */

const mongoose = require("mongoose");

async function main() {
    await mongoose.connect("mongodb+srv://salvador:KcoBAKsrp485556K@cluster0.fflunyb.mongodb.net/?appName=Cluster0");
    console.log("Conectado ao MongoDB");

    const Profile = require("./model/profiles");
    const all = await Profile.find({});
    console.log(`A verificar ${all.length} perfis...`);

    let fixed = 0;

    for (const doc of all) {
        let dirty = false;
        const athena = doc.profiles && doc.profiles["athena"];
        if (!athena) continue;

        if (!athena.items) { athena.items = {}; dirty = true; }

        // 1. Garantir que sandbox_loadout existe
        if (!athena.items["sandbox_loadout"]) {
            athena.items["sandbox_loadout"] = {
                "templateId": "CosmeticLocker:cosmeticlocker_athena",
                "attributes": {
                    "locker_slots_data": { "slots": {
                        "Character":       { "items": ["AthenaCharacter:CID_001_Athena_Commando_F_Default"], "activeVariants": [{"variants":[]}] },
                        "Backpack":        { "items": [""], "activeVariants": [{"variants":[]}] },
                        "SkyDiveContrail": { "items": [""], "activeVariants": [{"variants":[]}] },
                        "Pickaxe":         { "items": ["AthenaPickaxe:DefaultPickaxe"], "activeVariants": [{"variants":[]}] },
                        "Glider":          { "items": ["AthenaGlider:DefaultGlider"], "activeVariants": [{"variants":[]}] },
                        "Dance":           { "items": ["","","","","",""], "activeVariants": [{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]}] },
                        "ItemWrap":        { "items": ["","","","","","",""], "activeVariants": [{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]},{"variants":[]}] },
                        "MusicPack":       { "items": [""], "activeVariants": [{"variants":[]}] },
                        "LoadingScreen":   { "items": [""], "activeVariants": [{"variants":[]}] }
                    }},
                    "use_count": 0, "banner_icon_template": "", "banner_color_template": "",
                    "locker_name": "Preset 1", "item_seen": true, "favorite": false
                },
                "quantity": 1
            };
            dirty = true;
        } else {
            // Reparar null nos activeVariants
            const slots = athena.items["sandbox_loadout"].attributes.locker_slots_data.slots;
            for (const sn of ["Character","Backpack","SkyDiveContrail","Pickaxe","Glider","Dance","ItemWrap","MusicPack","LoadingScreen"]) {
                if (slots[sn] && slots[sn].activeVariants) {
                    const fixed2 = slots[sn].activeVariants.map(v => (v === null || v === undefined) ? {"variants":[]} : v);
                    if (JSON.stringify(fixed2) !== JSON.stringify(slots[sn].activeVariants)) {
                        slots[sn].activeVariants = fixed2;
                        dirty = true;
                    }
                }
            }
        }

        // 2. Remover loadouts inexistentes
        if (Array.isArray(athena.stats.attributes.loadouts)) {
            const before = athena.stats.attributes.loadouts.join(',');
            athena.stats.attributes.loadouts = athena.stats.attributes.loadouts.filter(id => id && athena.items[id]);
            if (!athena.stats.attributes.loadouts.includes("sandbox_loadout")) {
                athena.stats.attributes.loadouts.unshift("sandbox_loadout");
            }
            if (athena.stats.attributes.loadouts.join(',') !== before) dirty = true;
        } else {
            athena.stats.attributes.loadouts = ["sandbox_loadout"];
            dirty = true;
        }

        // 3. BUG PRINCIPAL: active_loadout_index a apontar para item inexistente
        const idx = athena.stats.attributes.active_loadout_index;
        const currentLoadout = athena.stats.attributes.loadouts[idx];
        if (typeof idx !== "number" || !currentLoadout || !athena.items[currentLoadout]) {
            athena.stats.attributes.active_loadout_index = 0;
            dirty = true;
        }

        // 4. Reparar last_applied_loadout
        if (!athena.stats.attributes.last_applied_loadout ||
            !athena.items[athena.stats.attributes.last_applied_loadout]) {
            athena.stats.attributes.last_applied_loadout = "sandbox_loadout";
            dirty = true;
        }

        // 5. Reparar favorite_itemwraps
        if (!Array.isArray(athena.stats.attributes.favorite_itemwraps) ||
            athena.stats.attributes.favorite_itemwraps.length < 7) {
            athena.stats.attributes.favorite_itemwraps = ["","","","","","",""];
            dirty = true;
        }

        // 6. Reparar favorite_dance
        if (!Array.isArray(athena.stats.attributes.favorite_dance) ||
            athena.stats.attributes.favorite_dance.length < 6) {
            athena.stats.attributes.favorite_dance = ["","","","","",""];
            dirty = true;
        }

        if (dirty) {
            await Profile.updateOne({ accountId: doc.accountId }, { $set: { "profiles.athena": athena } });
            fixed++;
            console.log(`  Reparado: ${doc.accountId}`);
        }
    }

    console.log(`\nConclu�do! Reparados ${fixed}/${all.length} perfis.`);
    await mongoose.disconnect();
}

main().catch(err => { console.error(err); process.exit(1); });