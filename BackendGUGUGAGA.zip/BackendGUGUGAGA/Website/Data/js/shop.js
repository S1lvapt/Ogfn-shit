let shopData = null;

const IMAGE_MAX_RETRIES = 2;
const IMAGE_RETRY_DELAY = 1000;

// Version filtering removed � the backend already serves the correct catalog for the hosted version.
// Filtering here caused valid items to be hidden from the shop website.

const VBUCKS_SVG = `<img src="https://i.imgur.com/wVpIWJK.png" width="20" height="20" alt="V-Bucks" style="vertical-align:middle;">`;

const CUSTOM_ITEM_SVG = `<svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" width="80" height="80">
  <rect width="80" height="80" rx="12" fill="url(#cg)"/>
  <defs>
    <linearGradient id="cg" x1="0" y1="0" x2="80" y2="80" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#2a2a4a"/>
      <stop offset="100%" stop-color="#1a1a2e"/>
    </linearGradient>
  </defs>
  <rect x="20" y="20" width="40" height="40" rx="6" stroke="rgba(103,202,245,0.4)" stroke-width="2" stroke-dasharray="4 3"/>
  <text x="40" y="46" text-anchor="middle" font-size="18" font-weight="bold" font-family="Arial,sans-serif" fill="rgba(103,202,245,0.7)">?</text>
</svg>`;

window.addEventListener('DOMContentLoaded', () => {
  loadShop();
});

function filterShopData(data) {
  // No filtering � show exactly what the server has in the catalog.
  // The backend already serves the correct items for the hosted version.
  return {
    featured: data.featured || [],
    daily: data.daily || [],
  };
}

function retryImageLoad(img) {
  const retries = parseInt(img.dataset.retries || '0');
  const originalSrc = img.dataset.originalSrc;

  if (retries < IMAGE_MAX_RETRIES && originalSrc) {
    img.dataset.retries = retries + 1;
    const spinner = img.previousElementSibling;
    if (spinner && spinner.classList.contains('image-loading-spinner')) {
      spinner.style.display = 'block';
    }
    setTimeout(() => {
      const cacheBuster = `${originalSrc.includes('?') ? '&' : '?'}retry=${retries + 1}&t=${Date.now()}`;
      img.src = originalSrc + cacheBuster;
    }, IMAGE_RETRY_DELAY);
  } else {
    img.style.display = 'none';
    const spinner = img.previousElementSibling;
    if (spinner && spinner.classList.contains('image-loading-spinner')) {
      spinner.style.display = 'none';
    }
    const placeholder = img.nextElementSibling;
    if (placeholder && placeholder.classList.contains('item-image-placeholder')) {
      placeholder.style.display = 'flex';
    }
  }
}

function onImageLoaded(img) {
  img.style.opacity = '1';
  const spinner = img.previousElementSibling;
  if (spinner && spinner.classList.contains('image-loading-spinner')) {
    spinner.style.display = 'none';
  }
}

async function loadShop() {
  const shopContent = document.getElementById('shopContent');

  shopContent.innerHTML = `
    <div class="loading-state">
      <div class="spinner-large"></div>
      <p>Loading shop...</p>
    </div>
  `;

  try {
    const response = await fetch('/api/shop/items');

    if (!response.ok) {
      throw new Error('Failed to load shop');
    }

    const data = await response.json();
    shopData = filterShopData(data);
    renderShop(shopData);
  } catch (error) {
    console.error('Shop error:', error);
    showError('Failed to connect to shop');
  }
}

function renderShop(data) {
  const shopContent = document.getElementById('shopContent');
  let html = '';

  if (data.featured && data.featured.length > 0) {
    html += `
      <div class="shop-section">
        <div class="section-header">
          <div>
            <h2 class="section-title">Vorza</h2>
            <p class="section-subtitle">Premium items available now</p>
          </div>
        </div>
        <div class="items-grid">
          ${data.featured.map(item => renderShopItem(item, true)).join('')}
        </div>
      </div>
    `;
  }

  if (data.daily && data.daily.length > 0) {
    html += `
      <div class="shop-section">
        <div class="section-header">
          <div>
            <h2 class="section-title">Daily Rotation</h2>
            <p class="section-subtitle">Refreshes every 24 hours</p>
          </div>
        </div>
        <div class="items-grid">
          ${data.daily.map(item => renderShopItem(item, false)).join('')}
        </div>
      </div>
    `;
  }

  if (html === '') {
    html = `
      <div class="empty-shop">
        <div class="empty-shop-icon">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="9" cy="21" r="1"/>
            <circle cx="20" cy="21" r="1"/>
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
          </svg>
        </div>
        <h3>Shop is Empty</h3>
        <p>Check back later for new items!</p>
      </div>
    `;
  }

  shopContent.innerHTML = html;
}

function renderShopItem(item, isFeatured) {
  const itemType = getItemType(item.items[0]);
  const rarity = getItemRarity(item.price);
  const spinnerHtml = `<div class="image-loading-spinner"></div>`;

  const imageHtml = item.imageUrl
    ? `${spinnerHtml}
       <img class="item-image" src="${item.imageUrl}" alt="${item.name}"
           style="opacity:0;transition:opacity 0.3s ease;"
           data-original-src="${item.imageUrl}"
           data-retries="0"
           onload="onImageLoaded(this)"
           onerror="retryImageLoad(this)">
       <div class="item-image-placeholder" style="display:none;">${CUSTOM_ITEM_SVG}</div>`
    : `<div class="item-image-placeholder">${CUSTOM_ITEM_SVG}</div>`;

  return `
    <div class="shop-item">
      <div class="item-image-container">
        ${isFeatured ? '<div class="item-featured-badge">FEATURED</div>' : ''}
        ${imageHtml}
      </div>
      <div class="item-info">
        <div class="item-name">${item.name}</div>
        <div class="item-type">${itemType}</div>
        <div class="item-rarity rarity-${rarity}">${rarity}</div>
        <div class="item-footer">
          <div class="item-price">
            ${VBUCKS_SVG}
            ${formatNumber(item.price)}
          </div>
          <div class="item-status"></div>
        </div>
      </div>
    </div>
  `;
}

function getItemType(templateId) {
  if (!templateId) return 'Item';

  const types = {
    'AthenaCharacter': 'Outfit',
    'AthenaBackpack': 'Back Bling',
    'AthenaPickaxe': 'Harvesting Tool',
    'AthenaGlider': 'Glider',
    'AthenaDance': 'Emote',
    'AthenaItemWrap': 'Wrap',
    'AthenaMusicPack': 'Music',
    'AthenaLoadingScreen': 'Loading Screen',
    'AthenaPet': 'Pet',
    'AthenaPetCarrier': 'Pet Carrier',
    'AthenaSpray': 'Spray',
    'AthenaToy': 'Toy',
    'AthenaVictory': 'Victory Pose'
  };

  for (const [key, value] of Object.entries(types)) {
    if (templateId.includes(key)) {
      return value;
    }
  }

  return 'Item';
}

function getItemRarity(price) {
  if (price >= 2000) return 'legendary';
  if (price >= 1500) return 'epic';
  if (price >= 1200) return 'rare';
  if (price >= 800) return 'uncommon';
  return 'common';
}

function formatNumber(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function showError(message) {
  const shopContent = document.getElementById('shopContent');
  shopContent.innerHTML = `
    <div class="error-state">
      <div class="error-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
      </div>
      <h3>Failed to Load Shop</h3>
      <p>${message}</p>
      <button class="retry-btn" onclick="loadShop()">Try Again</button>
    </div>
  `;
}