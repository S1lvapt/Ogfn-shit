/**
 * Matchmaker � adaptado do Rubidium para Node.js
 * 
 * O ticket assina um JWT com global.JWT_SECRET.
 * O matchmaker verifica o JWT extra�do de parts[3] do header Authorization.
 * Se o verify falhar, tenta jwt.decode() (sem verifica��o) como fallback de diagn�stico.
 */

const jwt       = require("jsonwebtoken");
const functions = require("../structs/functions.js");
const log       = require("../structs/log.js");
const config    = require("../Config/config.json");

const ConnectingPlayers = [];
const QueuedPlayers     = {};
const Clients           = [];

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function sendMessage(ws, type, payload) {
    try { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ payload, name: type })); } catch (_) {}
}

function findServer(playlist) {
    if (!Array.isArray(config.gameServers)) return null;
    let s = config.gameServers.find(s =>
        s.enabled !== false &&
        Array.isArray(s.playlists) &&
        s.playlists.some(p => p.toLowerCase() === (playlist || "").toLowerCase())
    );
    if (!s) s = config.gameServers.find(s => s.enabled !== false);
    return s || null;
}

module.exports = async (ws, req) => {
    const authHeader = req?.headers?.authorization || "";
    const parts      = authHeader.split(" ");

    log.backend(`[Matchmaker] Header completo: "${authHeader.substring(0, 200)}"`);
    log.backend(`[Matchmaker] Parts (${parts.length}): ${parts.map((p,i) => `[${i}]="${p.substring(0,40)}"`).join(" | ")}`);

    // Verificar que temos pelo menos 4 partes
    // "Epic-Signed mms-player <accountId/payload> <JWT> [nonce]"
    if (parts.length < 4) {
        log.error(`[Matchmaker] Apenas ${parts.length} partes no header, esperado >= 4`);
        // Tentar continuar com dados m�nimos se poss�vel
        if (parts.length < 2) { ws.close(); return; }
    }

    // Tentar verificar JWT (parts[3])
    let sigData = null;
    const jwtCandidate = parts[3] || "";

    try {
        sigData = jwt.verify(jwtCandidate, global.JWT_SECRET);
        log.backend(`[Matchmaker] JWT verificado OK | accountId: ${sigData.accountId}`);
    } catch (verifyErr) {
        log.error(`[Matchmaker] jwt.verify falhou: ${verifyErr.message}`);
        // Fallback: decode sem verifica��o para diagn�stico
        try {
            sigData = jwt.decode(jwtCandidate);
            if (sigData) {
                log.backend(`[Matchmaker] jwt.decode (sem verify) | accountId: ${sigData.accountId} | playlist: ${sigData.playlist}`);
            } else {
                log.error(`[Matchmaker] jwt.decode retornou null � JWT malformado: "${jwtCandidate.substring(0, 60)}"`);
            }
        } catch (decodeErr) {
            log.error(`[Matchmaker] jwt.decode tamb�m falhou: ${decodeErr.message}`);
        }
        if (!sigData) { ws.close(); return; }
    }

    // Extrair dados do JWT
    const accountId   = sigData.accountId   || parts[2] || "unknown";
    const displayName = sigData.displayName || accountId;
    const playlist    = sigData.playlist    || null;
    const region      = sigData.region      || "EU";
    const hasPriority = !!sigData.hasPriority;
    const partyMembers = sigData.partyMembers || accountId;

    // BucketId com wildcard (como Rubidium)
    let bucketId = sigData.bucketId || `0:*:${region}:${playlist}`;
    const bSplit = bucketId.split(":");
    if (bSplit.length === 4) { bSplit[1] = "*"; bucketId = bSplit.join(":"); }

    const ticketId = functions.MakeID().replace(/-/g, "");

    // Servidor do JWT ou fallback do config
    const server = sigData.serverAddress
        ? { ip: sigData.serverAddress, port: sigData.serverPort || 7777, id: sigData.serverId || "gs-001" }
        : findServer(playlist);

    log.backend(`[Matchmaker] ${displayName} | playlist: ${playlist} | servidor: ${server ? server.ip + ":" + (server.port||7777) : "NENHUM"}`);

    // Registar cliente
    ws._mm = { accountId, displayName, bucketId, ticketId };
    Clients.push(ws);
    ConnectingPlayers.push(accountId);

    ws.on("close", () => {
        const ci = Clients.indexOf(ws); if (ci !== -1) Clients.splice(ci, 1);
        const pi = ConnectingPlayers.indexOf(accountId); if (pi !== -1) ConnectingPlayers.splice(pi, 1);
        if (QueuedPlayers[bucketId]) QueuedPlayers[bucketId] = QueuedPlayers[bucketId].filter(p => !p.includes(accountId));
    });

    // Responder a mensagens do cliente com Queued (como Rubidium)
    ws.on("message", () => {
        sendMessage(ws, "StatusUpdate", { ticketId, queuedPlayers: 0, estimatedWaitSec: 5, status: {}, state: "Queued" });
    });

    ws.on("error", () => {});

    // -- Connecting ------------------------------------------------------------
    sendMessage(ws, "StatusUpdate", { state: "Connecting" });
    log.backend(`[Matchmaker] ${displayName} ? Connecting`);

    // -- Waiting � aguardar membros da party -----------------------------------
    if (Array.isArray(partyMembers) && partyMembers.length > 1) {
        let waited = 0;
        while (waited < 5000) {
            let connectedAmt = partyMembers.filter(pid => ConnectingPlayers.includes(pid)).length;
            sendMessage(ws, "StatusUpdate", { totalPlayers: partyMembers.length, connectedPlayers: connectedAmt, state: "Waiting" });
            if (connectedAmt >= partyMembers.length) break;
            await sleep(100);
            waited += 100;
        }
    } else {
        sendMessage(ws, "StatusUpdate", { totalPlayers: 1, connectedPlayers: 1, state: "Waiting" });
    }
    log.backend(`[Matchmaker] ${displayName} ? Waiting`);

    // Remover de ConnectingPlayers
    const pi = ConnectingPlayers.indexOf(accountId);
    if (pi !== -1) ConnectingPlayers.splice(pi, 1);
    await sleep(50);
    if (ws.readyState !== ws.OPEN) return;

    // -- Queued � adicionar � fila ---------------------------------------------
    if (!QueuedPlayers[bucketId]) QueuedPlayers[bucketId] = [];
    let alreadyQueued = QueuedPlayers[bucketId].some(party => party.includes(accountId));
    if (!alreadyQueued) {
        QueuedPlayers[bucketId].push(Array.isArray(partyMembers) ? partyMembers : [accountId]);
    }
    log.backend(`[Matchmaker] ${displayName} ? Queued`);
    sendMessage(ws, "StatusUpdate", { ticketId, queuedPlayers: 0, estimatedWaitSec: 5, status: {}, state: "Queued" });

    // -- Aguardar servidor se necess�rio ---------------------------------------
    let resolvedServer = server;
    if (!resolvedServer) {
        const deadline = Date.now() + 2 * 60 * 1000;
        while (Date.now() < deadline) {
            if (ws.readyState !== ws.OPEN) return;
            resolvedServer = findServer(playlist);
            if (resolvedServer) break;
            sendMessage(ws, "StatusUpdate", { ticketId, queuedPlayers: 0, estimatedWaitSec: Math.ceil((deadline - Date.now()) / 1000), status: {}, state: "Queued" });
            await sleep(2000);
        }
        if (!resolvedServer) {
            log.error(`[Matchmaker] ${displayName} timeout � sem servidor`);
            sendMessage(ws, "StatusUpdate", { state: "Error", message: "No server available." });
            ws.close(); return;
        }
    }

    if (ws.readyState !== ws.OPEN) return;

    // -- SessionAssignment -----------------------------------------------------
    const matchId   = functions.MakeID().replace(/-/g, "");
    const sessionId = functions.MakeID().replace(/-/g, "");

    sendMessage(ws, "StatusUpdate", { matchId, state: "SessionAssignment" });
    log.backend(`[Matchmaker] ${displayName} ? SessionAssignment | matchId: ${matchId}`);

    await sleep(hasPriority ? 300 : 600);
    if (ws.readyState !== ws.OPEN) return;

    // Guardar no KV
    try {
        await global.kv.setTTL(`playerPlaylist:${accountId}`, JSON.stringify({
            playlist, buildId: sigData.buildId || "0",
            serverId: resolvedServer.id || "gs-001",
            ip: resolvedServer.ip, port: resolvedServer.port || 7777,
            waitingForServer: false, timestamp: Date.now()
        }), 300000);
    } catch (_) {}

    // -- Play ------------------------------------------------------------------
    sendMessage(ws, "Play", { matchId, sessionId, joinDelaySec: 0 });
    log.backend(`[Matchmaker] ? ${displayName} ? PLAY | ${resolvedServer.ip}:${resolvedServer.port || 7777}`);
};