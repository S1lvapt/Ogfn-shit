const jwt = require("jsonwebtoken");

const User = require("../model/user.js");
const functions = require("../structs/functions.js");
const error = require("../structs/error.js");
const tokenCreation = require("./tokenCreation.js");

async function verifyToken(req, res, next) {
    let authErr = (reason) => {
        console.log(`❌ [AUTH ERROR] ${req.originalUrl} - ${reason}`);
        return error.createError(
            "errors.com.epicgames.common.authorization.authorization_failed",
            `Authorization failed for ${req.originalUrl}`,
            [req.originalUrl], 1032, undefined, 401, res
        );
    };

    if (!req.headers["authorization"] || !req.headers["authorization"].startsWith("bearer eg1~")) {
        return authErr("Missing or invalid authorization header");
    }

    const token = req.headers["authorization"].replace("bearer eg1~", "");

    try {
        const decodedToken = jwt.decode(token);
        let tokenExists = global.accessTokens.find(i => i.token == `eg1~${token}`);
        let isExpired = DateAddHours(new Date(decodedToken.creation_date), decodedToken.hours_expire).getTime() <= new Date().getTime();

        // If token is invalid or expired, try to use refresh token to generate new access token
        if (!tokenExists || isExpired) {
            console.log(`🔄 [AUTH] Access token invalid/expired, attempting auto-refresh for accountId: ${decodedToken.sub}`);

            // Find a valid refresh token for this account
            let validRefreshToken = global.refreshTokens.find(rt => {
                try {
                    let rtDecoded = jwt.decode(rt.token.replace("eg1~", ""));
                    let rtExpired = DateAddHours(new Date(rtDecoded.creation_date), rtDecoded.hours_expire).getTime() <= new Date().getTime();
                    return rtDecoded.sub === decodedToken.sub && !rtExpired;
                } catch {
                    return false;
                }
            });

            if (validRefreshToken) {
                // Get user from database
                let user = await User.findOne({ accountId: decodedToken.sub }).lean();
                if (!user) throw new Error("User not found");

                // Generate new access token (expires in 8 hours)
                let newAccessToken = tokenCreation.createAccess(user, decodedToken.clid, "refresh_token", decodedToken.dvid, 8);

                functions.UpdateTokens();

                console.log(`✅ [AUTH] Auto-generated new access token for: ${user.username}`);

                req.user = user;

                if (req.user.banned) return error.createError(
                    "errors.com.epicgames.account.account_not_active",
                    "You have been permanently banned from Fortnite.",
                    [], -1, undefined, 400, res
                );

                return next();
            } else {
                throw new Error("No valid refresh token found.");
            }
        }

        req.user = await User.findOne({ accountId: decodedToken.sub }).lean();

        if (req.user.banned) return error.createError(
            "errors.com.epicgames.account.account_not_active",
            "You have been permanently banned from Fortnite.",
            [], -1, undefined, 400, res
        );

        next();
    } catch (err) {
        console.log(`❌ [AUTH ERROR] Token validation failed: ${err.message}`);
        let accessIndex = global.accessTokens.findIndex(i => i.token == `eg1~${token}`);
        if (accessIndex != -1) {
            global.accessTokens.splice(accessIndex, 1);

            functions.UpdateTokens();
        }

        return authErr("Token validation failed: " + err.message);
    }
}

async function verifyClient(req, res, next) {
    let authErr = () => error.createError(
        "errors.com.epicgames.common.authorization.authorization_failed",
        `Authorization failed for ${req.originalUrl}`, 
        [req.originalUrl], 1032, undefined, 401, res
    );

    if (!req.headers["authorization"] || !req.headers["authorization"].startsWith("bearer eg1~")) return authErr();

    const token = req.headers["authorization"].replace("bearer eg1~", "");

    try {
        const decodedToken = jwt.decode(token);

        let findAccess = global.accessTokens.find(i => i.token == `eg1~${token}`);

        if (!findAccess && !global.clientTokens.find(i => i.token == `eg1~${token}`)) throw new Error("Invalid token.");

        if (DateAddHours(new Date(decodedToken.creation_date), decodedToken.hours_expire).getTime() <= new Date().getTime()) {
            throw new Error("Expired access/client token.");
        }

        if (findAccess) {
            req.user = await User.findOne({ accountId: decodedToken.sub }).lean();

            if (req.user.banned) return error.createError(
                "errors.com.epicgames.account.account_not_active",
                "You have been permanently banned from Fortnite.", 
                [], -1, undefined, 400, res
            );
        }

        next();
    } catch (err) {
        let accessIndex = global.accessTokens.findIndex(i => i.token == `eg1~${token}`);
        if (accessIndex != -1) global.accessTokens.splice(accessIndex, 1);

        let clientIndex = global.clientTokens.findIndex(i => i.token == `eg1~${token}`);
        if (clientIndex != -1) global.clientTokens.splice(clientIndex, 1);

        if (accessIndex != -1 || clientIndex != -1) functions.UpdateTokens();
        
        return authErr();
    }
}

function DateAddHours(pdate, number) {
    let date = pdate;
    date.setHours(date.getHours() + number);

    return date;
}

function verifyAdmin(req, res, next) {
    if (!req.user || !req.user.isAdmin) {
        return error.createError(
            "errors.com.epicgames.common.authorization.unauthorized",
            "You are not authorized to access this resource.",
            [], 1033, undefined, 403, res
        );
    }
    next();
}

module.exports = {
    verifyToken,
    verifyClient,
    verifyAdmin
}