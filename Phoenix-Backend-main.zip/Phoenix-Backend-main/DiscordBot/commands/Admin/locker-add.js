const { MessageEmbed } = require("discord.js");
const path = require("path");
const fs = require("fs");
const Users = require('../../../model/user.js');
const Profiles = require('../../../model/profiles.js');
const log = require("../../../structs/log.js");
const destr = require("destr");
const config = require('../../../Config/config.json')
module.exports = {
    commandInfo: {
        name: "locker-add",
        description: "Grants all available cosmetics to a specified user's locker.",
        options: [
            {
                name: "user",
                description: "The user you want to grant the cosmetics to",
                required: true,
                type: 6
            }
        ]
    },
    execute: async (interaction) => {
        if (!config.moderators.includes(interaction.user.id)) {
            return interaction.reply({ content: "you do not have moderator permissions.", ephemeral: true });
        }
        await interaction.deferReply({ ephemeral: true });
        const selectedUser = interaction.options.getUser('user');
        const selectedUserId = selectedUser?.id;
        try {
            const targetUser = await Users.findOne({ discordId: selectedUserId });
            if (!targetUser) {
                return interaction.editReply({ content: "That user does not own an account" });
            }
            const profile = await Profiles.findOne({ accountId: targetUser.accountId });
            if (!profile) {
                return interaction.editReply({ content: "That user does not have a profile" });
            }
            const allItems = destr(fs.readFileSync(path.join(__dirname, "../../../Config/DefaultProfiles/allathena.json"), 'utf8'));
            if (!allItems) {
                return interaction.editReply({ content: "failed to parse allathena.json" });
            }
            Profiles.findOneAndUpdate({ accountId: targetUser.accountId }, { $set: { "profiles.athena.items": allItems.items } }, { new: true }, (err, doc) => {
                if (err) {
                    return interaction.editReply({ content: "there was an error updating the profile." });
                }
            });
            const embed = new MessageEmbed()
                .setTitle("added full locker")
                .setDescription("added all skins to the selected acc")
                .setColor("GREEN")
                .setFooter({
                    text: "Vortyx",
                    iconURL: "https://imgur.com/nVt67YD"
                })
                .setTimestamp();
            await interaction.editReply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            log.error("An error occurred:", error);
            interaction.editReply({ content: "an error has occurred while processing the request." });
        }
    }
};