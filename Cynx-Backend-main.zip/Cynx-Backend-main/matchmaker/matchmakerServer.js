const http = require("http");
const fs = require("fs");
const { WebSocketServer } = require("ws");
const log = require("../structs/log.js");
const matchmaker = require("./matchmaker.js");

const config = JSON.parse(fs.readFileSync("./Config/config.json").toString());

function parseMatchmakerPort() {
    const raw = String(config.matchmakerIP || "127.0.0.1:1111");
    const withoutScheme = raw.replace(/^wss?:\/\//i, "");
    const port = parseInt(withoutScheme.split(":").pop(), 10);
    return Number.isFinite(port) ? port : 1111;
}

function startMatchmakerServer() {
    // ── Rubidium integration ─────────────────────────────────────────────────
    // When Rubidium is enabled it owns the matchmaker WebSocket (port 2053).
    // Kairo's built-in matchmaker is not needed and must not bind the same port.
    if (config.rubidium && config.rubidium.enabled) {
        log.backend("Rubidium matchmaker enabled — built-in matchmaker server skipped.");
        return null;
    }
    // ─────────────────────────────────────────────────────────────────────────

    const port = parseMatchmakerPort();

    const server = http.createServer((req, res) => {
        if (req.method === "POST" && (req.url === "/started" || req.url === "/started/")) {
            log.debug("Game server reported joinable via POST /started");
            matchmaker.forceMatchNow();
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ ok: true }));
            return;
        }

        res.writeHead(404);
        res.end();
    });

    const wss = new WebSocketServer({ server });
    wss.on("connection", (ws) => {
        matchmaker(ws).catch((err) => log.error(`Matchmaker connection error: ${err}`));
    });

    server.listen(port, () => {
        log.backend(`Matchmaker WebSocket listening on port ${port}`);
    }).on("error", async (err) => {
        if (err.code === "EADDRINUSE") {
            log.error(`Matchmaker port ${port} is already in use (Cynx autohost may own it).`);
        } else {
            throw err;
        }
    });

    return server;
}

module.exports = { startMatchmakerServer };
