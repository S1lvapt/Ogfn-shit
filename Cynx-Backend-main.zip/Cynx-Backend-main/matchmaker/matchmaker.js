const functions = require("../structs/functions.js");
const log = require("../structs/log.js");

let queue = [];
let matchTimer = null;
let countdown = 5;

function queueWaitSeconds() {
    if (queue.length <= 1) return 5;
    if (queue.length === 2) return 10;
    return 15;
}

function resetCountdown() {
    countdown = queueWaitSeconds();
}

function assignMatches() {
    const matchPlayers = queue.filter((player) => player.state === "Queued");
    if (matchPlayers.length === 0) return;

    queue = queue.filter((player) => player.state !== "Queued");
    if (queue.length === 0 && matchTimer) {
        clearInterval(matchTimer);
        matchTimer = null;
    }

    matchPlayers.forEach(async (player) => {
        if (player.ws.readyState !== 1) return;
        SessionAssignment(player.ws, player.matchId);
        await functions.sleep(500);
        if (player.ws.readyState === 1) {
            Join(player.ws, player.matchId, player.sessionId);
        }
    });
}

function forceMatchNow() {
    countdown = 0;
    if (matchTimer) {
        assignMatches();
        return;
    }
    assignMatches();
}

module.exports = async (ws) => {
    const ticketId = functions.MakeID().replace(/-/ig, "");
    const matchId = functions.MakeID().replace(/-/ig, "");
    const sessionId = functions.MakeID().replace(/-/ig, "");

    const player = {
        ws,
        ticketId,
        matchId,
        sessionId,
        state: "Connecting"
    };

    queue.push(player);
    log.debug(`Player joined matchmaking queue. Total: ${queue.length}`);

    resetCountdown();

    ws.on('close', () => {
        queue = queue.filter(p => p.ws !== ws);
        log.debug(`Player left matchmaking queue. Total: ${queue.length}`);
        updateQueueConfigs();
    });

    Connecting(ws);
    await functions.sleep(800);
    Waiting(ws);
    await functions.sleep(1000);

    player.state = "Queued";
    updateQueueConfigs();

    startMatchmakingTimer();
};

function updateQueueConfigs() {
    queue.forEach(player => {
        if (player.state === "Queued") {
            Queued(player.ws, player.ticketId, queue.length, countdown);
        }
    });
}

function startMatchmakingTimer() {
    if (matchTimer) return;

    matchTimer = setInterval(() => {
        if (queue.length === 0) {
            clearInterval(matchTimer);
            matchTimer = null;
            return;
        }

        if (countdown > 0) {
            countdown--;

            queue.forEach(player => {
                if (player.state === "Queued") {
                    Queued(player.ws, player.ticketId, queue.length, countdown);
                }
            });
        } else {
            assignMatches();
        }
    }, 1000);
}

module.exports.forceMatchNow = forceMatchNow;

function Connecting(ws) {
    ws.send(JSON.stringify({
        "payload": { "state": "Connecting" },
        "name": "StatusUpdate"
    }));
}

function Waiting(ws) {
    ws.send(JSON.stringify({
        "payload": {
            "totalPlayers": 1,
            "connectedPlayers": 1,
            "state": "Waiting"
        },
        "name": "StatusUpdate"
    }));
}

function Queued(ws, ticketId, queuedCount, estimatedWait) {
    ws.send(JSON.stringify({
        "payload": {
            "ticketId": ticketId,
            "queuedPlayers": queuedCount,
            "estimatedWaitSec": estimatedWait,
            "status": {},
            "state": "Queued"
        },
        "name": "StatusUpdate"
    }));
}

function SessionAssignment(ws, matchId) {
    ws.send(JSON.stringify({
        "payload": {
            "matchId": matchId,
            "state": "SessionAssignment"
        },
        "name": "StatusUpdate"
    }));
}

function Join(ws, matchId, sessionId) {
    ws.send(JSON.stringify({
        "payload": {
            "matchId": matchId,
            "sessionId": sessionId,
            "joinDelaySec": 1
        },
        "name": "Play"
    }));
}