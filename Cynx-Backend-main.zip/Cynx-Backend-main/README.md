⭐ Pls leave a star, it helps a lot!!  

I quit OGFN so dont ask me for anything

> [!WARNING]
> 1. I Quit OGFN So if you see Someone **SELLING** This **BACKEND** please dm me on discord : cynxdev 
> 2. If you are using this backend, **please give credits**.

---

## Latest Changes
- Added Arena, Added Tournaments, Battle Pass Working, XP Working, leveling up working! if u need more features just tell me on my discord server **https://discord.gg/sctnzHzj2j**
- Fixed Item Shop!!

---

## Features
- `/hwidcheck checks the hwid ids of the user you select! `
- `/ipcheck check checks the current ip of the user you select! works to ip ban too!!`
- ` /ipban if the user cheated on your project you can ip ban him! So the launcher detects if the ip is banned or not!!!`
- `/hwidban if the user cheated on your project you can just hwid ban him so he cant play anymore on your project! soon ill add it detects if the user spoofed!`
- `if u need much more features to add please let me know on my discord server! **https://discord.gg/sctnzHzj2j**`
---

