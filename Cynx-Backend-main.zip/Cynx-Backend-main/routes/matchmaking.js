const express = require("express");
const app = express.Router();
const config = require("../Config/config.json");
const functions = require("../structs/functions.js");
const log = require("../structs/log.js");
const MMCode = require("../model/mmcodes.js");
const User = require("../model/user.js");
const { verifyToken } = require("../tokenManager/tokenVerify.js");
const qs = require("qs");
const error = require("../structs/error.js");
const jwt = require("jsonwebtoken");

let buildUniqueId = {};

async function enforceMatchmakerBan(req, res) {
    if (!req.user || !req.user.matchmakerBannedUntil) {
        return false;
    }

    const expiresAt = new Date(req.user.matchmakerBannedUntil);
    if (Number.isNaN(expiresAt.getTime()) || expiresAt <= new Date()) {
        await User.updateOne(
            { accountId: req.user.accountId },
            { $set: { matchmakerBannedUntil: null, matchmakerBanReason: null } }
        );
        req.user.matchmakerBannedUntil = null;
        req.user.matchmakerBanReason = null;
        return false;
    }

    const remainingMs = expiresAt.getTime() - Date.now();
    const totalMinutes = Math.ceil(remainingMs / 60000);
    const days = Math.floor(totalMinutes / 1440);
    const hours = Math.floor((totalMinutes % 1440) / 60);
    const minutes = totalMinutes % 60;
    const remainingTextParts = [];

    if (days > 0) remainingTextParts.push(`${days}d`);
    if (hours > 0) remainingTextParts.push(`${hours}h`);
    remainingTextParts.push(`${minutes}m`);

    const reasonText = req.user.matchmakerBanReason ? ` Reason: ${req.user.matchmakerBanReason}` : "";
    const lobbyMessage = `You are matchmaker banned. Time remaining: ${remainingTextParts.join(" ")}.${reasonText}`;
    return error.createError(
        "errors.com.epicgames.matchmaking.account_banned",
        lobbyMessage,
        [],
        20017,
        "matchmaker_banned",
        403,
        res
    );
}

app.get("/fortnite/api/matchmaking/session/findPlayer/*", (req, res) => {
    log.debug("GET /fortnite/api/matchmaking/session/findPlayer/* called");
    res.status(200);
    res.end();
});

app.get("/fortnite/api/game/v2/matchmakingservice/ticket/player/*", verifyToken, async (req, res) => {
    log.debug("GET /fortnite/api/game/v2/matchmakingservice/ticket/player/* called");
    if (req.user.isServer == true) return res.status(403).end();
    if (req.user.matchmakingId == null) return res.status(400).end();
    if (await enforceMatchmakerBan(req, res)) return;

    const playerCustomKey = qs.parse(req.url.split("?")[1], { ignoreQueryPrefix: true })['player.option.customKey'];
    const bucketId = qs.parse(req.url.split("?")[1], { ignoreQueryPrefix: true })['bucketId'];
    if (typeof bucketId !== "string" || bucketId.split(":").length !== 4) {
        return res.status(400).end();
    }
    const rawPlaylist = bucketId.split(":")[3];
    let playlist = functions.PlaylistNames(rawPlaylist).toLowerCase();

    const gameServers = config.gameServerIP;
    let selectedServer = gameServers.find(server => server.split(":")[2].toLowerCase() === playlist);
    if (!selectedServer) {
        log.debug("No server found for playlist", playlist);
        return error.createError("errors.com.epicgames.common.matchmaking.playlist.not_found", `No server found for playlist ${playlist}`, [], 1013, "invalid_playlist", 404, res);
    }
    await global.kv.set(`playerPlaylist:${req.user.accountId}`, playlist);
    if (typeof playerCustomKey == "string") {
        let codeDocument = await MMCode.findOne({ code_lower: playerCustomKey?.toLowerCase() });
        if (!codeDocument) {
            return error.createError("errors.com.epicgames.common.matchmaking.code.not_found", `The matchmaking code "${playerCustomKey}" was not found`, [], 1013, "invalid_code", 404, res);
        }
        const kvDocument = JSON.stringify({
            ip: codeDocument.ip,
            port: codeDocument.port,
            playlist: playlist,
        });
        await global.kv.set(`playerCustomKey:${req.user.accountId}`, kvDocument);
    }
    if (typeof req.query.bucketId !== "string" || req.query.bucketId.split(":").length !== 4) {
        return res.status(400).end();
    }

    const bucketParts = req.query.bucketId.split(":");
    buildUniqueId[req.user.accountId] = bucketParts.length >= 3 ? bucketParts[2] : bucketParts[0];

    // ── Rubidium external matchmaker ────────────────────────────────────────
    if (config.rubidium && config.rubidium.enabled) {
        const region =
            (config.gameServerRegions && (config.gameServerRegions[playlist] || config.gameServerRegions["default"])) ||
            config.defaultGameServerRegion ||
            "EU";

        const serverParts = selectedServer.split(":");
        const serverAddress = serverParts[0];
        const serverPort = serverParts[1];

        // JWT payload – every field that Rubidium reads from SignatureData
        const rubidiumPayload = {
            accountId:     req.user.accountId,
            bucketId:      req.query.bucketId,
            bucketIds:     req.query.bucketId,   // used by DedicatedServerSocket
            region:        region,
            playlist:      playlist,
            // string → Rubidium treats solo players as a single-member party
            // swap for an array of accountIds to support full party queueing
            partyMembers:  req.user.accountId,
            buildUniqueId: buildUniqueId[req.user.accountId] || "19100000",
            serverAddress: serverAddress,
            serverPort:    serverPort
        };

        const rubidiumJwt = jwt.sign(
            rubidiumPayload,
            config.rubidium.secretKey,
            { expiresIn: "1h" }
        );

        log.debug(`Issuing Rubidium ticket for ${req.user.accountId} → ${config.rubidium.matchmakerUrl}`);

        // payload is compact JSON so the Authorization header produced by the
        // game client contains "}  " allowing Rubidium to extract the JWT via
        // authHeader.split("} ")[1].split(" ")[0]
        return res.json({
            "serviceUrl": config.rubidium.matchmakerUrl,
            "ticketType": "mms-player",
            "payload":    JSON.stringify({ accountId: req.user.accountId }),
            "signature":  rubidiumJwt
        });
    }
    // ── Built-in matchmaker (fallback) ───────────────────────────────────────
    const matchmakerIP = config.matchmakerIP;
    return res.json({
        "serviceUrl": matchmakerIP.includes("ws") || matchmakerIP.includes("wss") ? matchmakerIP : `ws://${matchmakerIP}`,
        "ticketType": "mms-player",
        "payload": `${req.user.matchmakingId}`,
        "signature": "account"
    });
});

app.get("/fortnite/api/game/v2/matchmaking/account/:accountId/session/:sessionId", (req, res) => {
    log.debug(`GET /fortnite/api/game/v2/matchmaking/account/${req.params.accountId}/session/${req.params.sessionId} called`);
    res.json({
        "accountId": req.params.accountId,
        "sessionId": req.params.sessionId,
        "key": "none"
    });
});

app.get("/fortnite/api/matchmaking/session/:sessionId", verifyToken, async (req, res) => {
    log.debug(`GET /fortnite/api/matchmaking/session/${req.params.sessionId} called`);
    if (await enforceMatchmakerBan(req, res)) return;

    // ── Rubidium: fetch real session data from Rubidium API ─────────────────
    if (config.rubidium && config.rubidium.enabled) {
        try {
            const apiRes = await fetch(
                `${config.rubidium.apiUrl}/solstice/api/v1/servers/${req.params.sessionId}`
            );
            if (apiRes.ok) {
                const sessionData = await apiRes.json();
                if (sessionData && sessionData.serverAddress) {
                    const playlistName = functions.PlaylistNames(sessionData.playlist || "");
                    const isCreative = playlistName.toLowerCase().includes("playground");
                    log.debug(`Rubidium session ${req.params.sessionId}: ${sessionData.serverAddress}:${sessionData.serverPort}`);
                    return res.json({
                        "id": req.params.sessionId,
                        "ownerId": functions.MakeID().replace(/-/ig, "").toUpperCase(),
                        "ownerName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
                        "serverName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
                        "serverAddress": sessionData.serverAddress,
                        "serverPort": parseInt(sessionData.serverPort, 10) || sessionData.serverPort,
                        "maxPublicPlayers": 220,
                        "openPublicPlayers": 175,
                        "maxPrivatePlayers": 0,
                        "openPrivatePlayers": 0,
                        "attributes": {
                            "REGION_s": sessionData.region || "EU",
                            "GAMEMODE_s": "FORTATHENA",
                            "ALLOWBROADCASTING_b": true,
                            "SUBREGION_s": "GB",
                            "DCID_s": "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
                            "tenant_s": "Fortnite",
                            "MATCHMAKINGPOOL_s": "Any",
                            "STORMSHIELDDEFENSETYPE_i": 0,
                            "HOTFIXVERSION_i": 0,
                            "PLAYLISTNAME_s": playlistName,
                            "SESSIONKEY_s": functions.MakeID().replace(/-/ig, "").toUpperCase(),
                            "TENANT_s": "Fortnite",
                            "BEACONPORT_i": 15009
                        },
                        "publicPlayers": [],
                        "privatePlayers": [],
                        "totalPlayers": sessionData.clients || 1,
                        "allowJoinInProgress": isCreative,
                        "shouldAdvertise": false,
                        "isDedicated": true,
                        "usesStats": false,
                        "allowInvites": false,
                        "usesPresence": false,
                        "allowJoinViaPresence": true,
                        "allowJoinViaPresenceFriendsOnly": false,
                        "buildUniqueId": sessionData.bucketId ? sessionData.bucketId.split(":")[0] : (buildUniqueId[req.user.accountId] || "0"),
                        "lastUpdated": new Date().toISOString(),
                        "started": isCreative
                    });
                }
            }
            log.debug(`Rubidium session ${req.params.sessionId} not found, falling back to config`);
        } catch (err) {
            log.error(`Rubidium session fetch failed: ${err.message}`);
        }
    }

    // ── Fallback: derive server info from config (built-in matchmaker) ───────
    const playlist = await global.kv.get(`playerPlaylist:${req.user.accountId}`);
    let kvDocument = await global.kv.get(`playerCustomKey:${req.user.accountId}`);
    if (!kvDocument) {
        const gameServers = config.gameServerIP;
        const playlistKey = String(playlist || "").toLowerCase();
        let selectedServer = gameServers.find(server => server.split(":")[2].toLowerCase() === playlistKey);
        if (!selectedServer) {
            log.debug("No server found for playlist", playlist);
            return error.createError("errors.com.epicgames.common.matchmaking.playlist.not_found", `No server found for playlist ${playlist}`, [], 1013, "invalid_playlist", 404, res);
        }
        kvDocument = JSON.stringify({
            ip: selectedServer.split(":")[0],
            port: selectedServer.split(":")[1],
            playlist: selectedServer.split(":")[2]
        });
    }
    let codeKV = JSON.parse(kvDocument);
    const playlistName = functions.PlaylistNames(codeKV.playlist);
    const isCreative = playlistName.toLowerCase().includes("playground");

    res.json({
        "id": req.params.sessionId,
        "ownerId": functions.MakeID().replace(/-/ig, "").toUpperCase(),
        "ownerName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
        "serverName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
        "serverAddress": codeKV.ip,
        "serverPort": parseInt(codeKV.port, 10) || codeKV.port,
        "maxPublicPlayers": 220,
        "openPublicPlayers": 175,
        "maxPrivatePlayers": 0,
        "openPrivatePlayers": 0,
        "attributes": {
          "REGION_s": "EU",
          "GAMEMODE_s": "FORTATHENA",
          "ALLOWBROADCASTING_b": true,
          "SUBREGION_s": "GB",
          "DCID_s": "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
          "tenant_s": "Fortnite",
          "MATCHMAKINGPOOL_s": "Any",
          "STORMSHIELDDEFENSETYPE_i": 0,
          "HOTFIXVERSION_i": 0,
          "PLAYLISTNAME_s": playlistName,
          "SESSIONKEY_s": functions.MakeID().replace(/-/ig, "").toUpperCase(),
          "TENANT_s": "Fortnite",
          "BEACONPORT_i": 15009
        },
        "publicPlayers": [],
        "privatePlayers": [],
        "totalPlayers": 45,
        "allowJoinInProgress": isCreative,
        "shouldAdvertise": false,
        "isDedicated": true,
        "usesStats": false,
        "allowInvites": false,
        "usesPresence": false,
        "allowJoinViaPresence": true,
        "allowJoinViaPresenceFriendsOnly": false,
        "buildUniqueId": buildUniqueId[req.user.accountId] || "0",
        "lastUpdated": new Date().toISOString(),
        "started": isCreative
      });
});

app.post("/fortnite/api/matchmaking/session/*/join", (req, res) => {
    log.debug("POST /fortnite/api/matchmaking/session/*/join called");
    res.status(204);
    res.end();
});

app.post("/fortnite/api/matchmaking/session/matchMakingRequest", (req, res) => {
    log.debug("POST /fortnite/api/matchmaking/session/matchMakingRequest called");
    res.json([]);
});

module.exports = app;