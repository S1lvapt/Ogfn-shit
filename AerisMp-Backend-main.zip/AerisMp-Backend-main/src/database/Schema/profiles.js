export { default } from '../../User/Mongodb/Schema/profiles.js';
