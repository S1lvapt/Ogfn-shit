export { default } from '../../User/Mongodb/Schema/friends.js';
